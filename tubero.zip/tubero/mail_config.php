<?php
// ============================================
// PHPMailer Configuration
// ============================================

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Load PHPMailer (make sure to include the path to PHPMailer)
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

class MailConfig {
    private $mail;
    
    public function __construct() {
        $this->mail = new PHPMailer(true);
        
        // Server settings
        $this->mail->SMTPDebug = 0; // Enable for debugging: SMTP::DEBUG_SERVER
        $this->mail->isSMTP();
        $this->mail->Host       = 'smtp.gmail.com'; // Your SMTP server
        $this->mail->SMTPAuth   = true;
        $this->mail->Username   = 'taglejoshua1212@gmail.com'; // Your email
        $this->mail->Password   = 'ogak oefc qtuq ynag'; // Your app password
        $this->mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $this->mail->Port       = 587;
        
        // Default sender
        $this->mail->setFrom('noreply@tubero.com', 'Tubero Management System');
    }
    
    public function sendVerificationEmail($email, $name, $token) {
        try {
            $this->mail->clearAddresses();
            $this->mail->addAddress($email, $name);
            $this->mail->isHTML(true);
            $this->mail->Subject = 'Verify Your Email - Tubero Management System';
            
            // Verification link
            $verifyLink = "http://127.0.0.1/tubero/user-side.php?page=verify&token=" . $token;
            
            // Email template
            $this->mail->Body = "
            <!DOCTYPE html>
            <html>
            <head>
                <style>
                    body { font-family: Arial, sans-serif; line-height: 1.6; }
                    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                    .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; text-align: center; }
                    .content { padding: 30px; background: #f9f9f9; }
                    .button { display: inline-block; padding: 12px 30px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
                    .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
                </style>
            </head>
            <body>
                <div class='container'>
                    <div class='header'>
                        <h2>Tubero Management System</h2>
                    </div>
                    <div class='content'>
                        <h3>Hello $name,</h3>
                        <p>Thank you for registering with Tubero Management System! Please verify your email address to complete your registration.</p>
                        <p>Click the button below to verify your email:</p>
                        <p style='text-align: center;'>
                            <a href='$verifyLink' class='button'>Verify Email Address</a>
                        </p>
                        <p>Or copy and paste this link in your browser:</p>
                        <p style='word-break: break-all;'>$verifyLink</p>
                        <p>This link will expire in 24 hours.</p>
                    </div>
                    <div class='footer'>
                        <p>&copy; 2024 Tubero Management System. All rights reserved.</p>
                        <p>This is an automated message, please do not reply.</p>
                    </div>
                </div>
            </body>
            </html>
            ";
            
            $this->mail->AltBody = "Hello $name,\n\nThank you for registering. Please verify your email by clicking this link: $verifyLink\n\nThis link will expire in 24 hours.";
            
            $this->mail->send();
            return true;
        } catch (Exception $e) {
            return false;
        }
    }
    
    public function sendPasswordResetEmail($email, $name, $token) {
        try {
            $this->mail->clearAddresses();
            $this->mail->addAddress($email, $name);
            $this->mail->isHTML(true);
            $this->mail->Subject = 'Password Reset - Tubero Management System';
            
            // Reset link
            $resetLink = "http://127.0.0.1/tubero/user-side.php?page=reset_password&token=" . $token;
            
            // Email template
            $this->mail->Body = "
            <!DOCTYPE html>
            <html>
            <head>
                <style>
                    body { font-family: Arial, sans-serif; line-height: 1.6; }
                    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                    .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; text-align: center; }
                    .content { padding: 30px; background: #f9f9f9; }
                    .button { display: inline-block; padding: 12px 30px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
                    .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
                </style>
            </head>
            <body>
                <div class='container'>
                    <div class='header'>
                        <h2>Tubero Management System</h2>
                    </div>
                    <div class='content'>
                        <h3>Hello $name,</h3>
                        <p>We received a request to reset your password. Click the button below to create a new password:</p>
                        <p style='text-align: center;'>
                            <a href='$resetLink' class='button'>Reset Password</a>
                        </p>
                        <p>Or copy and paste this link in your browser:</p>
                        <p style='word-break: break-all;'>$resetLink</p>
                        <p>This link will expire in 1 hour.</p>
                        <p>If you didn't request a password reset, please ignore this email.</p>
                    </div>
                    <div class='footer'>
                        <p>&copy; 2024 Tubero Management System. All rights reserved.</p>
                        <p>This is an automated message, please do not reply.</p>
                    </div>
                </div>
            </body>
            </html>
            ";
            
            $this->mail->AltBody = "Hello $name,\n\nWe received a request to reset your password. Click this link to reset it: $resetLink\n\nThis link will expire in 1 hour.\n\nIf you didn't request this, please ignore this email.";
            
            $this->mail->send();
            return true;
        } catch (Exception $e) {
            return false;
        }
    }
    
    public function sendWelcomeEmail($email, $name) {
        try {
            $this->mail->clearAddresses();
            $this->mail->addAddress($email, $name);
            $this->mail->isHTML(true);
            $this->mail->Subject = 'Welcome to Tubero Management System!';
            
            $this->mail->Body = "
            <!DOCTYPE html>
            <html>
            <head>
                <style>
                    body { font-family: Arial, sans-serif; line-height: 1.6; }
                    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                    .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; text-align: center; }
                    .content { padding: 30px; background: #f9f9f9; }
                    .button { display: inline-block; padding: 12px 30px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
                    .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
                </style>
            </head>
            <body>
                <div class='container'>
                    <div class='header'>
                        <h2>Welcome to Tubero Management System!</h2>
                    </div>
                    <div class='content'>
                        <h3>Hello $name,</h3>
                        <p>Your email has been successfully verified! You can now:</p>
                        <ul>
                            <li>Request plumbing services</li>
                            <li>Track your service requests</li>
                            <li>View service history</li>
                            <li>Save your preferences</li>
                        </ul>
                        <p style='text-align: center;'>
                            <a href='http://127.0.0.1/tubero/user-side.php?page=home' class='button'>Start Using Tubero</a>
                        </p>
                    </div>
                    <div class='footer'>
                        <p>&copy; 2024 Tubero Management System. All rights reserved.</p>
                    </div>
                </div>
            </body>
            </html>
            ";
            
            $this->mail->AltBody = "Hello $name,\n\nYour email has been successfully verified! You can now request plumbing services and track your requests through our system.";
            
            $this->mail->send();
            return true;
        } catch (Exception $e) {
            return false;
        }
    }
}
?>