<?php
// ============================================
// TUBERO MANAGEMENT SYSTEM - USER SIDE
// ============================================

session_start();

// Database configuration (same as admin)
$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'tubero_system';

// Create connection
$conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Include PHPMailer configuration
require_once 'mail_config.php';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'register':
                registerUser($conn, $_POST);
                break;
            case 'login':
                loginUser($conn, $_POST);
                break;
            case 'logout':
                logoutUser();
                break;
            case 'submit_request':
                submitServiceRequest($conn, $_POST);
                break;
            case 'track_request':
                header("Location: ?page=track&ref=" . $_POST['reference']);
                exit();
                break;
            case 'forgot_password':
                forgotPassword($conn, $_POST);
                break;
            case 'reset_password':
                resetPassword($conn, $_POST);
                break;
            case 'resend_verification':
                resendVerification($conn, $_POST);
                break;
        }
    }
}

// Function to register user
function registerUser($conn, $data) {
    // Check if email already exists
    $checkEmail = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $checkEmail->bind_param("s", $data['email']);
    $checkEmail->execute();
    $result = $checkEmail->get_result();
    
    if ($result->num_rows > 0) {
        $_SESSION['error'] = "Email already registered. Please login or use a different email.";
        header("Location: " . $_SERVER['PHP_SELF'] . "?page=register");
        exit();
    }
    
    // Validate password
    if (strlen($data['password']) < 8) {
        $_SESSION['error'] = "Password must be at least 8 characters long.";
        header("Location: " . $_SERVER['PHP_SELF'] . "?page=register");
        exit();
    }
    
    if ($data['password'] !== $data['confirm_password']) {
        $_SESSION['error'] = "Passwords do not match.";
        header("Location: " . $_SERVER['PHP_SELF'] . "?page=register");
        exit();
    }
    
    // Hash password
    $hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);
    
    // Generate verification token
    $token = bin2hex(random_bytes(32));
    
    // Insert user
    $stmt = $conn->prepare("INSERT INTO users (full_name, email, password, contact_number, address, verification_token) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $data['full_name'], $data['email'], $hashedPassword, $data['contact'], $data['address'], $token);
    
    if ($stmt->execute()) {
        // Send verification email
        $mailer = new MailConfig();
        if ($mailer->sendVerificationEmail($data['email'], $data['full_name'], $token)) {
            $_SESSION['success'] = "Registration successful! Please check your email to verify your account.";
            $_SESSION['email'] = $data['email'];
        } else {
            $_SESSION['warning'] = "Registration successful but failed to send verification email. Please contact support.";
        }
        header("Location: " . $_SERVER['PHP_SELF'] . "?page=login");
    } else {
        $_SESSION['error'] = "Registration failed: " . $conn->error;
        header("Location: " . $_SERVER['PHP_SELF'] . "?page=register");
    }
    exit();
}

// Function to login user
function loginUser($conn, $data) {
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $data['email']);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        
        // Check if email is verified
        if ($user['email_verified'] == 0) {
            $_SESSION['error'] = "Please verify your email before logging in. <a href='?page=resend_verification&email=" . urlencode($data['email']) . "'>Resend verification email</a>";
            header("Location: " . $_SERVER['PHP_SELF'] . "?page=login");
            exit();
        }
        
        if (password_verify($data['password'], $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['logged_in'] = true;
            
            // Update last login
            $conn->query("UPDATE users SET last_login = NOW() WHERE id = " . $user['id']);
            
            $_SESSION['success'] = "Welcome back, " . $user['full_name'] . "!";
            header("Location: " . $_SERVER['PHP_SELF'] . "?page=dashboard");
        } else {
            $_SESSION['error'] = "Invalid password!";
            header("Location: " . $_SERVER['PHP_SELF'] . "?page=login");
        }
    } else {
        $_SESSION['error'] = "Email not found!";
        header("Location: " . $_SERVER['PHP_SELF'] . "?page=login");
    }
    exit();
}

// Function to logout user
function logoutUser() {
    session_destroy();
    header("Location: " . $_SERVER['PHP_SELF'] . "?page=home");
    exit();
}

// Function to handle forgot password
function forgotPassword($conn, $data) {
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $data['email']);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        
        // Generate reset token
        $token = bin2hex(random_bytes(32));
        $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
        
        // Save token
        $update = $conn->prepare("UPDATE users SET reset_token = ?, reset_expires = ? WHERE id = ?");
        $update->bind_param("ssi", $token, $expires, $user['id']);
        $update->execute();
        
        // Send reset email
        $mailer = new MailConfig();
        if ($mailer->sendPasswordResetEmail($user['email'], $user['full_name'], $token)) {
            $_SESSION['success'] = "Password reset instructions have been sent to your email.";
        } else {
            $_SESSION['error'] = "Failed to send reset email. Please try again.";
        }
    } else {
        $_SESSION['error'] = "Email not found in our records.";
    }
    header("Location: " . $_SERVER['PHP_SELF'] . "?page=forgot_password");
    exit();
}

// Function to reset password
function resetPassword($conn, $data) {
    if ($data['password'] !== $data['confirm_password']) {
        $_SESSION['error'] = "Passwords do not match.";
        header("Location: " . $_SERVER['PHP_SELF'] . "?page=reset_password&token=" . $data['token']);
        exit();
    }
    
    if (strlen($data['password']) < 8) {
        $_SESSION['error'] = "Password must be at least 8 characters long.";
        header("Location: " . $_SERVER['PHP_SELF'] . "?page=reset_password&token=" . $data['token']);
        exit();
    }
    
    $hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);
    
    $stmt = $conn->prepare("UPDATE users SET password = ?, reset_token = NULL, reset_expires = NULL WHERE reset_token = ? AND reset_expires > NOW()");
    $stmt->bind_param("ss", $hashedPassword, $data['token']);
    
    if ($stmt->execute() && $stmt->affected_rows > 0) {
        $_SESSION['success'] = "Password reset successful! You can now login with your new password.";
        header("Location: " . $_SERVER['PHP_SELF'] . "?page=login");
    } else {
        $_SESSION['error'] = "Invalid or expired reset token.";
        header("Location: " . $_SERVER['PHP_SELF'] . "?page=forgot_password");
    }
    exit();
}

// Function to resend verification email
function resendVerification($conn, $data) {
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? AND email_verified = 0");
    $stmt->bind_param("s", $data['email']);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        
        // Generate new token
        $token = bin2hex(random_bytes(32));
        $conn->query("UPDATE users SET verification_token = '$token' WHERE id = " . $user['id']);
        
        // Send verification email
        $mailer = new MailConfig();
        if ($mailer->sendVerificationEmail($user['email'], $user['full_name'], $token)) {
            $_SESSION['success'] = "Verification email has been resent. Please check your inbox.";
        } else {
            $_SESSION['error'] = "Failed to send verification email. Please try again.";
        }
    } else {
        $_SESSION['error'] = "Email not found or already verified.";
    }
    header("Location: " . $_SERVER['PHP_SELF'] . "?page=login");
    exit();
}

// Handle email verification
if (isset($_GET['page']) && $_GET['page'] == 'verify' && isset($_GET['token'])) {
    $token = $conn->real_escape_string($_GET['token']);
    $result = $conn->query("SELECT * FROM users WHERE verification_token = '$token' AND email_verified = 0");
    
    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        $conn->query("UPDATE users SET email_verified = 1, verification_token = NULL WHERE id = " . $user['id']);
        
        // Send welcome email
        $mailer = new MailConfig();
        $mailer->sendWelcomeEmail($user['email'], $user['full_name']);
        
        $_SESSION['success'] = "Email verified successfully! You can now login.";
        header("Location: " . $_SERVER['PHP_SELF'] . "?page=login");
    } else {
        $_SESSION['error'] = "Invalid or expired verification token.";
        header("Location: " . $_SERVER['PHP_SELF'] . "?page=login");
    }
    exit();
}

// Function to submit service request (updated to include user_id)
function submitServiceRequest($conn, $data) {
    $reference = 'TUB-' . strtoupper(uniqid());
    $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 'NULL';
    
    $stmt = $conn->prepare("INSERT INTO service_requests (user_id, customer_name, customer_contact, customer_address, location_area, problem_description, status, reference_number) VALUES (?, ?, ?, ?, ?, ?, 'pending', ?)");
    $stmt->bind_param("issssss", $user_id, $data['name'], $data['contact'], $data['address'], $data['area'], $data['problem'], $reference);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Service request submitted successfully! Your reference number is: " . $reference;
        $_SESSION['reference'] = $reference;
    } else {
        $_SESSION['error'] = "Error submitting request: " . $conn->error;
    }
    header("Location: " . $_SERVER['PHP_SELF'] . "?page=success");
    exit();
}


// Get current page
$page = isset($_GET['page']) ? $_GET['page'] : 'home';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tubero Management System - Book a Plumber</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f5f5;
        }
        
        /* Navigation */
        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 1rem 2rem;
            color: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .nav-container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .logo {
            font-size: 1.5rem;
            font-weight: bold;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .logo i {
            font-size: 2rem;
        }
        
        .nav-links a {
            color: white;
            text-decoration: none;
            margin-left: 2rem;
            padding: 0.5rem 1rem;
            border-radius: 5px;
            transition: background 0.3s;
        }
        
        .nav-links a:hover {
            background: rgba(255,255,255,0.2);
        }
        
        /* Hero Section */
        .hero {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 4rem 2rem;
            text-align: center;
        }
        
        .hero h1 {
            font-size: 3rem;
            margin-bottom: 1rem;
        }
        
        .hero p {
            font-size: 1.2rem;
            margin-bottom: 2rem;
            opacity: 0.9;
        }
        
        .cta-button {
            background: white;
            color: #667eea;
            border: none;
            padding: 1rem 2rem;
            font-size: 1.2rem;
            border-radius: 50px;
            cursor: pointer;
            font-weight: bold;
            transition: transform 0.3s;
            text-decoration: none;
            display: inline-block;
        }
        
        .cta-button:hover {
            transform: translateY(-2px);
        }
        
        /* Container */
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }
        
        /* Cards */
        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            margin: 3rem 0;
        }
        
        .feature-card {
            background: white;
            padding: 2rem;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }
        
        .feature-card:hover {
            transform: translateY(-5px);
        }
        
        .feature-card i {
            font-size: 3rem;
            color: #667eea;
            margin-bottom: 1rem;
        }
        
        .feature-card h3 {
            margin-bottom: 1rem;
            color: #333;
        }
        
        .feature-card p {
            color: #666;
            line-height: 1.6;
        }
        
        /* Forms */
        .form-container {
            background: white;
            border-radius: 10px;
            padding: 2rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            max-width: 600px;
            margin: 2rem auto;
        }
        
        .form-container h2 {
            text-align: center;
            color: #333;
            margin-bottom: 2rem;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            color: #333;
            font-weight: 500;
        }
        
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1rem;
            transition: border-color 0.3s;
        }
        
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .form-group textarea {
            resize: vertical;
            min-height: 100px;
        }
        
        .btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            padding: 1rem 2rem;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 600;
            width: 100%;
            transition: transform 0.3s;
        }
        
        .btn:hover {
            transform: translateY(-2px);
        }
        
        .btn-outline {
            background: transparent;
            border: 2px solid #667eea;
            color: #667eea;
        }
        
        /* Messages */
        .alert {
            padding: 1rem;
            border-radius: 5px;
            margin-bottom: 1rem;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .alert-info {
            background: #d1ecf1;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }
        
        /* Request Status */
        .tracking-container {
            background: white;
            border-radius: 10px;
            padding: 2rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .status-timeline {
            display: flex;
            justify-content: space-between;
            margin: 3rem 0;
            position: relative;
        }
        
        .status-timeline::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 0;
            right: 0;
            height: 2px;
            background: #ddd;
            transform: translateY(-50%);
            z-index: 1;
        }
        
        .status-step {
            text-align: center;
            position: relative;
            z-index: 2;
            background: white;
            padding: 0 1rem;
        }
        
        .status-step.completed .step-icon {
            background: #28a745;
            color: white;
        }
        
        .status-step.active .step-icon {
            background: #667eea;
            color: white;
            transform: scale(1.1);
        }
        
        .step-icon {
            width: 50px;
            height: 50px;
            background: #ddd;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 0.5rem;
            transition: all 0.3s;
        }
        
        .step-icon i {
            font-size: 1.2rem;
        }
        
        .step-label {
            font-weight: 500;
            color: #333;
        }
        
        .request-details {
            background: #f8f9fa;
            padding: 1.5rem;
            border-radius: 5px;
            margin: 2rem 0;
        }
        
        .request-details h3 {
            color: #333;
            margin-bottom: 1rem;
        }
        
        .detail-row {
            display: flex;
            margin-bottom: 0.5rem;
        }
        
        .detail-label {
            font-weight: 600;
            width: 150px;
            color: #666;
        }
        
        .detail-value {
            color: #333;
        }
        
        /* Plumber List */
        .plumber-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 1.5rem;
            margin: 2rem 0;
        }
        
        .plumber-card {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }
        
        .plumber-card:hover {
            transform: translateY(-5px);
        }
        
        .plumber-card h3 {
            color: #333;
            margin-bottom: 0.5rem;
        }
        
        .plumber-card .role {
            color: #667eea;
            font-weight: 600;
            margin-bottom: 1rem;
        }
        
        .plumber-card .details {
            color: #666;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .plumber-card .details i {
            width: 20px;
            color: #667eea;
        }
        
        .plumber-card .rate {
            font-size: 1.2rem;
            color: #333;
            font-weight: 600;
            margin: 1rem 0;
        }
        
        /* Map */
        .map-container {
            margin: 2rem 0;
            height: 400px;
            border-radius: 10px;
            overflow: hidden;
        }
        
        /* Footer */
        .footer {
            background: #333;
            color: white;
            text-align: center;
            padding: 2rem;
            margin-top: 3rem;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .nav-container {
                flex-direction: column;
                gap: 1rem;
            }
            
            .nav-links a {
                margin: 0 0.5rem;
            }
            
            .hero h1 {
                font-size: 2rem;
            }
            
            .features-grid {
                grid-template-columns: 1fr;
            }
            
            .status-timeline {
                flex-direction: column;
                gap: 1rem;
            }
            
            .status-timeline::before {
                display: none;
            }
            
            .status-step {
                display: flex;
                align-items: center;
                gap: 1rem;
            }
        }

        /* Auth Pages */
        .auth-container {
            min-height: calc(100vh - 200px);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
        }
        
        .auth-box {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 450px;
            padding: 2.5rem;
        }
        
        .auth-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        
        .auth-header i {
            font-size: 3rem;
            color: #667eea;
            margin-bottom: 1rem;
        }
        
        .auth-header h2 {
            color: #333;
            margin-bottom: 0.5rem;
        }
        
        .auth-header p {
            color: #666;
        }
        
        .auth-tabs {
            display: flex;
            margin-bottom: 2rem;
            border-bottom: 2px solid #f0f0f0;
        }
        
        .auth-tab {
            flex: 1;
            text-align: center;
            padding: 1rem;
            cursor: pointer;
            color: #666;
            transition: all 0.3s;
            position: relative;
        }
        
        .auth-tab.active {
            color: #667eea;
        }
        
        .auth-tab.active::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            right: 0;
            height: 2px;
            background: #667eea;
        }
        
        .auth-form {
            display: none;
        }
        
        .auth-form.active {
            display: block;
        }
        
        .password-requirements {
            background: #f8f9fa;
            padding: 1rem;
            border-radius: 5px;
            margin: 1rem 0;
            font-size: 0.9rem;
        }
        
        .password-requirements p {
            margin-bottom: 0.5rem;
            font-weight: 600;
        }
        
        .password-requirements ul {
            list-style: none;
            padding-left: 0;
        }
        
        .password-requirements li {
            margin-bottom: 0.3rem;
            color: #666;
        }
        
        .password-requirements li.valid {
            color: #28a745;
        }
        
        .password-requirements li i {
            margin-right: 0.5rem;
        }
        
        .user-menu {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: white;
        }
        
        .user-info i {
            font-size: 1.2rem;
        }
        
        .dropdown {
            position: relative;
            display: inline-block;
        }
        
        .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background: white;
            min-width: 200px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
            border-radius: 5px;
            z-index: 1;
        }
        
        .dropdown:hover .dropdown-content {
            display: block;
        }
        
        .dropdown-content a {
            color: #333;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            transition: background 0.3s;
        }
        
        .dropdown-content a:hover {
            background: #f5f5f5;
        }
        
        .dropdown-content a i {
            width: 20px;
            margin-right: 10px;
            color: #667eea;
        }
        
        /* Dashboard */
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1.5rem;
            margin: 2rem 0;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .dashboard-card h3 {
            color: #333;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .dashboard-card h3 i {
            color: #667eea;
        }
        
        .request-list {
            list-style: none;
        }
        
        .request-list-item {
            padding: 1rem 0;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .request-list-item:last-child {
            border-bottom: none;
        }
        
        .request-status {
            display: inline-block;
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .status-pending { background: #ffc107; color: #000; }
        .status-assigned { background: #17a2b8; color: #fff; }
        .status-in_progress { background: #007bff; color: #fff; }
        .status-completed { background: #28a745; color: #fff; }
        .status-cancelled { background: #dc3545; color: #fff; }
        
        /* Profile Page */
        .profile-container {
            max-width: 800px;
            margin: 2rem auto;
        }
        
        .profile-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 2rem;
            border-radius: 10px 10px 0 0;
            text-align: center;
        }
        
        .profile-avatar {
            width: 100px;
            height: 100px;
            background: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1rem;
        }
        
        .profile-avatar i {
            font-size: 3rem;
            color: #667eea;
        }
        
        .profile-content {
            background: white;
            padding: 2rem;
            border-radius: 0 0 10px 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .info-group {
            margin-bottom: 1.5rem;
        }
        
        .info-label {
            font-weight: 600;
            color: #666;
            margin-bottom: 0.3rem;
        }
        
        .info-value {
            color: #333;
            font-size: 1.1rem;
        }
        
        /* Responsive additions */
        @media (max-width: 768px) {
            .nav-container {
                flex-direction: column;
                gap: 1rem;
            }
            
            .user-menu {
                margin-top: 0.5rem;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">
                <i class="fas fa-tools"></i>
                <span>Tubero System</span>
            </div>
            <div class="nav-links">
                <a href="?page=home"><i class="fas fa-home"></i> Home</a>
                <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']): ?>
                    <a href="?page=dashboard"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                    <a href="?page=request"><i class="fas fa-plus-circle"></i> Request Service</a>
                    <a href="?page=track"><i class="fas fa-search"></i> Track</a>
                <?php else: ?>
                    <a href="?page=login"><i class="fas fa-sign-in-alt"></i> Login</a>
                    <a href="?page=register"><i class="fas fa-user-plus"></i> Register</a>
                <?php endif; ?>
            </div>
            
            <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']): ?>
                <div class="user-menu">
                    <div class="user-info">
                        <i class="fas fa-user-circle"></i>
                        <span><?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
                    </div>
                    <div class="dropdown">
                        <i class="fas fa-chevron-down" style="color: white; cursor: pointer;"></i>
                        <div class="dropdown-content">
                            <a href="?page=dashboard"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                            <a href="?page=profile"><i class="fas fa-user"></i> My Profile</a>
                            <a href="?page=history"><i class="fas fa-history"></i> Request History</a>
                            <hr>
                            <form method="POST" style="margin: 0;">
                                <input type="hidden" name="action" value="logout">
                                <button type="submit" style="width: 100%; text-align: left; padding: 12px 16px; background: none; border: none; cursor: pointer; color: #dc3545;">
                                    <i class="fas fa-sign-out-alt"></i> Logout
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </nav>
    
    <!-- Messages -->
    <?php if (isset($_SESSION['success'])): ?>
        <div class="container">
            <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
        </div>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['error'])): ?>
        <div class="container">
            <div class="alert alert-error"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
        </div>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['warning'])): ?>
        <div class="container">
            <div class="alert alert-info"><?php echo $_SESSION['warning']; unset($_SESSION['warning']); ?></div>
        </div>
    <?php endif; ?>
    
    <!-- Main Content -->
    <?php if ($page == 'home'): ?>
        <!-- Hero Section (same as before) -->
        <section class="hero">
            <h1>Need a Plumber? We're Here to Help!</h1>
            <p>Fast, reliable, and professional plumbing services at your doorstep</p>
            <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']): ?>
                <a href="?page=request" class="cta-button">
                    <i class="fas fa-wrench"></i> Request Service Now
                </a>
            <?php else: ?>
                <a href="?page=register" class="cta-button">
                    <i class="fas fa-user-plus"></i> Get Started
                </a>
            <?php endif; ?>
        </section>
        
        <!-- Features (same as before) -->
        <div class="container">
            <div class="features-grid">
                <div class="feature-card">
                    <i class="fas fa-clock"></i>
                    <h3>24/7 Emergency Service</h3>
                    <p>Round-the-clock availability for your plumbing emergencies.</p>
                </div>
                <div class="feature-card">
                    <i class="fas fa-map-marker-alt"></i>
                    <h3>Nearby Plumbers</h3>
                    <p>Find the nearest available plumbers in your area.</p>
                </div>
                <div class="feature-card">
                    <i class="fas fa-hand-holding-usd"></i>
                    <h3>Transparent Pricing</h3>
                    <p>Get upfront cost estimates with no hidden fees.</p>
                </div>
            </div>
        </div>
        
    <?php elseif ($page == 'register'): ?>
        <!-- Registration Page -->
        <div class="auth-container">
            <div class="auth-box">
                <div class="auth-header">
                    <i class="fas fa-user-plus"></i>
                    <h2>Create an Account</h2>
                    <p>Join Tubero Management System today</p>
                </div>
                
                <form method="POST" onsubmit="return validatePassword()">
                    <input type="hidden" name="action" value="register">
                    
                    <div class="form-group">
                        <label><i class="fas fa-user"></i> Full Name *</label>
                        <input type="text" name="full_name" required placeholder="Enter your full name">
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-envelope"></i> Email Address *</label>
                        <input type="email" name="email" required placeholder="you@example.com">
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-phone"></i> Contact Number</label>
                        <input type="text" name="contact" placeholder="e.g., 09123456789">
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-map-marker-alt"></i> Address</label>
                        <textarea name="address" placeholder="Your complete address"></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-lock"></i> Password *</label>
                        <input type="password" name="password" id="password" required placeholder="Min. 8 characters">
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-lock"></i> Confirm Password *</label>
                        <input type="password" name="confirm_password" id="confirm_password" required>
                    </div>
                    
                    <div class="password-requirements">
                        <p>Password must contain:</p>
                        <ul>
                            <li id="length-check"><i class="fas fa-times"></i> At least 8 characters</li>
                            <li id="uppercase-check"><i class="fas fa-times"></i> At least 1 uppercase letter</li>
                            <li id="number-check"><i class="fas fa-times"></i> At least 1 number</li>
                            <li id="match-check"><i class="fas fa-times"></i> Passwords match</li>
                        </ul>
                    </div>
                    
                    
                    <button type="submit" class="btn">Create Account</button>
                    
                    <p style="text-align: center; margin-top: 1.5rem;">
                        Already have an account? <a href="?page=login" style="color: #667eea;">Login here</a>
                    </p>
                </form>
            </div>
        </div>
        
        <script>
            function validatePassword() {
                const password = document.getElementById('password').value;
                const confirm = document.getElementById('confirm_password').value;
                
                if (password !== confirm) {
                    alert('Passwords do not match!');
                    return false;
                }
                return true;
            }
            
            // Real-time password validation
            document.getElementById('password').addEventListener('input', checkPassword);
            document.getElementById('confirm_password').addEventListener('input', checkPassword);
            
            function checkPassword() {
                const password = document.getElementById('password').value;
                const confirm = document.getElementById('confirm_password').value;
                
                // Length check
                const lengthCheck = document.getElementById('length-check');
                if (password.length >= 8) {
                    lengthCheck.innerHTML = '<i class="fas fa-check" style="color: #28a745;"></i> At least 8 characters';
                    lengthCheck.style.color = '#28a745';
                } else {
                    lengthCheck.innerHTML = '<i class="fas fa-times" style="color: #dc3545;"></i> At least 8 characters';
                    lengthCheck.style.color = '#666';
                }
                
                // Uppercase check
                const upperCheck = document.getElementById('uppercase-check');
                if (/[A-Z]/.test(password)) {
                    upperCheck.innerHTML = '<i class="fas fa-check" style="color: #28a745;"></i> At least 1 uppercase letter';
                    upperCheck.style.color = '#28a745';
                } else {
                    upperCheck.innerHTML = '<i class="fas fa-times" style="color: #dc3545;"></i> At least 1 uppercase letter';
                    upperCheck.style.color = '#666';
                }
                
                // Number check
                const numberCheck = document.getElementById('number-check');
                if (/[0-9]/.test(password)) {
                    numberCheck.innerHTML = '<i class="fas fa-check" style="color: #28a745;"></i> At least 1 number';
                    numberCheck.style.color = '#28a745';
                } else {
                    numberCheck.innerHTML = '<i class="fas fa-times" style="color: #dc3545;"></i> At least 1 number';
                    numberCheck.style.color = '#666';
                }
                
                // Match check
                const matchCheck = document.getElementById('match-check');
                if (password && confirm && password === confirm) {
                    matchCheck.innerHTML = '<i class="fas fa-check" style="color: #28a745;"></i> Passwords match';
                    matchCheck.style.color = '#28a745';
                } else {
                    matchCheck.innerHTML = '<i class="fas fa-times" style="color: #dc3545;"></i> Passwords match';
                    matchCheck.style.color = '#666';
                }
            }
        </script>
        
    <?php elseif ($page == 'login'): ?>
        <!-- Login Page -->
        <div class="auth-container">
            <div class="auth-box">
                <div class="auth-header">
                    <i class="fas fa-sign-in-alt"></i>
                    <h2>Welcome Back</h2>
                    <p>Login to your account</p>
                </div>
                
                <form method="POST">
                    <input type="hidden" name="action" value="login">
                    
                    <div class="form-group">
                        <label><i class="fas fa-envelope"></i> Email Address</label>
                        <input type="email" name="email" required placeholder="Enter your email" 
                               value="<?php echo isset($_SESSION['email']) ? htmlspecialchars($_SESSION['email']) : ''; ?>">
                        <?php unset($_SESSION['email']); ?>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-lock"></i> Password</label>
                        <input type="password" name="password" required placeholder="Enter your password">
                    </div>
                    
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
                        <label style="display: flex; align-items: center; gap: 0.3rem;">
                            <input type="checkbox" name="remember"> Remember me
                        </label>
                        <a href="?page=forgot_password" style="color: #667eea;">Forgot Password?</a>
                    </div>
                    
                    <button type="submit" class="btn">Login</button>
                    
                    <p style="text-align: center; margin-top: 1.5rem;">
                        Don't have an account? <a href="?page=register" style="color: #667eea;">Register here</a>
                    </p>
                </form>
            </div>
        </div>
        
    <?php elseif ($page == 'forgot_password'): ?>
        <!-- Forgot Password Page -->
        <div class="auth-container">
            <div class="auth-box">
                <div class="auth-header">
                    <i class="fas fa-key"></i>
                    <h2>Forgot Password</h2>
                    <p>Enter your email to reset your password</p>
                </div>
                
                <form method="POST">
                    <input type="hidden" name="action" value="forgot_password">
                    
                    <div class="form-group">
                        <label><i class="fas fa-envelope"></i> Email Address</label>
                        <input type="email" name="email" required placeholder="Enter your registered email">
                    </div>
                    
                    <button type="submit" class="btn">Send Reset Link</button>
                    
                    <p style="text-align: center; margin-top: 1.5rem;">
                        <a href="?page=login" style="color: #667eea;">Back to Login</a>
                    </p>
                </form>
            </div>
        </div>
        
    <?php elseif ($page == 'reset_password' && isset($_GET['token'])): ?>
        <!-- Reset Password Page -->
        <div class="auth-container">
            <div class="auth-box">
                <div class="auth-header">
                    <i class="fas fa-lock"></i>
                    <h2>Reset Password</h2>
                    <p>Enter your new password</p>
                </div>
                
                <form method="POST">
                    <input type="hidden" name="action" value="reset_password">
                    <input type="hidden" name="token" value="<?php echo htmlspecialchars($_GET['token']); ?>">
                    
                    <div class="form-group">
                        <label><i class="fas fa-lock"></i> New Password</label>
                        <input type="password" name="password" required placeholder="Min. 8 characters">
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-lock"></i> Confirm New Password</label>
                        <input type="password" name="confirm_password" required>
                    </div>
                    
                    <button type="submit" class="btn">Reset Password</button>
                </form>
            </div>
        </div>
        
    <?php elseif ($page == 'resend_verification' && isset($_GET['email'])): ?>
        <!-- Resend Verification Page -->
        <div class="auth-container">
            <div class="auth-box">
                <div class="auth-header">
                    <i class="fas fa-envelope"></i>
                    <h2>Resend Verification</h2>
                    <p>Resend verification email</p>
                </div>
                
                <form method="POST">
                    <input type="hidden" name="action" value="resend_verification">
                    <input type="hidden" name="email" value="<?php echo htmlspecialchars($_GET['email']); ?>">
                    
                    <p style="text-align: center; margin-bottom: 1.5rem;">
                        Click the button below to resend the verification email to:<br>
                        <strong><?php echo htmlspecialchars($_GET['email']); ?></strong>
                    </p>
                    
                    <button type="submit" class="btn">Resend Verification Email</button>
                    
                    <p style="text-align: center; margin-top: 1.5rem;">
                        <a href="?page=login" style="color: #667eea;">Back to Login</a>
                    </p>
                </form>
            </div>
        </div>
        
    <?php elseif ($page == 'dashboard' && isset($_SESSION['logged_in'])): ?>
        <!-- User Dashboard -->
        <div class="container">
            <h1 style="margin-bottom: 2rem;">Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!</h1>
            
            <div class="dashboard-grid">
                <div class="dashboard-card">
                    <h3><i class="fas fa-clipboard-list"></i> Recent Requests</h3>
                    <?php
                    $userId = $_SESSION['user_id'];
                    $requests = $conn->query("SELECT * FROM service_requests WHERE user_id = $userId ORDER BY request_date DESC LIMIT 5");
                    
                    if ($requests->num_rows > 0):
                    ?>
                        <ul class="request-list">
                            <?php while ($request = $requests->fetch_assoc()): ?>
                                <li class="request-list-item">
                                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
                                        <span style="font-weight: 600;"><?php echo htmlspecialchars($request['reference_number']); ?></span>
                                        <span class="request-status status-<?php echo $request['status']; ?>">
                                            <?php echo ucfirst(str_replace('_', ' ', $request['status'])); ?>
                                        </span>
                                    </div>
                                    <div style="color: #666; font-size: 0.9rem;">
                                        <i class="fas fa-calendar"></i> <?php echo date('M d, Y', strtotime($request['request_date'])); ?>
                                    </div>
                                </li>
                            <?php endwhile; ?>
                        </ul>
                        <a href="?page=history" style="display: block; text-align: center; margin-top: 1rem; color: #667eea;">
                            View All Requests <i class="fas fa-arrow-right"></i>
                        </a>
                    <?php else: ?>
                        <p style="text-align: center; color: #666; padding: 2rem;">
                            No service requests yet.<br>
                            <a href="?page=request" style="color: #667eea;">Request a plumber now!</a>
                        </p>
                    <?php endif; ?>
                </div>
                
                <div class="dashboard-card">
                    <h3><i class="fas fa-user"></i> Profile Summary</h3>
                    <?php
                    $user = $conn->query("SELECT * FROM users WHERE id = $userId")->fetch_assoc();
                    ?>
                    <div style="margin-bottom: 1rem;">
                        <div style="color: #666; font-size: 0.9rem;">Email</div>
                        <div style="font-weight: 500;"><?php echo htmlspecialchars($user['email']); ?></div>
                    </div>
                    <div style="margin-bottom: 1rem;">
                        <div style="color: #666; font-size: 0.9rem;">Contact</div>
                        <div style="font-weight: 500;"><?php echo htmlspecialchars($user['contact_number'] ?: 'Not provided'); ?></div>
                    </div>
                    <div style="margin-bottom: 1rem;">
                        <div style="color: #666; font-size: 0.9rem;">Member Since</div>
                        <div style="font-weight: 500;"><?php echo date('F d, Y', strtotime($user['created_at'])); ?></div>
                    </div>
                    <a href="?page=profile" class="btn" style="display: block; text-align: center;">Edit Profile</a>
                </div>
                
                <div class="dashboard-card">
                    <h3><i class="fas fa-chart-bar"></i> Quick Stats</h3>
                    <?php
                    $totalRequests = $conn->query("SELECT COUNT(*) as count FROM service_requests WHERE user_id = $userId")->fetch_assoc()['count'];
                    $completedRequests = $conn->query("SELECT COUNT(*) as count FROM service_requests WHERE user_id = $userId AND status = 'completed'")->fetch_assoc()['count'];
                    $pendingRequests = $conn->query("SELECT COUNT(*) as count FROM service_requests WHERE user_id = $userId AND status = 'pending'")->fetch_assoc()['count'];
                    ?>
                    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 1rem; text-align: center;">
                        <div>
                            <div style="font-size: 2rem; font-weight: bold; color: #667eea;"><?php echo $totalRequests; ?></div>
                            <div style="color: #666;">Total</div>
                        </div>
                        <div>
                            <div style="font-size: 2rem; font-weight: bold; color: #28a745;"><?php echo $completedRequests; ?></div>
                            <div style="color: #666;">Completed</div>
                        </div>
                        <div>
                            <div style="font-size: 2rem; font-weight: bold; color: #ffc107;"><?php echo $pendingRequests; ?></div>
                            <div style="color: #666;">Pending</div>
                        </div>
                        <div>
                            <div style="font-size: 2rem; font-weight: bold; color: #17a2b8;"><?php echo $totalRequests - $completedRequests - $pendingRequests; ?></div>
                            <div style="color: #666;">Other</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    <?php elseif ($page == 'profile' && isset($_SESSION['logged_in'])): ?>
        <!-- Profile Page -->
        <div class="container">
            <div class="profile-container">
                <div class="profile-header">
                    <div class="profile-avatar">
                        <i class="fas fa-user"></i>
                    </div>
                    <h2><?php echo htmlspecialchars($_SESSION['user_name']); ?></h2>
                    <p>Member since <?php 
                        $user = $conn->query("SELECT created_at FROM users WHERE id = " . $_SESSION['user_id'])->fetch_assoc();
                        echo date('F Y', strtotime($user['created_at']));
                    ?></p>
                </div>
                
                <div class="profile-content">
                    <?php
                    $user = $conn->query("SELECT * FROM users WHERE id = " . $_SESSION['user_id'])->fetch_assoc();
                    ?>
                    
                    <form method="POST" action="update_profile.php" id="profileForm">
                        <div class="info-group">
                            <div class="info-label">Full Name</div>
                            <input type="text" class="form-control" value="<?php echo htmlspecialchars($user['full_name']); ?>" readonly>
                        </div>
                        
                        <div class="info-group">
                            <div class="info-label">Email Address</div>
                            <input type="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" readonly>
                            <?php if ($user['email_verified']): ?>
                                <span style="color: #28a745; font-size: 0.9rem;"><i class="fas fa-check-circle"></i> Verified</span>
                            <?php else: ?>
                                <span style="color: #ffc107; font-size: 0.9rem;">
                                    <i class="fas fa-exclamation-triangle"></i> Not verified 
                                    <a href="?page=resend_verification&email=<?php echo urlencode($user['email']); ?>" style="color: #667eea;">Resend verification</a>
                                </span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="info-group">
                            <div class="info-label">Contact Number</div>
                            <input type="text" class="form-control" value="<?php echo htmlspecialchars($user['contact_number'] ?: 'Not provided'); ?>" readonly>
                        </div>
                        
                        <div class="info-group">
                            <div class="info-label">Address</div>
                            <textarea class="form-control" readonly><?php echo htmlspecialchars($user['address'] ?: 'Not provided'); ?></textarea>
                        </div>
                        
                        <div class="info-group">
                            <div class="info-label">Last Login</div>
                            <input type="text" class="form-control" value="<?php echo $user['last_login'] ? date('F d, Y h:i A', strtotime($user['last_login'])) : 'First time login'; ?>" readonly>
                        </div>
                        
                        <hr style="margin: 2rem 0;">
                        
                        <h3 style="margin-bottom: 1rem;">Change Password</h3>
                        
                        <div class="form-group">
                            <label>Current Password</label>
                            <input type="password" name="current_password" class="form-control">
                        </div>
                        
                        <div class="form-group">
                            <label>New Password</label>
                            <input type="password" name="new_password" class="form-control">
                        </div>
                        
                        <div class="form-group">
                            <label>Confirm New Password</label>
                            <input type="password" name="confirm_new_password" class="form-control">
                        </div>
                        
                        <button type="submit" class="btn" style="width: auto;">Update Password</button>
                    </form>
                </div>
            </div>
        </div>
        
    <?php elseif ($page == 'history' && isset($_SESSION['logged_in'])): ?>
        <!-- Request History -->
        <div class="container">
            <h2 style="margin-bottom: 2rem;">My Service Requests</h2>
            
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Reference #</th>
                            <th>Date</th>
                            <th>Location</th>
                            <th>Problem</th>
                            <th>Status</th>
                            <th>Est. Cost</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $userId = $_SESSION['user_id'];
                        $requests = $conn->query("SELECT sr.*, p.full_name as plumber_name FROM service_requests sr LEFT JOIN plumbers p ON sr.assigned_plumber_id = p.id WHERE sr.user_id = $userId ORDER BY sr.request_date DESC");
                        
                        if ($requests->num_rows > 0):
                            while ($request = $requests->fetch_assoc()):
                        ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($request['reference_number']); ?></strong></td>
                                <td><?php echo date('M d, Y', strtotime($request['request_date'])); ?></td>
                                <td><?php echo htmlspecialchars($request['location_area']); ?></td>
                                <td><?php echo substr(htmlspecialchars($request['problem_description']), 0, 50) . '...'; ?></td>
                                <td>
                                    <span class="request-status status-<?php echo $request['status']; ?>">
                                        <?php echo ucfirst(str_replace('_', ' ', $request['status'])); ?>
                                    </span>
                                </td>
                                <td>₱<?php echo $request['estimated_cost'] ? number_format($request['estimated_cost'], 2) : 'Pending'; ?></td>
                                <td>
                                    <a href="?page=track&ref=<?php echo $request['reference_number']; ?>" class="btn" style="padding: 0.5rem 1rem; font-size: 0.9rem;">
                                        <i class="fas fa-eye"></i> View
                                    </a>
                                </td>
                            </tr>
                        <?php
                            endwhile;
                        else:
                        ?>
                            <tr>
                                <td colspan="7" style="text-align: center; padding: 3rem;">
                                    <i class="fas fa-clipboard-list" style="font-size: 3rem; color: #ddd; margin-bottom: 1rem;"></i>
                                    <p>No service requests found.</p>
                                    <a href="?page=request" class="btn" style="margin-top: 1rem;">Request a Plumber</a>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
    <?php elseif ($page == 'request'): ?>
        <!-- Service Request Form (updated to include user info if logged in) -->
        <div class="container">
            <div class="form-container">
                <h2><i class="fas fa-tools"></i> Request Plumbing Service</h2>
                
                <?php if (!isset($_SESSION['logged_in'])): ?>
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle"></i> 
                        Please <a href="?page=login" style="color: #667eea; font-weight: 600;">login</a> or 
                        <a href="?page=register" style="color: #667eea; font-weight: 600;">register</a> to track your requests easily.
                    </div>
                <?php endif; ?>
                
                <form method="POST">
                    <input type="hidden" name="action" value="submit_request">
                    
                    <div class="form-group">
                        <label><i class="fas fa-user"></i> Full Name *</label>
                        <input type="text" name="name" required placeholder="Enter your full name"
                               value="<?php echo isset($_SESSION['user_name']) ? htmlspecialchars($_SESSION['user_name']) : ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-phone"></i> Contact Number *</label>
                        <input type="text" name="contact" required placeholder="e.g., 09123456789"
                               value="<?php 
                                   if (isset($_SESSION['user_id'])) {
                                       $user = $conn->query("SELECT contact_number FROM users WHERE id = " . $_SESSION['user_id'])->fetch_assoc();
                                       echo htmlspecialchars($user['contact_number'] ?? '');
                                   }
                               ?>">
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-map-marker-alt"></i> Complete Address *</label>
                        <textarea name="address" required placeholder="House/Unit No., Street, Barangay, City/Municipality"><?php 
                            if (isset($_SESSION['user_id'])) {
                                $user = $conn->query("SELECT address FROM users WHERE id = " . $_SESSION['user_id'])->fetch_assoc();
                                echo htmlspecialchars($user['address'] ?? '');
                            }
                        ?></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-location-dot"></i> Location Area *</label>
                        <select name="area" required>
                            <option value="">Select your area</option>
                            <option value="Metro Manila">Metro Manila</option>
                            <option value="Quezon City">Quezon City</option>
                            <option value="Makati">Makati</option>
                            <option value="Taguig">Taguig</option>
                            <option value="Pasig">Pasig</option>
                            <option value="Manila">Manila</option>
                            <option value="Cavite">Cavite</option>
                            <option value="Laguna">Laguna</option>
                            <option value="Rizal">Rizal</option>
                            <option value="Bulacan">Bulacan</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-exclamation-triangle"></i> Problem Description *</label>
                        <textarea name="problem" required placeholder="Describe your plumbing issue in detail..."></textarea>
                    </div>
                    
                    <button type="submit" class="btn">
                        <i class="fas fa-paper-plane"></i> Submit Request
                    </button>
                </form>
            </div>
        </div>
        
    <?php elseif ($page == 'track'): ?>
        <!-- Track Request (same as before, but now users can see their own requests easily) -->
        <div class="container">
            <div class="tracking-container">
                <h2 style="text-align: center; margin-bottom: 2rem;">
                    <i class="fas fa-search"></i> Track Your Service Request
                </h2>
                
                <?php if (isset($_SESSION['logged_in'])): ?>
                    <!-- Show user's recent requests -->
                    <div style="margin-bottom: 2rem;">
                        <h3>Your Recent Requests</h3>
                        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 1rem; margin-top: 1rem;">
                            <?php
                            $userId = $_SESSION['user_id'];
                            $recent = $conn->query("SELECT reference_number, status, request_date FROM service_requests WHERE user_id = $userId ORDER BY request_date DESC LIMIT 5");
                            while ($req = $recent->fetch_assoc()):
                            ?>
                                <a href="?page=track&ref=<?php echo $req['reference_number']; ?>" style="text-decoration: none;">
                                    <div style="background: #f8f9fa; padding: 1rem; border-radius: 5px; border: 1px solid #eee;">
                                        <div style="font-weight: 600; color: #333;"><?php echo $req['reference_number']; ?></div>
                                        <div style="font-size: 0.9rem; color: #666;"><?php echo date('M d, Y', strtotime($req['request_date'])); ?></div>
                                        <span class="request-status status-<?php echo $req['status']; ?>" style="margin-top: 0.5rem;">
                                            <?php echo ucfirst($req['status']); ?>
                                        </span>
                                    </div>
                                </a>
                            <?php endwhile; ?>
                        </div>
                    </div>
                <?php endif; ?>
                
                <!-- Search Form -->
                <form method="POST" style="max-width: 400px; margin: 2rem auto;">
                    <input type="hidden" name="action" value="track_request">
                    <div class="form-group" style="display: flex; gap: 0.5rem;">
                        <input type="text" name="reference" placeholder="Enter Reference Number (e.g., TUB-...)" 
                               value="<?php echo htmlspecialchars($_GET['ref'] ?? ''); ?>" required>
                        <button type="submit" class="btn" style="width: auto;">
                            <i class="fas fa-arrow-right"></i>
                        </button>
                    </div>
                </form>
                
                <?php
                if (isset($_GET['ref'])) {
                    $ref = $conn->real_escape_string($_GET['ref']);
                    $request = $conn->query("SELECT sr.*, p.full_name as plumber_name, p.contact_number as plumber_contact 
                                             FROM service_requests sr 
                                             LEFT JOIN plumbers p ON sr.assigned_plumber_id = p.id 
                                             WHERE sr.reference_number = '$ref'")->fetch_assoc();
                    
                    if ($request):
                        // Check if this request belongs to logged-in user or allow public tracking
                        if (isset($_SESSION['logged_in']) && $request['user_id'] && $request['user_id'] != $_SESSION['user_id']) {
                            echo '<div class="alert alert-error">You do not have permission to view this request.</div>';
                        } else {
                ?>
                        <!-- Status Timeline (same as before) -->
                        <div class="status-timeline">
                            <?php
                            $statuses = ['pending', 'assigned', 'in_progress', 'completed'];
                            $currentStatus = $request['status'];
                            $currentIndex = array_search($currentStatus, $statuses);
                            
                            foreach ($statuses as $index => $status):
                                $statusClass = '';
                                if ($index < $currentIndex) $statusClass = 'completed';
                                elseif ($index == $currentIndex) $statusClass = 'active';
                            ?>
                                <div class="status-step <?php echo $statusClass; ?>">
                                    <div class="step-icon">
                                        <?php
                                        switch($status) {
                                            case 'pending': echo '<i class="fas fa-clock"></i>'; break;
                                            case 'assigned': echo '<i class="fas fa-user-check"></i>'; break;
                                            case 'in_progress': echo '<i class="fas fa-wrench"></i>'; break;
                                            case 'completed': echo '<i class="fas fa-check"></i>'; break;
                                        }
                                        ?>
                                    </div>
                                    <div class="step-label"><?php echo ucfirst(str_replace('_', ' ', $status)); ?></div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <!-- Request Details -->
                        <div class="request-details">
                            <h3>Request Details</h3>
                            <div class="detail-row">
                                <span class="detail-label">Reference:</span>
                                <span class="detail-value"><?php echo htmlspecialchars($request['reference_number']); ?></span>
                            </div>
                            <div class="detail-row">
                                <span class="detail-label">Customer:</span>
                                <span class="detail-value"><?php echo htmlspecialchars($request['customer_name']); ?></span>
                            </div>
                            <div class="detail-row">
                                <span class="detail-label">Contact:</span>
                                <span class="detail-value"><?php echo htmlspecialchars($request['customer_contact']); ?></span>
                            </div>
                            <div class="detail-row">
                                <span class="detail-label">Location:</span>
                                <span class="detail-value"><?php echo htmlspecialchars($request['location_area']); ?></span>
                            </div>
                            <div class="detail-row">
                                <span class="detail-label">Problem:</span>
                                <span class="detail-value"><?php echo htmlspecialchars($request['problem_description']); ?></span>
                            </div>
                            <div class="detail-row">
                                <span class="detail-label">Request Date:</span>
                                <span class="detail-value"><?php echo date('F d, Y h:i A', strtotime($request['request_date'])); ?></span>
                            </div>
                            
                            <?php if ($request['assigned_plumber_id']): ?>
                                <hr style="margin: 1.5rem 0;">
                                <h3>Assigned Plumber</h3>
                                <div class="detail-row">
                                    <span class="detail-label">Name:</span>
                                    <span class="detail-value"><?php echo htmlspecialchars($request['plumber_name']); ?></span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label">Contact:</span>
                                    <span class="detail-value"><?php echo htmlspecialchars($request['plumber_contact']); ?></span>
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($request['estimated_cost']): ?>
                                <div class="detail-row" style="margin-top: 1rem;">
                                    <span class="detail-label">Estimated Cost:</span>
                                    <span class="detail-value" style="font-size: 1.2rem; color: #28a745; font-weight: bold;">
                                        ₱<?php echo number_format($request['estimated_cost'], 2); ?>
                                    </span>
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Action Buttons -->
                        <div style="display: flex; gap: 1rem; justify-content: center;">
                            <?php if ($request['status'] == 'completed'): ?>
                                <button class="btn" onclick="window.print()">
                                    <i class="fas fa-print"></i> Print Receipt
                                </button>
                            <?php endif; ?>
                            <a href="?page=request" class="btn btn-outline">
                                <i class="fas fa-plus"></i> New Request
                            </a>
                        </div>
                <?php
                        }
                    else:
                        echo '<div class="alert alert-error">Request not found. Please check your reference number.</div>';
                    endif;
                }
                ?>
            </div>
        </div>
        
    <?php elseif ($page == 'plumbers'): ?>
        <!-- Find Plumbers (same as before) -->
        <div class="container">
            <h2 style="text-align: center; margin-bottom: 2rem;">
                <i class="fas fa-users"></i> Available Plumbers Near You
            </h2>
            
            <!-- Search and Filter -->
            <div class="form-container" style="max-width: 400px; margin-bottom: 2rem;">
                <form method="GET">
                    <input type="hidden" name="page" value="plumbers">
                    <div class="form-group">
                        <label>Search by Location</label>
                        <select name="area">
                            <option value="">All Areas</option>
                            <option value="Metro Manila">Metro Manila</option>
                            <option value="Quezon City">Quezon City</option>
                            <option value="Makati">Makati</option>
                            <option value="Taguig">Taguig</option>
                            <option value="Cavite">Cavite</option>
                            <option value="Laguna">Laguna</option>
                        </select>
                    </div>
                    <button type="submit" class="btn">Search</button>
                </form>
            </div>
            
            <!-- Plumbers List -->
            <div class="plumber-grid">
                <?php
                $areaFilter = isset($_GET['area']) && $_GET['area'] != '' ? "WHERE service_area LIKE '%" . $conn->real_escape_string($_GET['area']) . "%'" : "WHERE 1=1";
                $plumbers = $conn->query("SELECT * FROM plumbers $areaFilter AND availability = 1 ORDER BY hourly_rate ASC");
                
                if ($plumbers->num_rows > 0):
                    while ($plumber = $plumbers->fetch_assoc()):
                ?>
                        <div class="plumber-card">
                            <h3><i class="fas fa-user"></i> <?php echo htmlspecialchars($plumber['full_name']); ?></h3>
                            <div class="role"><?php echo htmlspecialchars($plumber['role']); ?></div>
                            <div class="details">
                                <i class="fas fa-map-marker-alt"></i>
                                <span><?php echo htmlspecialchars($plumber['service_area']); ?></span>
                            </div>
                            <div class="details">
                                <i class="fas fa-phone"></i>
                                <span><?php echo htmlspecialchars($plumber['contact_number']); ?></span>
                            </div>
                            <?php if ($plumber['email']): ?>
                            <div class="details">
                                <i class="fas fa-envelope"></i>
                                <span><?php echo htmlspecialchars($plumber['email']); ?></span>
                            </div>
                            <?php endif; ?>
                            <div class="rate">
                                <i class="fas fa-tag"></i> ₱<?php echo number_format($plumber['hourly_rate'], 2); ?>/hour
                            </div>
                            <div class="details">
                                <i class="fas fa-car"></i>
                                <span>Travel Fee: ₱<?php echo number_format($plumber['travel_fee_per_km'], 2); ?>/km</span>
                            </div>
                            <a href="?page=request" class="btn" style="margin-top: 1rem;">
                                <i class="fas fa-calendar-check"></i> Book This Plumber
                            </a>
                        </div>
                <?php
                    endwhile;
                else:
                    echo '<div class="alert alert-info" style="grid-column: 1/-1;">No plumbers found in this area. Please try another location.</div>';
                endif;
                ?>
            </div>
        </div>
        
    <?php elseif ($page == 'success'): ?>
        <!-- Success Page (same as before) -->
        <div class="container">
            <div class="form-container" style="text-align: center;">
                <i class="fas fa-check-circle" style="font-size: 5rem; color: #28a745; margin-bottom: 1rem;"></i>
                <h2>Request Submitted Successfully!</h2>
                
                <?php if (isset($_SESSION['success'])): ?>
                    <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
                <?php endif; ?>
                
                <div style="background: #f8f9fa; padding: 1.5rem; border-radius: 5px; margin: 2rem 0;">
                    <p style="font-size: 1.2rem; margin-bottom: 0.5rem;">Your Reference Number:</p>
                    <h3 style="color: #667eea; font-size: 2rem; letter-spacing: 2px;"><?php echo $_SESSION['reference'] ?? ''; ?></h3>
                </div>
                
                <p style="margin-bottom: 2rem;">Please save this reference number to track your request status.</p>
                
                <div style="display: flex; gap: 1rem; justify-content: center;">
                    <?php if (isset($_SESSION['logged_in'])): ?>
                        <a href="?page=dashboard" class="btn" style="width: auto;">
                            <i class="fas fa-tachometer-alt"></i> Go to Dashboard
                        </a>
                    <?php endif; ?>
                    <a href="?page=track&ref=<?php echo $_SESSION['reference'] ?? ''; ?>" class="btn" style="width: auto;">
                        <i class="fas fa-search"></i> Track Request
                    </a>
                    <a href="?page=request" class="btn btn-outline" style="width: auto;">
                        <i class="fas fa-plus"></i> New Request
                    </a>
                </div>
            </div>
        </div>
        
    <?php endif; ?>
    
    <!-- Footer -->
    <footer class="footer">
        <p>&copy; 2024 Tubero Management System. All rights reserved.</p>
        <p style="margin-top: 1rem; font-size: 0.9rem;">
            <i class="fas fa-phone"></i> Emergency Hotline: 0917-123-4567 |
            <i class="fas fa-envelope"></i> support@tubero.com
        </p>
    </footer>
</body>
</html>
<?php $conn->close(); ?>