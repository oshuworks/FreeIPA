<?php
// Snipe-IT v24.04 LTS - Complete Asset Management System
// Single file implementation with MySQL database
// Fixed for Linux Ubuntu

session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database Configuration - Update these for your Ubuntu system
$db_host = 'localhost';
$db_name = 'snipeit_db';
$db_user = 'root';  // Change this if you have a different MySQL user
$db_pass = '';      // Add your MySQL password here

// Create database connection with error handling
try {
    // First, connect without selecting a database
    $pdo = new PDO("mysql:host=$db_host;charset=utf8mb4", $db_user, $db_pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    
    // Create database if not exists
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `$db_name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $pdo->exec("USE `$db_name`");
    
    // Create tables
    createTables($pdo);
    
} catch(PDOException $e) {
    // More user-friendly error message
    if ($e->getCode() == 1045) {
        die("<h3>Connection failed: Access denied for user</h3>
             <p>Please check your MySQL username and password in the configuration.</p>
             <p><strong>For Ubuntu:</strong> If you're using default MySQL installation, try:</p>
             <ul>
                 <li>Username: root</li>
                 <li>Password: (leave empty if no password set)</li>
             </ul>
             <p>Or create a new database user:</p>
             <pre>
             sudo mysql
             CREATE USER 'snipeit'@'localhost' IDENTIFIED BY 'your_password';
             GRANT ALL PRIVILEGES ON snipeit_db.* TO 'snipeit'@'localhost';
             FLUSH PRIVILEGES;
             EXIT;
             </pre>
             <p><strong>Error details:</strong> " . $e->getMessage() . "</p>");
    } else {
        die("<h3>Database Error</h3>
             <p><strong>Message:</strong> " . $e->getMessage() . "</p>
             <p><strong>Code:</strong> " . $e->getCode() . "</p>");
    }
}

// Main Application Logic
$action = isset($_GET['action']) ? preg_replace('/[^a-zA-Z0-9_]/', '', $_GET['action']) : 'dashboard';
$module = isset($_GET['module']) ? preg_replace('/[^a-zA-Z0-9_]/', '', $_GET['module']) : '';

// Authentication check
if(!isset($_SESSION['user_id']) && !in_array($action, ['login', 'install', 'ajax'])) {
    header('Location: ?action=login');
    exit;
}

// Handle AJAX requests
if(isset($_GET['ajax'])) {
    handleAjaxRequest($pdo);
    exit;
}

// Handle form submissions
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    handlePostRequest($pdo);
}

// Render the page
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Snipe-IT v24.04 LTS - Asset Management System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">
    <style>
        :root {
            --primary-color: #2C3E50;
            --secondary-color: #F39C12;
            --danger-color: #E74C3C;
            --warning-color: #F1C40F;
            --info-color: #3498DB;
            --success-color: #27AE60;
            --light-gray: #ECF0F1;
            --medium-gray: #7F8C8D;
            --off-white: #F8F9FA;
            --dark-slate: #1A252F;
        }
        
        body {
            background-color: var(--off-white);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .navbar-brand {
            font-weight: 600;
            color: var(--secondary-color) !important;
        }
        
        .sidebar-logo {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 10px 0;
            border-bottom: 2px solid rgba(255,255,255,0.2);
            margin-bottom: 15px;
        }
        
        .sidebar-logo img {
            filter: drop-shadow(0 2px 4px rgba(255,255,255,0.2));
        }
        
        .sidebar {
            min-height: 100vh;
            background: var(--primary-color);
            color: white;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            transition: all 0.3s;
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 0.8rem 1rem;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover {
            background: rgba(255,255,255,0.1);
            color: white;
            padding-left: 1.5rem;
        }
        
        .sidebar .nav-link.active {
            background: var(--secondary-color);
            color: #1a1a1a;
            font-weight: 600;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
        }
        
        .main-content {
            padding: 20px;
        }
        
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            transition: transform 0.2s;
        }
        
        .card:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
        }
        
        .card-header {
            background: var(--light-gray);
            border-bottom: 2px solid #f0f0f0;
            font-weight: 600;
            border-radius: 10px 10px 0 0 !important;
        }
        
        .stat-card {
            background: linear-gradient(45deg, var(--primary-color), #34495E);
            color: white;
            position: relative;
            overflow: hidden;
        }
        
        .stat-card .card-body {
            padding: 20px;
        }
        
        .btn-primary {
            background: var(--primary-color) !important;
            border-color: var(--primary-color) !important;
        }
        
        .btn-primary:hover {
            background: #1a2332 !important;
            border-color: #1a2332 !important;
            box-shadow: 0 4px 12px rgba(44, 62, 80, 0.3);
        }
        
        .btn-success {
            background: var(--success-color) !important;
            border-color: var(--success-color) !important;
        }
        
        .btn-success:hover {
            background: #1e8449 !important;
            border-color: #1e8449 !important;
        }
        
        .btn-danger {
            background: var(--danger-color) !important;
            border-color: var(--danger-color) !important;
        }
        
        .btn-warning {
            background: var(--warning-color) !important;
            border-color: var(--warning-color) !important;
            color: black !important;
        }
        
        .btn-warning:hover {
            background: #d4a600 !important;
            border-color: #d4a600 !important;
        }
        
        .btn-info {
            background: var(--info-color) !important;
            border-color: var(--info-color) !important;
        }
        
        .stat-icon {
            font-size: 48px;
            opacity: 0.3;
            position: absolute;
            right: 20px;
            top: 20px;
        }
        
        .btn-action {
            margin: 2px;
            border-radius: 20px;
            padding: 5px 15px;
            font-size: 0.875rem;
        }
        
        .table th {
            background: var(--light-gray);
            border-bottom: 2px solid #dee2e6;
            color: var(--primary-color);
        }
        
        .badge-status {
            padding: 5px 10px;
            border-radius: 20px;
            font-weight: 500;
            font-size: 0.75rem;
        }
        
        .badge-available { background: var(--success-color); color: white; }
        .badge-assigned { background: var(--danger-color); color: white; }
        .badge-deployed { background: var(--warning-color); color: black; }
        .badge-maintenance { background: var(--warning-color); color: black; }
        .badge-retired { background: var(--medium-gray); color: white; }
        
        .search-box {
            border-radius: 30px;
            padding: 10px 20px;
            border: 2px solid #e0e0e0;
            transition: all 0.3s;
            width: 100%;
        }
        
        .search-box:focus {
            border-color: var(--secondary-color);
            box-shadow: none;
            outline: none;
        }
        
        .form-control:focus,
        .form-select:focus {
            border-color: var(--secondary-color);
            box-shadow: 0 0 0 0.2rem rgba(243, 156, 18, 0.25);
        }
        
        .form-control,
        .form-select {
            border-color: #ddd;
        }
        
        .form-label {
            color: var(--primary-color);
            font-weight: 500;
        }
        
        .qr-container {
            text-align: center;
            padding: 20px;
        }
        
        .qr-code {
            max-width: 200px;
            margin: 0 auto;
        }
        
        .toast-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            /* container sits above page but should not block clicks */
            pointer-events: none;
        }
        /* allow interactive elements within individual toasts to receive clicks */
        .toast {
            pointer-events: auto;
        }
        
        .toast {
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            margin-bottom: 10px;
            min-width: 300px;
        }
        
        .toast.success {
            border-left: 4px solid var(--success-color);
        }
        
        .toast.error {
            border-left: 4px solid var(--danger-color);
        }
        
        .toast.warning {
            border-left: 4px solid var(--warning-color);
        }
        
        .toast.info {
            border-left: 4px solid var(--info-color);
        }
        
        .loading-spinner {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(0,0,0,0.1);
            border-radius: 50%;
            border-top-color: var(--secondary-color);
            animation: spin 1s ease-in-out infinite;
        }
        
        .badge {
            padding: 0.5rem 0.75rem;
            font-weight: 500;
        }
        
        .badge.bg-danger {
            background: var(--danger-color) !important;
        }
        
        .badge.bg-success {
            background: var(--success-color) !important;
        }
        
        .badge.bg-info {
            background: var(--info-color) !important;
        }
        
        .badge.bg-warning {
            background: var(--warning-color) !important;
            color: black;
        }
        
        .modal-header {
            background: var(--light-gray);
            border-bottom: 2px solid #dee2e6;
        }
        
        .modal-title {
            color: var(--primary-color);
            font-weight: 600;
        }
        
        a {
            color: var(--info-color);
            text-decoration: none;
        }
        
        a:hover {
            color: var(--secondary-color);
            text-decoration: underline;
        }
        
        .dropdown-item:hover {
            background: var(--light-gray);
            color: var(--primary-color);
        }
        
        /* Logo styling */
        .sidebar-logo img {
            transition: all 0.3s ease;
        }
        
        .sidebar-logo img:hover {
            transform: scale(1.05);
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        @media print {
            .sidebar, .navbar, .btn, .no-print, .modal, .toast-container {
                display: none !important;
            }
            .main-content {
                margin: 0 !important;
                padding: 0 !important;
            }
        }
    </style>
</head>
<body>
    <div class="toast-container" id="toastContainer"></div>
    
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <?php if(isset($_SESSION['user_id'])): ?>
            <div class="col-md-2 p-0 sidebar">
                <div class="p-3">
                    <div class="sidebar-logo">
                        <img src="main_logo.png" alt="Snipe-IT Logo" class="img-fluid" style="max-height: 100px; width: auto; border-radius: 50%; object-fit: cover;">
                    </div>
                    <h5 class="text-center text-white mb-4">Snipe-IT</h5>
                    <nav class="nav flex-column">
                        <a class="nav-link <?php echo $action == 'dashboard' ? 'active' : ''; ?>" href="?action=dashboard">
                            <i class="fas fa-tachometer-alt"></i> Dashboard
                        </a>
                        <a class="nav-link <?php echo $action == 'assets' ? 'active' : ''; ?>" href="?action=assets">
                            <i class="fas fa-laptop"></i> Assets
                        </a>
                        <a class="nav-link <?php echo $action == 'licenses' ? 'active' : ''; ?>" href="?action=licenses">
                            <i class="fas fa-key"></i> Licenses
                        </a>
                        <a class="nav-link <?php echo $action == 'accessories' ? 'active' : ''; ?>" href="?action=accessories">
                            <i class="fas fa-mouse"></i> Accessories
                        </a>
                        <a class="nav-link <?php echo $action == 'consumables' ? 'active' : ''; ?>" href="?action=consumables">
                            <i class="fas fa-box"></i> Inventory
                        </a>
                        <a class="nav-link <?php echo $action == 'people' ? 'active' : ''; ?>" href="?action=people">
                            <i class="fas fa-users"></i> People
                        </a>
                        <a class="nav-link <?php echo $action == 'reports' ? 'active' : ''; ?>" href="?action=reports">
                            <i class="fas fa-chart-bar"></i> Reports
                        </a>
                        <a class="nav-link <?php echo $action == 'settings' ? 'active' : ''; ?>" href="?action=settings">
                            <i class="fas fa-cog"></i> Settings
                        </a>
                        <hr class="bg-white">
                        <a class="nav-link" href="?action=logout">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </nav>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Main Content -->
            <div class="col-md-<?php echo isset($_SESSION['user_id']) ? '10' : '12'; ?> p-0">
                <?php if(isset($_SESSION['user_id'])): ?>
                <?php
                    $unreadCount = 0;
                    if(isset($_SESSION['user_id'])) {
                        $stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND read_at IS NULL");
                        $stmt->execute([$_SESSION['user_id']]);
                        $unreadCount = $stmt->fetchColumn();
                        if(isset($action) && $action === 'notifications') {
                            // will be marked read later, avoid showing count in nav
                            $unreadCount = 0;
                        }
                    }
                ?>
                <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
                    <div class="container-fluid">
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarNav">
                            <ul class="navbar-nav ms-auto">
                                <li class="nav-item">
                                    <a class="nav-link position-relative" href="?action=notifications">
                                        <i class="fas fa-bell"></i>
                                        <?php if($unreadCount > 0): ?>
                                        <span class="badge bg-danger position-absolute top-0 start-100 translate-middle"><?php echo $unreadCount; ?></span>
                                        <?php endif; ?>
                                    </a>
                                </li>
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown">
                                        <i class="fas fa-user-circle"></i> <?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?>
                                        <?php if($_SESSION['user_role'] == 'admin'): ?>
                                        <span class="badge bg-danger ms-2">Admin</span>
                                        <?php endif; ?>
                                    </a>
                                    <ul class="dropdown-menu">
                                        <li><a class="dropdown-item" href="?action=profile"><i class="fas fa-id-card"></i> Profile</a></li>
                                        <li><a class="dropdown-item" href="?action=settings"><i class="fas fa-cog"></i> Settings</a></li>
                                        <li><hr class="dropdown-divider"></li>
                                        <li><a class="dropdown-item" href="?action=logout"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
                <?php endif; ?>
                
                <div class="main-content">
                    <?php
                    // Display flash messages
                    if(isset($_SESSION['success'])) {
                        echo '<script>showToast("success", "' . htmlspecialchars($_SESSION['success'] ?? '', ENT_QUOTES) . '");</script>';
                        unset($_SESSION['success']);
                    }
                    if(isset($_SESSION['error'])) {
                        echo '<script>showToast("error", "' . htmlspecialchars($_SESSION['error'] ?? '', ENT_QUOTES) . '");</script>';
                        unset($_SESSION['error']);
                    }
                    
                    // Route to appropriate page
                    switch($action) {
                        case 'login':
                            includeLoginPage($pdo);
                            break;
                        case 'logout':
                            session_destroy();
                            header('Location: ?action=login');
                            break;
                        case 'install':
                            includeInstallPage($pdo);
                            break;
                        case 'profile':
                            includeProfilePage($pdo);
                            break;
                        default:
                            includeMainContent($action, $pdo);
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js"></script>
    <script src="https://unpkg.com/html5-qrcode"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    
    <script>
        // Modal UX styles (inserted via server file for simplicity)
        (function(){
            const css = `
            .modal-body { max-height: 60vh; overflow-y: auto; }
            .modal .modal-spinner { display: none; margin-left:10px }
            .modal.loading .modal-spinner { display: inline-block; }
            .modal .modal-actions { display:flex; gap:8px; }
            `;
            const s = document.createElement('style'); s.appendChild(document.createTextNode(css)); document.head.appendChild(s);
        })();

        // Small helper to mark modal loading state and focus first input when shown
        function setModalLoading(modalEl, isLoading) {
            if(!modalEl) return;
            if(isLoading) modalEl.classList.add('loading'); else modalEl.classList.remove('loading');
        }

        function focusFirstInput(modalEl) {
            if(!modalEl) return;
            const el = modalEl.querySelector('input:not([type=hidden]), textarea, select');
            if(el) el.focus();
        }
        // Toast notification system
        function showToast(type, message) {
            const toast = document.createElement('div');
            toast.className = `toast ${type}`;
            toast.innerHTML = `
                <div class="toast-header">
                    <strong class="me-auto">${type.charAt(0).toUpperCase() + type.slice(1)}</strong>
                    <button type="button" class="btn-close" onclick="this.parentElement.parentElement.remove()"></button>
                </div>
                <div class="toast-body">
                    ${message}
                </div>
            `;
            document.getElementById('toastContainer').appendChild(toast);
            
            setTimeout(() => {
                toast.remove();
            }, 5000);
        }
        
        // Live search
        function liveSearch(input, targetSelector) {
            const filter = input.value.toLowerCase();
            const rows = document.querySelectorAll(targetSelector + ' tbody tr');
            
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(filter) ? '' : 'none';
            });
        }
        
        // Export to CSV
        function exportToCSV(tableId, filename) {
            const rows = document.querySelectorAll('#' + tableId + ' tr');
            const csv = [];
            
            rows.forEach(row => {
                const cols = row.querySelectorAll('td, th');
                const rowData = [];
                cols.forEach(col => {
                    let text = col.innerText.replace(/,/g, ';'); // Replace commas to avoid CSV issues
                    rowData.push('"' + text + '"');
                });
                csv.push(rowData.join(','));
            });
            
            const csvContent = csv.join('\n');
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            const url = URL.createObjectURL(blob);
            link.href = url;
            link.download = filename + '.csv';
            link.click();
            URL.revokeObjectURL(url);
        }
        
        // Print content
        function printContent(elementId) {
            const printContent = document.getElementById(elementId).innerHTML;
            const originalContent = document.body.innerHTML;
            
            const printWindow = window.open('', '_blank');
            printWindow.document.write(`
                <html>
                    <head>
                        <title>Print</title>
                        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
                    </head>
                    <body>
                        <div class="container mt-4">
                            ${printContent}
                        </div>
                    </body>
                </html>
            `);
            printWindow.document.close();
            printWindow.print();
        }
        
        // Generate QR Code
        function generateQRCode(elementId, text) {
            new QRCode(document.getElementById(elementId), {
                text: text,
                width: 200,
                height: 200
            });
        }
        
        // Show QR Code in modal
        function showQR(qrData) {
            const modal = new bootstrap.Modal(document.getElementById('qrModal'));
            document.getElementById('qrCodeContainer').innerHTML = '';
            new QRCode(document.getElementById('qrCodeContainer'), {
                text: qrData,
                width: 200,
                height: 200
            });
            modal.show();
        }
        
        // Asset checkout/checkin functions (global)
        function checkoutAsset(assetId) {
            document.getElementById('checkout_asset_id').value = assetId;
            
            // Load active users if not already loaded
            const userSelect = document.getElementById('checkout_user_select');
            if(userSelect.options.length <= 1) {
                fetch('?ajax=get_active_users')
                    .then(response => response.json())
                    .then(data => {
                        if(data.success && data.data) {
                            // Clear existing options except the placeholder
                            while(userSelect.options.length > 1) {
                                userSelect.remove(1);
                            }
                            
                            // Add users to dropdown
                            data.data.forEach(user => {
                                const display = (user.first_name && user.last_name) 
                                    ? user.first_name + ' ' + user.last_name 
                                    : user.username;
                                const position = user.position ? ' - ' + user.position : '';
                                const username = ' (' + user.username + ')';
                                
                                const option = document.createElement('option');
                                option.value = user.id;
                                option.textContent = display + position + username;
                                option.title = user.email;
                                userSelect.appendChild(option);
                            });
                        }
                    })
                    .catch(error => console.error('Error loading users:', error));
            }
            
            new bootstrap.Modal(document.getElementById('checkoutModal')).show();
        }
        
        function checkinAsset(assetId) {
            document.getElementById('checkin_asset_id').value = assetId;
            new bootstrap.Modal(document.getElementById('checkinModal')).show();
        }

        // Scanner helpers
        let html5QrCodeScanner;
        function openScanner() {
            const modal = new bootstrap.Modal(document.getElementById('scanModal'));
            modal.show();
            startScanner();
        }

        function startScanner() {
            html5QrCodeScanner = new Html5Qrcode("qr-reader");
            html5QrCodeScanner.start(
                { facingMode: "environment" },
                { fps: 10, qrbox: 250 },
                qrCodeMessage => {
                    document.getElementById("scanResult").innerText = "Scanned: " + qrCodeMessage;
                    html5QrCodeScanner.stop().then(() => {
                        // lookup asset via AJAX
                        fetch('?ajax=search_assets&term=' + encodeURIComponent(qrCodeMessage))
                            .then(r=>r.json())
                            .then(data=>{
                                    if(data.success && data.data.length > 0) {
                                        // Close scan modal then open asset details in modal
                                        try {
                                            const scanEl = document.getElementById('scanModal');
                                            const scanModalInstance = bootstrap.Modal.getInstance(scanEl);
                                            if(scanModalInstance) scanModalInstance.hide();
                                        } catch(e) { console.warn('Could not hide scan modal', e); }

                                        // Open asset detail modal via existing function
                                        if(typeof viewAsset === 'function') {
                                            viewAsset(data.data[0].id);
                                        } else {
                                            // Fallback to navigating if viewAsset not available
                                            window.location.href = '?action=assets&view=' + data.data[0].id;
                                        }
                                    } else {
                                        document.getElementById("scanResult").innerText = "No asset found for " + qrCodeMessage;
                                    }
                                });
                    }).catch(err=>console.error(err));
                }
            ).catch(err => {
                console.error("Unable to start scanner", err);
                document.getElementById("scanResult").innerText = "Camera access denied or not available.";
            });
        }

        document.getElementById('scanModal').addEventListener('hidden.bs.modal', function () {
            if(html5QrCodeScanner) {
                html5QrCodeScanner.stop().catch(e=>{});
            }
        });
        
        // Download QR Code as image
        function downloadQR() {
            const canvas = document.querySelector('#qrcode canvas');
            if(canvas) {
                const link = document.createElement('a');
                link.href = canvas.toDataURL('image/png');
                link.download = 'qrcode_' + new Date().getTime() + '.png';
                link.click();
            } else {
                showToast('error', 'QR code not found');
            }
        }
        
        // Initialize QR code on asset detail page load
        document.addEventListener('DOMContentLoaded', function() {
            const qrcodeDiv = document.getElementById('qrcode');
            if(qrcodeDiv) {
                // Get asset tag from the page (should be in an element or data attribute)
                const assetTag = document.querySelector('[data-asset-tag]')?.getAttribute('data-asset-tag') ||
                                document.querySelector('h2')?.textContent.match(/Asset Details: (.+)/)?.[1];
                
                if(assetTag) {
                    generateQRCode('qrcode', assetTag.trim());
                }
            }
        });
        
        // Initialize DataTables
        $(document).ready(function() {
            $('.datatable').DataTable({
                pageLength: 25,
                responsive: true,
                language: {
                    search: "Search:",
                    lengthMenu: "Show _MENU_ entries",
                    info: "Showing _START_ to _END_ of _TOTAL_ entries"
                }
            });
        });

        // Modal UX: focus first input on show and show loading spinner on submit
        document.addEventListener('shown.bs.modal', function(e) {
            try { focusFirstInput(e.target); } catch(err){}
        });

        // Attach submit handlers to modal forms to show loading state
        document.querySelectorAll('.modal form').forEach(form => {
            form.addEventListener('submit', function(event) {
                const modalEl = form.closest('.modal');
                // show loading state on modal header
                setModalLoading(modalEl, true);
                // disable submit button and add small spinner
                const submit = form.querySelector('button[type=submit]');
                if(submit) {
                    submit.disabled = true;
                    if(!submit.querySelector('.spinner-border')) {
                        const s = document.createElement('span');
                        s.className = 'spinner-border spinner-border-sm ms-2';
                        s.setAttribute('role','status'); s.setAttribute('aria-hidden','true');
                        submit.appendChild(s);
                    }
                }
            });
        });
    </script>
    
    <!-- QR Code Modal -->
    <div class="modal fade" id="qrModal" tabindex="-1">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">QR Code</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body text-center">
                    <div id="qrCodeContainer"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- View Asset Modal -->
    <div class="modal fade" id="viewAssetModal" tabindex="-1">
        <div class="modal-dialog modal-xl" style="max-height: 90vh;">
            <div class="modal-content" style="display: flex; flex-direction: column; max-height: 90vh;">
                <div class="modal-header">
                    <h5 class="modal-title">Asset Details <span class="spinner-border spinner-border-sm modal-spinner" role="status" aria-hidden="true"></span></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="viewAssetContent" style="overflow-y: auto; flex: 1;">
                    <!-- Asset detail HTML will be injected here -->
                </div>
            </div>
        </div>
    </div>
    <!-- Scan QR Code Modal -->
    <div class="modal fade" id="scanModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Scan QR Code</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div id="qr-reader" style="width:100%;"></div>
                    <p id="scanResult" class="mt-3"></p>
                </div>
            </div>
        </div>
    </div>
    <!-- Checkout & Checkin Modals (global, used by list and detail views) -->
    <div class="modal fade" id="checkoutModal" tabindex="-1" role="dialog" aria-modal="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Checkout Asset <span class="spinner-border spinner-border-sm modal-spinner" role="status" aria-hidden="true"></span></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST">
                    <input type="hidden" name="action" value="checkout_asset">
                    <input type="hidden" name="asset_id" id="checkout_asset_id">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Assign to User *</label>
                            <select name="user_id" class="form-select" required id="checkout_user_select">
                                <option value="">-- Select User --</option>
                            </select>
                            <small class="form-text text-muted">Only active users are shown</small>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Reason for Assignment</label>
                            <textarea name="notes" class="form-control" rows="3" placeholder="e.g., Issued to user for daily work, Temporary assignment, etc."></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Expected Return Date (Optional)</label>
                            <input type="date" name="expected_return" class="form-control">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <div class="modal-actions">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-success">Assign Asset</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="checkinModal" tabindex="-1" role="dialog" aria-modal="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Checkin Asset <span class="spinner-border spinner-border-sm modal-spinner" role="status" aria-hidden="true"></span></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST">
                    <input type="hidden" name="action" value="checkin_asset">
                    <input type="hidden" name="asset_id" id="checkin_asset_id">
                    <div class="modal-body">
                        <div class="alert alert-info mb-3">
                            <i class="fas fa-info-circle"></i> <strong>Return the asset</strong> to your inventory and mark its condition.
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Asset Condition</label>
                            <select name="condition" class="form-select" required>
                                <option value="">-- Select Condition --</option>
                                <option value="good">Good - No damage</option>
                                <option value="fair">Fair - Minor wear</option>
                                <option value="poor">Poor - Functional but visible damage</option>
                                <option value="damaged">Damaged - Not working properly</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Return Notes</label>
                            <textarea name="notes" class="form-control" rows="3" placeholder="e.g., Asset returned in good condition, Minor scratches on screen, etc."></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <div class="modal-actions">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-warning">Return Asset</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>

<?php
// Function to create database tables
function createTables($pdo) {
    try {
        // Users table
        $pdo->exec("CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(100) UNIQUE NOT NULL,
            email VARCHAR(255) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL,
            first_name VARCHAR(100),
            last_name VARCHAR(100),
            employee_id VARCHAR(100),
            department VARCHAR(100),
            position VARCHAR(100),
            location VARCHAR(255),
            phone VARCHAR(50),
            role ENUM('admin', 'user', 'manager') DEFAULT 'user',
            status ENUM('active', 'inactive') DEFAULT 'active',
            last_login DATETIME,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_email (email),
            INDEX idx_employee (employee_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Categories table
        $pdo->exec("CREATE TABLE IF NOT EXISTS categories (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            type ENUM('asset', 'accessory', 'consumable', 'license') DEFAULT 'asset',
            color VARCHAR(7),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_type (type)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Manufacturers table
        $pdo->exec("CREATE TABLE IF NOT EXISTS manufacturers (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            support_url VARCHAR(255),
            support_phone VARCHAR(50),
            support_email VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Locations table
        $pdo->exec("CREATE TABLE IF NOT EXISTS locations (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            address VARCHAR(255),
            address2 VARCHAR(255),
            city VARCHAR(100),
            state VARCHAR(100),
            zip VARCHAR(20),
            country VARCHAR(100),
            manager_id INT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (manager_id) REFERENCES users(id) ON DELETE SET NULL,
            INDEX idx_country (country)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Assets table
        $pdo->exec("CREATE TABLE IF NOT EXISTS assets (
            id INT AUTO_INCREMENT PRIMARY KEY,
            asset_tag VARCHAR(255) UNIQUE NOT NULL,
            serial VARCHAR(255),
            name VARCHAR(255),
            model VARCHAR(255),
            category_id INT,
            manufacturer_id INT,
            location_id INT,
            assigned_to INT,
            status ENUM('available', 'assigned', 'deployed', 'maintenance', 'retired') DEFAULT 'available',
            purchase_date DATE,
            purchase_cost DECIMAL(10,2),
            warranty_months INT,
            warranty_expires DATE,
            supplier VARCHAR(255),
            order_number VARCHAR(255),
            description TEXT,
            notes TEXT,
            qr_code VARCHAR(255),
            created_by INT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
            FOREIGN KEY (manufacturer_id) REFERENCES manufacturers(id) ON DELETE SET NULL,
            FOREIGN KEY (location_id) REFERENCES locations(id) ON DELETE SET NULL,
            FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL,
            FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
            INDEX idx_asset_tag (asset_tag),
            INDEX idx_serial (serial),
            INDEX idx_status (status),
            INDEX idx_assigned (assigned_to)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Licenses table
        $pdo->exec("CREATE TABLE IF NOT EXISTS licenses (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            product_key VARCHAR(255),
            serial VARCHAR(255),
            seats INT DEFAULT 1,
            license_email VARCHAR(255),
            license_name VARCHAR(255),
            manufacturer_id INT,
            category_id INT,
            location_id INT,
            supplier VARCHAR(255),
            order_number VARCHAR(255),
            purchase_date DATE,
            purchase_cost DECIMAL(10,2),
            expiration_date DATE,
            termination_date DATE,
            notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (manufacturer_id) REFERENCES manufacturers(id) ON DELETE SET NULL,
            FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
            FOREIGN KEY (location_id) REFERENCES locations(id) ON DELETE SET NULL,
            INDEX idx_product_key (product_key)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // License assignments table
        $pdo->exec("CREATE TABLE IF NOT EXISTS license_assignments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            license_id INT NOT NULL,
            user_id INT,
            asset_id INT,
            assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (license_id) REFERENCES licenses(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Accessories table
        $pdo->exec("CREATE TABLE IF NOT EXISTS accessories (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            category_id INT,
            manufacturer_id INT,
            location_id INT,
            model_number VARCHAR(255),
            serial_number VARCHAR(255),
            quantity INT DEFAULT 1,
            min_quantity INT DEFAULT 0,
            purchase_date DATE,
            purchase_cost DECIMAL(10,2),
            order_number VARCHAR(255),
            notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
            FOREIGN KEY (manufacturer_id) REFERENCES manufacturers(id) ON DELETE SET NULL,
            FOREIGN KEY (location_id) REFERENCES locations(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Accessory assignments table
        $pdo->exec("CREATE TABLE IF NOT EXISTS accessory_assignments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            accessory_id INT NOT NULL,
            user_id INT NOT NULL,
            assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            returned_at TIMESTAMP NULL,
            FOREIGN KEY (accessory_id) REFERENCES accessories(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Consumables table
        $pdo->exec("CREATE TABLE IF NOT EXISTS consumables (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            category_id INT,
            manufacturer_id INT,
            location_id INT,
            model_number VARCHAR(255),
            item_no VARCHAR(255),
            quantity INT DEFAULT 1,
            min_quantity INT DEFAULT 0,
            purchase_date DATE,
            purchase_cost DECIMAL(10,2),
            order_number VARCHAR(255),
            notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
            FOREIGN KEY (manufacturer_id) REFERENCES manufacturers(id) ON DELETE SET NULL,
            FOREIGN KEY (location_id) REFERENCES locations(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Consumable assignments table
        $pdo->exec("CREATE TABLE IF NOT EXISTS consumable_assignments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            consumable_id INT NOT NULL,
            user_id INT NOT NULL,
            quantity INT DEFAULT 1,
            assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (consumable_id) REFERENCES consumables(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Asset history table
        $pdo->exec("CREATE TABLE IF NOT EXISTS asset_history (
            id INT AUTO_INCREMENT PRIMARY KEY,
            asset_id INT NOT NULL,
            user_id INT,
            action VARCHAR(100),
            notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
            INDEX idx_asset (asset_id),
            INDEX idx_action (action)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Custom fields table
        $pdo->exec("CREATE TABLE IF NOT EXISTS custom_fields (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            type ENUM('text', 'number', 'date', 'boolean', 'select') DEFAULT 'text',
            field_options TEXT,
            required BOOLEAN DEFAULT FALSE,
            show_in_list BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Custom field values table
        $pdo->exec("CREATE TABLE IF NOT EXISTS custom_field_values (
            id INT AUTO_INCREMENT PRIMARY KEY,
            field_id INT NOT NULL,
            asset_id INT NOT NULL,
            field_value TEXT,
            FOREIGN KEY (field_id) REFERENCES custom_fields(id) ON DELETE CASCADE,
            FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE,
            UNIQUE KEY unique_field_asset (field_id, asset_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Notifications table
        $pdo->exec("CREATE TABLE IF NOT EXISTS notifications (
            id INT AUTO_INCREMENT PRIMARY KEY,
            type VARCHAR(100),
            title VARCHAR(255),
            message TEXT,
            user_id INT,
            read_at TIMESTAMP NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_user_read (user_id, read_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Settings table
        $pdo->exec("CREATE TABLE IF NOT EXISTS settings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            setting_key VARCHAR(255) UNIQUE NOT NULL,
            setting_value TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Insert default admin if not exists
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE role = 'admin'");
        $stmt->execute();
        if($stmt->fetchColumn() == 0) {
            $admin_pass = password_hash('admin123', PASSWORD_DEFAULT);
            $pdo->exec("INSERT INTO users (username, email, password, first_name, last_name, role) 
                        VALUES ('admin', 'admin@snipeit.local', '$admin_pass', 'System', 'Administrator', 'admin')");
        }

        // Insert default categories
        $default_categories = [
            ['Laptops', 'asset', '#3498DB'],
            ['Desktops', 'asset', '#2ECC71'],
            ['Tablets', 'asset', '#F39C12'],
            ['Software', 'license', '#E74C3C'],
            ['Peripherals', 'accessory', '#9B59B6'],
            ['Office Supplies', 'consumable', '#1ABC9C']
        ];
        
        foreach($default_categories as $cat) {
            $stmt = $pdo->prepare("INSERT IGNORE INTO categories (name, type, color) VALUES (?, ?, ?)");
            $stmt->execute($cat);
        }

        // Insert default manufacturers
        $default_manufacturers = [
            ['Dell', 'https://www.dell.com/support', '1-800-624-9896', 'support@dell.com'],
            ['HP', 'https://support.hp.com', '1-800-474-6836', 'support@hp.com'],
            ['Lenovo', 'https://support.lenovo.com', '1-855-253-6686', 'support@lenovo.com'],
            ['Apple', 'https://support.apple.com', '1-800-275-2273', 'support@apple.com'],
            ['Microsoft', 'https://support.microsoft.com', '1-800-642-7676', 'support@microsoft.com']
        ];
        
        foreach($default_manufacturers as $man) {
            $stmt = $pdo->prepare("INSERT IGNORE INTO manufacturers (name, support_url, support_phone, support_email) VALUES (?, ?, ?, ?)");
            $stmt->execute($man);
        }

        // Insert default locations
        $default_locations = [
            ['Headquarters', '123 Main St', 'New York', 'NY', '10001', 'USA'],
            ['Branch Office', '456 Oak Ave', 'Los Angeles', 'CA', '90001', 'USA']
        ];
        
        foreach($default_locations as $loc) {
            $stmt = $pdo->prepare("INSERT IGNORE INTO locations (name, address, city, state, zip, country) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute($loc);
        }

        // Insert default settings
        $default_settings = [
            'site_name' => 'Snipe-IT Asset Management',
            'site_url' => 'http://localhost/snipeit',
            'company_name' => 'Your Company',
            'alert_threshold' => '30',
            'default_currency' => 'USD',
            'date_format' => 'Y-m-d',
            'enable_qr' => 'true',
            'qr_size' => '200',
            'version' => '24.04 LTS'
        ];

        foreach($default_settings as $key => $value) {
            $stmt = $pdo->prepare("INSERT IGNORE INTO settings (setting_key, setting_value) VALUES (?, ?)");
            $stmt->execute([$key, $value]);
        }

        // Insert sample data for testing
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM assets");
        $stmt->execute();
        if($stmt->fetchColumn() == 0) {
            // Add sample assets
            $sample_assets = [
                ['ASSET001', 'Laptop-001', 'SN123456', 'Latitude 5420', 1, 1, 1, 'available', '2024-01-15', 1200.00],
                ['ASSET002', 'Desktop-001', 'SN789012', 'OptiPlex 7080', 2, 1, 1, 'available', '2024-01-20', 850.00],
                ['ASSET003', 'Tablet-001', 'SN345678', 'iPad Pro', 3, 4, 2, 'available', '2024-02-01', 999.00]
            ];
            
            foreach($sample_assets as $asset) {
                $qr_code = $asset[0];
                $stmt = $pdo->prepare("INSERT INTO assets (asset_tag, name, serial, model, category_id, manufacturer_id, location_id, status, purchase_date, purchase_cost, qr_code, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)");
                $stmt->execute([$asset[0], $asset[1], $asset[2], $asset[3], $asset[4], $asset[5], $asset[6], $asset[7], $asset[8], $asset[9], $qr_code]);
            }
        }

        return true;
        
    } catch(PDOException $e) {
        // Log error but continue
        error_log("Table creation error: " . $e->getMessage());
        echo "<div class='alert alert-warning'>Warning: Some tables could not be created. " . $e->getMessage() . "</div>";
        return false;
    }
}

// Handle POST requests
function handlePostRequest($pdo) {
    $action = isset($_POST['action']) ? $_POST['action'] : '';
    
    try {
        switch($action) {
            case 'login':
                $username = isset($_POST['username']) ? trim($_POST['username']) : '';
                $password = isset($_POST['password']) ? $_POST['password'] : '';
                
                $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND status = 'active'");
                $stmt->execute([$username]);
                $user = $stmt->fetch();
                
                if($user && password_verify($password, $user['password'])) {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['user_role'] = $user['role'];
                    $_SESSION['user_name'] = $user['first_name'] . ' ' . $user['last_name'];
                    
                    // Update last login
                    $stmt = $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
                    $stmt->execute([$user['id']]);
                    
                    $_SESSION['success'] = 'Welcome back, ' . $user['first_name'] . '!';
                    header('Location: ?action=dashboard');
                    exit;
                } else {
                    $_SESSION['error'] = 'Invalid username or password';
                    header('Location: ?action=login');
                    exit;
                }
                break;
                
            case 'import_assets':
                if(isset($_FILES['csv_file']) && $_FILES['csv_file']['error'] === UPLOAD_ERR_OK) {
                    $file = fopen($_FILES['csv_file']['tmp_name'], 'r');
                    $header = fgetcsv($file);
                    while(($row = fgetcsv($file)) !== false) {
                        // simple mapping: asset_tag,name,serial,model,category,manufacturer,location,status
                        $asset_tag = $row[0] ?? '';
                        $name = $row[1] ?? '';
                        $serial = $row[2] ?? '';
                        $model = $row[3] ?? '';
                        $category_name = $row[4] ?? '';
                        $manufacturer_name = $row[5] ?? '';
                        $location_name = $row[6] ?? '';
                        $status = $row[7] ?? 'available';

                        // lookup ids
                        $category_id = null;
                        if($category_name) {
                            $stmtC = $pdo->prepare("SELECT id FROM categories WHERE name = ? LIMIT 1");
                            $stmtC->execute([$category_name]);
                            $category_id = $stmtC->fetchColumn();
                        }
                        $manufacturer_id = null;
                        if($manufacturer_name) {
                            $stmtM = $pdo->prepare("SELECT id FROM manufacturers WHERE name = ? LIMIT 1");
                            $stmtM->execute([$manufacturer_name]);
                            $manufacturer_id = $stmtM->fetchColumn();
                        }
                        $location_id = null;
                        if($location_name) {
                            $stmtL = $pdo->prepare("SELECT id FROM locations WHERE name = ? LIMIT 1");
                            $stmtL->execute([$location_name]);
                            $location_id = $stmtL->fetchColumn();
                        }

                        $qr_code = $asset_tag;
                        $stmt = $pdo->prepare("INSERT IGNORE INTO assets (asset_tag, name, serial, model, category_id, manufacturer_id, location_id, status, qr_code, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                        $stmt->execute([$asset_tag, $name, $serial, $model, $category_id, $manufacturer_id, $location_id, $status, $qr_code, $_SESSION['user_id']]);
                        $asset_id = $pdo->lastInsertId();
                        if($asset_id) {
                            $stmtHist = $pdo->prepare("INSERT INTO asset_history (asset_id, user_id, action, notes) VALUES (?, ?, 'created', 'Imported via CSV')");
                            $stmtHist->execute([$asset_id, $_SESSION['user_id']]);
                        }
                    }
                    fclose($file);
                    $_SESSION['success'] = 'Asset import completed';
                    createNotification($pdo, 'info', 'Assets imported', 'Assets were imported from a CSV file', null);
                } else {
                    $_SESSION['error'] = 'Failed to upload CSV file';
                }
                header('Location: ?action=assets');
                exit;
                break;

            case 'add_asset':
                $asset_tag = isset($_POST['asset_tag']) ? trim($_POST['asset_tag']) : '';
                $name = isset($_POST['name']) ? trim($_POST['name']) : '';
                $serial = isset($_POST['serial']) ? trim($_POST['serial']) : '';
                $model = isset($_POST['model']) ? trim($_POST['model']) : '';
                $category_id = !empty($_POST['category_id']) ? $_POST['category_id'] : null;
                $manufacturer_id = !empty($_POST['manufacturer_id']) ? $_POST['manufacturer_id'] : null;
                $location_id = !empty($_POST['location_id']) ? $_POST['location_id'] : null;
                $purchase_date = !empty($_POST['purchase_date']) ? $_POST['purchase_date'] : null;
                $purchase_cost = !empty($_POST['purchase_cost']) ? floatval($_POST['purchase_cost']) : 0;
                $status = isset($_POST['status']) ? $_POST['status'] : 'available';
                
                // Generate QR code data (just use tag)
                $qr_code = $asset_tag;
                
                $stmt = $pdo->prepare("INSERT INTO assets (asset_tag, name, serial, model, category_id, manufacturer_id, location_id, purchase_date, purchase_cost, status, qr_code, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$asset_tag, $name, $serial, $model, $category_id, $manufacturer_id, $location_id, $purchase_date, $purchase_cost, $status, $qr_code, $_SESSION['user_id']]);
                
                // Add to history
                $asset_id = $pdo->lastInsertId();
                $stmt = $pdo->prepare("INSERT INTO asset_history (asset_id, user_id, action, notes) VALUES (?, ?, 'created', 'Asset created')");
                $stmt->execute([$asset_id, $_SESSION['user_id']]);
                
                $_SESSION['success'] = 'Asset added successfully';
                createNotification($pdo, 'info', 'Asset added', 'Asset "' . $name . '" was added', $_SESSION['user_id']);
                header('Location: ?action=assets');
                exit;
                break;
                
            case 'checkout_asset':
                $asset_id = isset($_POST['asset_id']) ? intval($_POST['asset_id']) : 0;
                $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
                $notes = isset($_POST['notes']) ? trim($_POST['notes']) : '';
                
                // Check if asset is available
                $stmt = $pdo->prepare("SELECT status FROM assets WHERE id = ?");
                $stmt->execute([$asset_id]);
                $asset = $stmt->fetch();
                
                if($asset && $asset['status'] == 'available') {
                    $stmt = $pdo->prepare("UPDATE assets SET assigned_to = ?, status = 'assigned' WHERE id = ?");
                    if($stmt->execute([$user_id, $asset_id])) {
                        // Add to history
                        $stmt = $pdo->prepare("INSERT INTO asset_history (asset_id, user_id, action, notes) VALUES (?, ?, 'checked_out', ?)");
                        $stmt->execute([$asset_id, $_SESSION['user_id'], $notes]);
                        
                        $_SESSION['success'] = 'Asset checked out successfully';
                        createNotification($pdo, 'info', 'Asset checked out', 'Asset ID ' . $asset_id . ' checked out', $_SESSION['user_id']);
                    }
                } else {
                    $_SESSION['error'] = 'Asset is not available for checkout';
                }
                header('Location: ?action=assets' . (isset($_POST['return_to_view']) ? '&view=' . $asset_id : ''));
                exit;
                break;
                
            case 'checkin_asset':
                $asset_id = isset($_POST['asset_id']) ? intval($_POST['asset_id']) : 0;
                $notes = isset($_POST['notes']) ? trim($_POST['notes']) : '';
                
                $stmt = $pdo->prepare("UPDATE assets SET assigned_to = NULL, status = 'available' WHERE id = ?");
                if($stmt->execute([$asset_id])) {
                    // Add to history
                    $stmt = $pdo->prepare("INSERT INTO asset_history (asset_id, user_id, action, notes) VALUES (?, ?, 'checked_in', ?)");
                    $stmt->execute([$asset_id, $_SESSION['user_id'], $notes]);
                    
                    $_SESSION['success'] = 'Asset checked in successfully';
                    createNotification($pdo, 'info', 'Asset checked in', 'Asset ID ' . $asset_id . ' checked in', $_SESSION['user_id']);
                } else {
                    $_SESSION['error'] = 'Asset could not be checked in';
                }
                header('Location: ?action=assets' . (isset($_POST['return_to_view']) ? '&view=' . $asset_id : ''));
                exit;
                break;
                
            case 'update_asset':
                $asset_id = isset($_POST['asset_id']) ? intval($_POST['asset_id']) : 0;
                $asset_tag = isset($_POST['asset_tag']) ? trim($_POST['asset_tag']) : '';
                $name = isset($_POST['name']) ? trim($_POST['name']) : '';
                $serial = isset($_POST['serial']) ? trim($_POST['serial']) : '';
                $model = isset($_POST['model']) ? trim($_POST['model']) : '';
                $category_id = !empty($_POST['category_id']) ? $_POST['category_id'] : null;
                $manufacturer_id = !empty($_POST['manufacturer_id']) ? $_POST['manufacturer_id'] : null;
                $location_id = !empty($_POST['location_id']) ? $_POST['location_id'] : null;
                $purchase_date = !empty($_POST['purchase_date']) ? $_POST['purchase_date'] : null;
                $purchase_cost = !empty($_POST['purchase_cost']) ? floatval($_POST['purchase_cost']) : 0;
                $status = isset($_POST['status']) ? $_POST['status'] : 'available';
                $notes = isset($_POST['notes']) ? trim($_POST['notes']) : '';
                
                $stmt = $pdo->prepare("UPDATE assets SET asset_tag = ?, name = ?, serial = ?, model = ?, category_id = ?, manufacturer_id = ?, location_id = ?, purchase_date = ?, purchase_cost = ?, status = ?, notes = ? WHERE id = ?");
                if($stmt->execute([$asset_tag, $name, $serial, $model, $category_id, $manufacturer_id, $location_id, $purchase_date, $purchase_cost, $status, $notes, $asset_id])) {
                    // Add to history
                    $stmt = $pdo->prepare("INSERT INTO asset_history (asset_id, user_id, action, notes) VALUES (?, ?, 'updated', 'Asset information updated')");
                    $stmt->execute([$asset_id, $_SESSION['user_id']]);
                    
                    $_SESSION['success'] = 'Asset updated successfully';
                    createNotification($pdo, 'info', 'Asset updated', 'Asset "' . $name . '" was updated', $_SESSION['user_id']);
                } else {
                    $_SESSION['error'] = 'Failed to update asset';
                }
                header('Location: ?action=assets&view=' . $asset_id);
                exit;
                break;
                
            case 'add_license':
                $name = isset($_POST['name']) ? trim($_POST['name']) : '';
                $product_key = isset($_POST['product_key']) ? trim($_POST['product_key']) : '';
                $seats = isset($_POST['seats']) ? intval($_POST['seats']) : 1;
                $manufacturer_id = !empty($_POST['manufacturer_id']) ? $_POST['manufacturer_id'] : null;
                $purchase_date = !empty($_POST['purchase_date']) ? $_POST['purchase_date'] : null;
                $expiration_date = !empty($_POST['expiration_date']) ? $_POST['expiration_date'] : null;
                
                $stmt = $pdo->prepare("INSERT INTO licenses (name, product_key, seats, manufacturer_id, purchase_date, expiration_date) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$name, $product_key, $seats, $manufacturer_id, $purchase_date, $expiration_date]);
                
                $_SESSION['success'] = 'License added successfully';
                createNotification($pdo, 'info', 'License added', 'License "' . $name . '" was created', $_SESSION['user_id']);
                break;
            case 'update_license':
                $license_id = isset($_POST['license_id']) ? intval($_POST['license_id']) : 0;
                $name = isset($_POST['name']) ? trim($_POST['name']) : '';
                $product_key = isset($_POST['product_key']) ? trim($_POST['product_key']) : '';
                $seats = isset($_POST['seats']) ? intval($_POST['seats']) : 1;
                $manufacturer_id = !empty($_POST['manufacturer_id']) ? $_POST['manufacturer_id'] : null;
                $purchase_date = !empty($_POST['purchase_date']) ? $_POST['purchase_date'] : null;
                $expiration_date = !empty($_POST['expiration_date']) ? $_POST['expiration_date'] : null;
                $notes = isset($_POST['notes']) ? trim($_POST['notes']) : '';

                $stmt = $pdo->prepare("UPDATE licenses SET name = ?, product_key = ?, seats = ?, manufacturer_id = ?, purchase_date = ?, expiration_date = ?, notes = ? WHERE id = ?");
                if($stmt->execute([$name, $product_key, $seats, $manufacturer_id, $purchase_date, $expiration_date, $notes, $license_id])) {
                    $_SESSION['success'] = 'License updated successfully';
                    createNotification($pdo, 'info', 'License updated', 'License "' . $name . '" was updated', $_SESSION['user_id']);
                } else {
                    $_SESSION['error'] = 'Failed to update license';
                }
                header('Location: ?action=licenses');
                exit;
                break;
            case 'assign_license':
                $license_id = isset($_POST['license_id']) ? intval($_POST['license_id']) : 0;
                $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : null;
                $asset_id = isset($_POST['asset_id']) ? intval($_POST['asset_id']) : null;

                if($license_id && ($user_id || $asset_id)) {
                    $stmt = $pdo->prepare("INSERT INTO license_assignments (license_id, user_id, asset_id) VALUES (?, ?, ?)");
                    $stmt->execute([$license_id, $user_id ?: null, $asset_id ?: null]);
                    $_SESSION['success'] = 'License assigned successfully';
                    createNotification($pdo, 'info', 'License assigned', 'License ID ' . $license_id . ' assigned', $_SESSION['user_id']);
                } else {
                    $_SESSION['error'] = 'Please select a user or asset to assign';
                }
                header('Location: ?action=licenses');
                exit;
                break;

            // accessory CRUD and assignments
            case 'add_accessory':
                $name = isset($_POST['name']) ? trim($_POST['name']) : '';
                $category_id = !empty($_POST['category_id']) ? $_POST['category_id'] : null;
                $manufacturer_id = !empty($_POST['manufacturer_id']) ? $_POST['manufacturer_id'] : null;
                $location_id = !empty($_POST['location_id']) ? $_POST['location_id'] : null;
                $model_number = isset($_POST['model_number']) ? trim($_POST['model_number']) : '';
                $serial_number = isset($_POST['serial_number']) ? trim($_POST['serial_number']) : '';
                $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;
                $min_quantity = isset($_POST['min_quantity']) ? intval($_POST['min_quantity']) : 0;
                $purchase_date = !empty($_POST['purchase_date']) ? $_POST['purchase_date'] : null;
                $purchase_cost = !empty($_POST['purchase_cost']) ? floatval($_POST['purchase_cost']) : 0;
                $notes = isset($_POST['notes']) ? trim($_POST['notes']) : '';

                $stmt = $pdo->prepare("INSERT INTO accessories (name, category_id, manufacturer_id, location_id, model_number, serial_number, quantity, min_quantity, purchase_date, purchase_cost, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$name, $category_id, $manufacturer_id, $location_id, $model_number, $serial_number, $quantity, $min_quantity, $purchase_date, $purchase_cost, $notes]);
                $_SESSION['success'] = 'Accessory added successfully';
                createNotification($pdo,'info','Accessory added','Accessory "' . $name . '" added',$_SESSION['user_id']);
                header('Location: ?action=accessories');
                exit;
                break;

            case 'update_accessory':
                $accessory_id = isset($_POST['accessory_id']) ? intval($_POST['accessory_id']) : 0;
                $name = isset($_POST['name']) ? trim($_POST['name']) : '';
                $category_id = !empty($_POST['category_id']) ? $_POST['category_id'] : null;
                $manufacturer_id = !empty($_POST['manufacturer_id']) ? $_POST['manufacturer_id'] : null;
                $location_id = !empty($_POST['location_id']) ? $_POST['location_id'] : null;
                $model_number = isset($_POST['model_number']) ? trim($_POST['model_number']) : '';
                $serial_number = isset($_POST['serial_number']) ? trim($_POST['serial_number']) : '';
                $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 0;
                $min_quantity = isset($_POST['min_quantity']) ? intval($_POST['min_quantity']) : 0;
                $purchase_date = !empty($_POST['purchase_date']) ? $_POST['purchase_date'] : null;
                $purchase_cost = !empty($_POST['purchase_cost']) ? floatval($_POST['purchase_cost']) : 0;
                $notes = isset($_POST['notes']) ? trim($_POST['notes']) : '';

                $stmt = $pdo->prepare("UPDATE accessories SET name = ?, category_id = ?, manufacturer_id = ?, location_id = ?, model_number = ?, serial_number = ?, quantity = ?, min_quantity = ?, purchase_date = ?, purchase_cost = ?, notes = ? WHERE id = ?");
                if($stmt->execute([$name, $category_id, $manufacturer_id, $location_id, $model_number, $serial_number, $quantity, $min_quantity, $purchase_date, $purchase_cost, $notes, $accessory_id])) {
                    $_SESSION['success'] = 'Accessory updated successfully';
                    createNotification($pdo,'info','Accessory updated','Accessory "' . $name . '" updated',$_SESSION['user_id']);
                } else {
                    $_SESSION['error'] = 'Failed to update accessory';
                }
                header('Location: ?action=accessories' . (isset($_POST['return_to_view']) ? '&view=' . $accessory_id : ''));
                exit;
                break;

            case 'delete_accessory':
                if($_SESSION['user_role'] == 'admin') {
                    $accessory_id = isset($_POST['accessory_id']) ? intval($_POST['accessory_id']) : 0;
                    $stmt = $pdo->prepare("DELETE FROM accessories WHERE id = ?");
                    if($stmt->execute([$accessory_id])) {
                        $_SESSION['success'] = 'Accessory deleted';
                        createNotification($pdo,'info','Accessory deleted','Accessory ID ' . $accessory_id . ' deleted',$_SESSION['user_id']);
                    } else {
                        $_SESSION['error'] = 'Failed to delete accessory';
                    }
                } else {
                    $_SESSION['error'] = 'Unauthorized';
                }
                header('Location: ?action=accessories');
                exit;
                break;

            case 'assign_accessory':
                $accessory_id = isset($_POST['accessory_id']) ? intval($_POST['accessory_id']) : 0;
                $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
                if($accessory_id && $user_id) {
                    $stmt = $pdo->prepare("INSERT INTO accessory_assignments (accessory_id, user_id) VALUES (?, ?)");
                    $stmt->execute([$accessory_id, $user_id]);
                    $_SESSION['success'] = 'Accessory assigned';
                    createNotification($pdo,'info','Accessory assigned','Accessory ID ' . $accessory_id . ' assigned',$_SESSION['user_id']);
                } else {
                    $_SESSION['error'] = 'Please select a user and accessory';
                }
                header('Location: ?action=accessories' . (isset($_POST['return_to_view']) ? '&view=' . $accessory_id : ''));
                exit;
                break;

            case 'return_accessory':
                $assignment_id = isset($_POST['assignment_id']) ? intval($_POST['assignment_id']) : 0;
                $accid = null;
                if($assignment_id) {
                    $stmt = $pdo->prepare("SELECT accessory_id FROM accessory_assignments WHERE id = ?");
                    $stmt->execute([$assignment_id]);
                    $accid = $stmt->fetchColumn();
                    $stmt = $pdo->prepare("UPDATE accessory_assignments SET returned_at = NOW() WHERE id = ?");
                    $stmt->execute([$assignment_id]);
                    $_SESSION['success'] = 'Accessory returned';
                    createNotification($pdo,'info','Accessory returned','Assignment ID ' . $assignment_id . ' returned',$_SESSION['user_id']);
                }
                header('Location: ?action=accessories' . ($accid ? '&view=' . $accid : ''));
                exit;
                break;

                
            case 'add_user':
                // Add consumable
                if(false) {}
                break;
            case 'add_consumable':
                $name = isset($_POST['name']) ? trim($_POST['name']) : '';
                $category_id = !empty($_POST['category_id']) ? $_POST['category_id'] : null;
                $manufacturer_id = !empty($_POST['manufacturer_id']) ? $_POST['manufacturer_id'] : null;
                $location_id = !empty($_POST['location_id']) ? $_POST['location_id'] : null;
                $model_number = isset($_POST['model_number']) ? trim($_POST['model_number']) : '';
                $item_no = isset($_POST['item_no']) ? trim($_POST['item_no']) : '';
                $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;
                $min_quantity = isset($_POST['min_quantity']) ? intval($_POST['min_quantity']) : 0;
                $purchase_date = !empty($_POST['purchase_date']) ? $_POST['purchase_date'] : null;
                $purchase_cost = !empty($_POST['purchase_cost']) ? floatval($_POST['purchase_cost']) : 0;
                $notes = isset($_POST['notes']) ? trim($_POST['notes']) : '';

                $stmt = $pdo->prepare("INSERT INTO consumables (name, category_id, manufacturer_id, location_id, model_number, item_no, quantity, min_quantity, purchase_date, purchase_cost, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$name, $category_id, $manufacturer_id, $location_id, $model_number, $item_no, $quantity, $min_quantity, $purchase_date, $purchase_cost, $notes]);
                $_SESSION['success'] = 'Item added successfully';
                createNotification($pdo, 'info', 'Item added', 'Item "' . $name . '" was created', $_SESSION['user_id']);
                header('Location: ?action=consumables');
                exit;
                break;

            case 'checkout_consumable':
                $consumable_id = isset($_POST['consumable_id']) ? intval($_POST['consumable_id']) : 0;
                $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
                $qty = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;
                $notes = isset($_POST['notes']) ? trim($_POST['notes']) : '';

                if($consumable_id && $user_id && $qty > 0) {
                    // Check availability
                    $stmt = $pdo->prepare("SELECT quantity, name, min_quantity FROM consumables WHERE id = ?");
                    $stmt->execute([$consumable_id]);
                    $cons = $stmt->fetch();
                    if($cons) {
                        $stmt2 = $pdo->prepare("SELECT IFNULL(SUM(quantity),0) FROM consumable_assignments WHERE consumable_id = ?");
                        $stmt2->execute([$consumable_id]);
                        $used = intval($stmt2->fetchColumn());
                        $available = intval($cons['quantity']) - $used;
                        if($qty <= $available) {
                            $ins = $pdo->prepare("INSERT INTO consumable_assignments (consumable_id, user_id, quantity) VALUES (?, ?, ?)");
                            $ins->execute([$consumable_id, $user_id, $qty]);
                            $_SESSION['success'] = 'Item checked out successfully';
                            createNotification($pdo, 'info', 'Item checked out', 'Item ID ' . $consumable_id . ' qty ' . $qty . ' checked out to user ' . $user_id, $_SESSION['user_id']);

                            // Recalculate availability and notify if low
                            $stmt2->execute([$consumable_id]);
                            $used2 = intval($stmt2->fetchColumn());
                            $available2 = intval($cons['quantity']) - $used2;
                            if($available2 <= intval($cons['min_quantity'])) {
                                createNotification($pdo, 'warning', 'Item low', 'Item "' . $cons['name'] . '" is low: ' . $available2 . ' remaining', null);
                            }
                        } else {
                            $_SESSION['error'] = 'Requested quantity exceeds available stock';
                        }
                    } else {
                        $_SESSION['error'] = 'Consumable not found';
                    }
                } else {
                    $_SESSION['error'] = 'Please select a user and quantity';
                }
                header('Location: ?action=consumables');
                exit;
                break;
                $username = isset($_POST['username']) ? trim($_POST['username']) : '';
                $email = isset($_POST['email']) ? trim($_POST['email']) : '';
                $password = isset($_POST['password']) ? password_hash($_POST['password'], PASSWORD_DEFAULT) : password_hash('password123', PASSWORD_DEFAULT);
                $first_name = isset($_POST['first_name']) ? trim($_POST['first_name']) : '';
                $last_name = isset($_POST['last_name']) ? trim($_POST['last_name']) : '';
                $employee_id = isset($_POST['employee_id']) ? trim($_POST['employee_id']) : '';
                $department = isset($_POST['department']) ? trim($_POST['department']) : '';
                $position = isset($_POST['position']) ? trim($_POST['position']) : '';
                $role = isset($_POST['role']) ? $_POST['role'] : 'user';
                
                // Check if username or email already exists
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ? OR email = ?");
                $stmt->execute([$username, $email]);
                if($stmt->fetchColumn() > 0) {
                    $_SESSION['error'] = 'Username or email already exists';
                    break;
                }
                
                $stmt = $pdo->prepare("INSERT INTO users (username, email, password, first_name, last_name, employee_id, department, position, role) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$username, $email, $password, $first_name, $last_name, $employee_id, $department, $position, $role]);
                
                $_SESSION['success'] = 'User added successfully';
                createNotification($pdo, 'info', 'User added', 'New user "' . $username . '" was created', $_SESSION['user_id']);
                break;
                
            case 'add_category':
                $name = isset($_POST['name']) ? trim($_POST['name']) : '';
                $type = isset($_POST['type']) ? $_POST['type'] : 'asset';
                $color = isset($_POST['color']) ? $_POST['color'] : '#000000';
                
                $stmt = $pdo->prepare("INSERT INTO categories (name, type, color) VALUES (?, ?, ?)");
                $stmt->execute([$name, $type, $color]);
                
                $_SESSION['success'] = 'Category added successfully';
                createNotification($pdo, 'info', 'Category added', 'Category "' . $name . '" was created', $_SESSION['user_id']);
                break;
                
            case 'add_manufacturer':
                $name = isset($_POST['name']) ? trim($_POST['name']) : '';
                $support_url = isset($_POST['support_url']) ? trim($_POST['support_url']) : '';
                $support_phone = isset($_POST['support_phone']) ? trim($_POST['support_phone']) : '';
                $support_email = isset($_POST['support_email']) ? trim($_POST['support_email']) : '';
                
                $stmt = $pdo->prepare("INSERT INTO manufacturers (name, support_url, support_phone, support_email) VALUES (?, ?, ?, ?)");
                $stmt->execute([$name, $support_url, $support_phone, $support_email]);
                
                $_SESSION['success'] = 'Manufacturer added successfully';
                createNotification($pdo, 'info', 'Manufacturer added', 'Manufacturer "' . $name . '" was created', $_SESSION['user_id']);
                break;
                
            case 'add_location':
                $name = isset($_POST['name']) ? trim($_POST['name']) : '';
                $address = isset($_POST['address']) ? trim($_POST['address']) : '';
                $city = isset($_POST['city']) ? trim($_POST['city']) : '';
                $state = isset($_POST['state']) ? trim($_POST['state']) : '';
                $zip = isset($_POST['zip']) ? trim($_POST['zip']) : '';
                $country = isset($_POST['country']) ? trim($_POST['country']) : '';
                
                $stmt = $pdo->prepare("INSERT INTO locations (name, address, city, state, zip, country) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$name, $address, $city, $state, $zip, $country]);
                
                $_SESSION['success'] = 'Location added successfully';
                createNotification($pdo, 'info', 'Location added', 'Location "' . $name . '" was created', $_SESSION['user_id']);
                break;
                
            case 'add_custom_field':
                $name = isset($_POST['name']) ? trim($_POST['name']) : '';
                $type = isset($_POST['type']) ? $_POST['type'] : 'text';
                $field_options = isset($_POST['options']) ? trim($_POST['options']) : '';
                $required = isset($_POST['required']) ? 1 : 0;
                $show_in_list = isset($_POST['show_in_list']) ? 1 : 0;
                
                $stmt = $pdo->prepare("INSERT INTO custom_fields (name, type, field_options, required, show_in_list) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$name, $type, $field_options, $required, $show_in_list]);
                
                $_SESSION['success'] = 'Custom field added successfully';
                createNotification($pdo, 'info', 'Custom field added', 'Custom field "' . $name . '" was created', $_SESSION['user_id']);
                break;
                
            case 'update_settings':
                foreach($_POST as $key => $value) {
                    if($key != 'action') {
                        $stmt = $pdo->prepare("UPDATE settings SET setting_value = ? WHERE setting_key = ?");
                        $stmt->execute([$value, $key]);
                    }
                }
                $_SESSION['success'] = 'Settings updated successfully';
                createNotification($pdo, 'info', 'Settings changed', 'System settings were updated', null);
                break;
                
            case 'update_profile':
                $user_id = $_SESSION['user_id'];
                $first_name = isset($_POST['first_name']) ? trim($_POST['first_name']) : '';
                $last_name = isset($_POST['last_name']) ? trim($_POST['last_name']) : '';
                $email = isset($_POST['email']) ? trim($_POST['email']) : '';
                $phone = isset($_POST['phone']) ? trim($_POST['phone']) : '';
                $current_password = isset($_POST['current_password']) ? $_POST['current_password'] : '';
                $new_password = isset($_POST['new_password']) ? $_POST['new_password'] : '';
                
                // Verify current password if changing password
                if(!empty($new_password)) {
                    $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
                    $stmt->execute([$user_id]);
                    $user = $stmt->fetch();
                    
                    if(!password_verify($current_password, $user['password'])) {
                        $_SESSION['error'] = 'Current password is incorrect';
                        break;
                    }
                    
                    $new_password_hash = password_hash($new_password, PASSWORD_DEFAULT);
                    $stmt = $pdo->prepare("UPDATE users SET first_name = ?, last_name = ?, email = ?, phone = ?, password = ? WHERE id = ?");
                    $stmt->execute([$first_name, $last_name, $email, $phone, $new_password_hash, $user_id]);
                } else {
                    $stmt = $pdo->prepare("UPDATE users SET first_name = ?, last_name = ?, email = ?, phone = ? WHERE id = ?");
                    $stmt->execute([$first_name, $last_name, $email, $phone, $user_id]);
                }
                
                $_SESSION['success'] = 'Profile updated successfully';
                createNotification($pdo, 'info', 'Profile updated', 'User profile was updated', $_SESSION['user_id']);
                break;
        }
        
        // Redirect back to the same page
        if(!isset($_SESSION['error']) && !headers_sent()) {
            $redirect = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '?action=dashboard';
            header('Location: ' . $redirect);
            exit;
        }
        
    } catch(PDOException $e) {
        $_SESSION['error'] = 'Database error: ' . $e->getMessage();
        error_log("Post request error: " . $e->getMessage());
    }
}

// Handle AJAX requests
function handleAjaxRequest($pdo) {
    header('Content-Type: application/json');
    $response = ['success' => false, 'message' => '', 'data' => null];
    
    try {
        $action = isset($_GET['ajax']) ? $_GET['ajax'] : '';
        
        switch($action) {
            case 'get_asset_history':
                $asset_id = isset($_GET['asset_id']) ? intval($_GET['asset_id']) : 0;
                
                $stmt = $pdo->prepare("SELECT ah.*, u.username, u.first_name, u.last_name 
                                      FROM asset_history ah 
                                      LEFT JOIN users u ON ah.user_id = u.id 
                                      WHERE ah.asset_id = ? 
                                      ORDER BY ah.created_at DESC");
                $stmt->execute([$asset_id]);
                $history = $stmt->fetchAll();
                
                $response['success'] = true;
                $response['data'] = $history;
                break;
                
            case 'get_dashboard_stats':
                $stats = [
                    'total_assets' => $pdo->query("SELECT COUNT(*) FROM assets")->fetchColumn(),
                    'available_assets' => $pdo->query("SELECT COUNT(*) FROM assets WHERE status = 'available'")->fetchColumn(),
                    'assigned_assets' => $pdo->query("SELECT COUNT(*) FROM assets WHERE status = 'assigned'")->fetchColumn(),
                    'maintenance_assets' => $pdo->query("SELECT COUNT(*) FROM assets WHERE status = 'maintenance'")->fetchColumn(),
                    'total_users' => $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn(),
                    'total_licenses' => $pdo->query("SELECT COUNT(*) FROM licenses")->fetchColumn(),
                    'expiring_licenses' => $pdo->query("SELECT COUNT(*) FROM licenses WHERE expiration_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)")->fetchColumn()
                ];
                
                $response['success'] = true;
                $response['data'] = $stats;
                break;
                
            case 'search_assets':
                $term = isset($_GET['term']) ? '%' . $_GET['term'] . '%' : '%';
                
                $stmt = $pdo->prepare("SELECT a.*, c.name as category_name, u.first_name, u.last_name 
                                      FROM assets a 
                                      LEFT JOIN categories c ON a.category_id = c.id 
                                      LEFT JOIN users u ON a.assigned_to = u.id 
                                      WHERE a.asset_tag LIKE ? OR a.name LIKE ? OR a.serial LIKE ? 
                                      LIMIT 10");
                $stmt->execute([$term, $term, $term]);
                $results = $stmt->fetchAll();
                
                $response['success'] = true;
                $response['data'] = $results;
                break;
                
            case 'delete_asset':
                if($_SESSION['user_role'] != 'admin') {
                    $response['message'] = 'Unauthorized';
                    break;
                }
                
                $asset_id = isset($_POST['asset_id']) ? intval($_POST['asset_id']) : 0;
                
                $stmt = $pdo->prepare("DELETE FROM assets WHERE id = ?");
                if($stmt->execute([$asset_id])) {
                    $response['success'] = true;
                    $response['message'] = 'Asset deleted successfully';
                }
                break;
                
            case 'get_asset':
                $asset_id = isset($_GET['asset_id']) ? intval($_GET['asset_id']) : 0;
                
                $stmt = $pdo->prepare("SELECT * FROM assets WHERE id = ?");
                $stmt->execute([$asset_id]);
                $asset = $stmt->fetch();
                
                if($asset) {
                    $response['success'] = true;
                    $response['data'] = $asset;
                } else {
                    $response['message'] = 'Asset not found';
                }
                break;
            case 'asset_detail_html':
                $asset_id = isset($_GET['asset_id']) ? intval($_GET['asset_id']) : 0;
                ob_start();
                // Render the asset detail HTML using the existing function
                includeAssetDetail($pdo, $asset_id, true);
                $html = ob_get_clean();
                $response['success'] = true;
                $response['html'] = $html;
                break;
            case 'api_assets':
                $response['success'] = true;
                $response['data'] = $pdo->query("SELECT * FROM assets")->fetchAll();
                break;
            case 'api_asset':
                if(isset($_GET['asset_id'])) {
                    $stmt = $pdo->prepare("SELECT * FROM assets WHERE id = ?");
                    $stmt->execute([intval($_GET['asset_id'])]);
                    $response['success'] = true;
                    $response['data'] = $stmt->fetch();
                }
                break;
            case 'api_users':
                $response['success'] = true;
                $response['data'] = $pdo->query("SELECT * FROM users")->fetchAll();
                break;
            case 'api_licenses':
                $response['success'] = true;
                $response['data'] = $pdo->query("SELECT * FROM licenses")->fetchAll();
                break;
                
            case 'get_active_users':
                $stmt = $pdo->query("SELECT id, first_name, last_name, username, email, position FROM users WHERE status = 'active' ORDER BY first_name ASC, last_name ASC");
                $response['success'] = true;
                $response['data'] = $stmt->fetchAll();
                break;
            case 'get_license':
                $license_id = isset($_GET['license_id']) ? intval($_GET['license_id']) : 0;
                $stmt = $pdo->prepare("SELECT * FROM licenses WHERE id = ?");
                $stmt->execute([$license_id]);
                $license = $stmt->fetch();
                if($license) {
                    $response['success'] = true;
                    $response['data'] = $license;
                } else {
                    $response['message'] = 'License not found';
                }
                break;
            case 'get_accessory':
                $id = isset($_GET['accessory_id']) ? intval($_GET['accessory_id']) : 0;
                $stmt = $pdo->prepare("SELECT * FROM accessories WHERE id = ?");
                $stmt->execute([$id]);
                $accessory = $stmt->fetch();
                if($accessory) {
                    $response['success'] = true;
                    $response['data'] = $accessory;
                } else {
                    $response['message'] = 'Accessory not found';
                }
                break;
            case 'delete_accessory':
                if($_SESSION['user_role'] != 'admin') {
                    $response['message'] = 'Unauthorized';
                    break;
                }
                $acc = isset($_POST['accessory_id']) ? intval($_POST['accessory_id']) : 0;
                $stmt = $pdo->prepare("DELETE FROM accessories WHERE id = ?");
                if($stmt->execute([$acc])) {
                    $response['success'] = true;
                    $response['message'] = 'Accessory deleted';
                }
                break;
            case 'accessory_detail_html':
                $acc = isset($_GET['accessory_id']) ? intval($_GET['accessory_id']) : 0;
                ob_start();
                includeAccessoryDetail($pdo, $acc, true);
                $html = ob_get_clean();
                $response['success'] = true;
                $response['html'] = $html;
                break;
            case 'get_consumable':
                $cid = isset($_GET['consumable_id']) ? intval($_GET['consumable_id']) : 0;
                $stmt = $pdo->prepare("SELECT * FROM consumables WHERE id = ?");
                $stmt->execute([$cid]);
                $cons = $stmt->fetch();
                if($cons) {
                    $stmt2 = $pdo->prepare("SELECT IFNULL(SUM(quantity),0) FROM consumable_assignments WHERE consumable_id = ?");
                    $stmt2->execute([$cid]);
                    $used = intval($stmt2->fetchColumn());
                    $available = intval($cons['quantity']) - $used;
                    $cons['used_quantity'] = $used;
                    $cons['available'] = $available;
                    $response['success'] = true;
                    $response['data'] = $cons;
                } else {
                    $response['message'] = 'Item not found';
                }
                break;
            case 'api_accessories':
                $response['success'] = true;
                $response['data'] = $pdo->query("SELECT * FROM accessories")->fetchAll();
                break;
        }
        
    } catch(Exception $e) {
        $response['message'] = $e->getMessage();
    }
    
    echo json_encode($response);
    exit;
}

// Helper for creating notifications
function createNotification($pdo, $type, $title, $message, $user_id = null) {
    // If no specific user_id provided, create a notification for every user (notify all)
    if($user_id === null) {
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare("SELECT id FROM users");
            $stmt->execute();
            $users = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $ins = $pdo->prepare("INSERT INTO notifications (type, title, message, user_id) VALUES (?, ?, ?, ?)");
            foreach($users as $uid) {
                $ins->execute([$type, $title, $message, $uid]);
            }

            $pdo->commit();
        } catch(Exception $e) {
            $pdo->rollBack();
            throw $e;
        }
    } else {
        $stmt = $pdo->prepare("INSERT INTO notifications (type, title, message, user_id) VALUES (?, ?, ?, ?)");
        $stmt->execute([$type, $title, $message, $user_id]);
    }
}

// Include login page
function includeLoginPage($pdo) {
    ?>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <div class="card shadow">
                    <div class="card-header bg-white text-center">
                        <h3 class="mb-0">Snipe-IT v24.04 LTS</h3>
                        <p class="text-muted">Asset Management System</p>
                    </div>
                    <div class="card-body">
                        <?php if(isset($_SESSION['error'])): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <?php echo htmlspecialchars($_SESSION['error'] ?? ''); unset($_SESSION['error']); ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>
                        
                        <form method="POST">
                            <input type="hidden" name="action" value="login">
                            <div class="mb-3">
                                <label class="form-label">Username</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-user"></i></span>
                                    <input type="text" name="username" class="form-control" required autofocus>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Password</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                    <input type="password" name="password" class="form-control" required>
                                </div>
                            </div>
                            <div class="mb-3 form-check">
                                <input type="checkbox" class="form-check-input" id="remember">
                                <label class="form-check-label" for="remember">Remember me</label>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">Login</button>
                        </form>
                        <hr>
                        <div class="text-center">
                            <small class="text-muted">Default: admin / admin123</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
}

// Include install page
function includeInstallPage($pdo) {
    // Check if installation is complete
    $users_count = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    ?>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-header bg-white">
                        <h4 class="mb-0">System Installation</h4>
                    </div>
                    <div class="card-body">
                        <?php if($users_count > 0): ?>
                            <div class="alert alert-success">
                                <i class="fas fa-check-circle"></i> Database tables created successfully!
                            </div>
                            <p><strong>Default Login:</strong></p>
                            <ul>
                                <li>Username: admin</li>
                                <li>Password: admin123</li>
                            </ul>
                            <a href="?action=login" class="btn btn-primary">Go to Login</a>
                        <?php else: ?>
                            <div class="alert alert-warning">
                                <i class="fas fa-exclamation-triangle"></i> Installation incomplete. Please check database connection.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
}

// Include profile page
function includeProfilePage($pdo) {
    $user_id = $_SESSION['user_id'];
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    ?>
    
    <div class="container">
        <h2 class="mb-4">My Profile</h2>
        
        <div class="row">
            <div class="col-md-4">
                <div class="card text-center">
                    <div class="card-body">
                        <div class="mb-3">
                            <i class="fas fa-user-circle fa-5x text-secondary"></i>
                        </div>
                        <h4><?php echo htmlspecialchars(strval($user['first_name'] . ' ' . $user['last_name'])); ?></h4>
                        <p class="text-muted"><?php echo htmlspecialchars($user['position'] ?: 'No position set'); ?></p>
                        <span class="badge bg-<?php echo $user['role'] == 'admin' ? 'danger' : 'primary'; ?>">
                            <?php echo ucfirst($user['role']); ?>
                        </span>
                    </div>
                    <div class="card-footer text-muted">
                        Member since: <?php echo date('F j, Y', strtotime($user['created_at'])); ?>
                    </div>
                </div>
                
                <div class="card mt-3">
                    <div class="card-header">
                        <h5>Assigned Assets</h5>
                    </div>
                    <div class="card-body">
                        <?php
                        $stmt = $pdo->prepare("SELECT * FROM assets WHERE assigned_to = ?");
                        $stmt->execute([$user_id]);
                        $assets = $stmt->fetchAll();
                        ?>
                        <?php if(count($assets) > 0): ?>
                            <ul class="list-group">
                                <?php foreach($assets as $asset): ?>
                                <li class="list-group-item">
                                    <strong><?php echo htmlspecialchars($asset['name'] ?? ''); ?></strong>
                                    <br>
                                    <small>Tag: <?php echo htmlspecialchars($asset['asset_tag'] ?? ''); ?></small>
                                </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php else: ?>
                            <p class="text-muted">No assets assigned</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h5>Edit Profile</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <input type="hidden" name="action" value="update_profile">
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">First Name</label>
                                    <input type="text" name="first_name" class="form-control" 
                                           value="<?php echo htmlspecialchars($user['first_name'] ?? ''); ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Last Name</label>
                                    <input type="text" name="last_name" class="form-control" 
                                           value="<?php echo htmlspecialchars($user['last_name'] ?? ''); ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Email</label>
                                    <input type="email" name="email" class="form-control" 
                                           value="<?php echo htmlspecialchars($user['email'] ?? ''); ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Phone</label>
                                    <input type="text" name="phone" class="form-control" 
                                           value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Employee ID</label>
                                    <input type="text" class="form-control" 
                                           value="<?php echo htmlspecialchars($user['employee_id'] ?? ''); ?>" readonly>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Department</label>
                                    <input type="text" class="form-control" 
                                           value="<?php echo htmlspecialchars($user['department'] ?? ''); ?>" readonly>
                                </div>
                            </div>
                            
                            <hr>
                            <h6>Change Password (leave blank to keep current)</h6>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Current Password</label>
                                    <input type="password" name="current_password" class="form-control">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">New Password</label>
                                    <input type="password" name="new_password" class="form-control">
                                </div>
                            </div>
                            
                            <button type="submit" class="btn btn-primary">Update Profile</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
}

// Notifications page
function includeNotifications($pdo) {
    $user_id = $_SESSION['user_id'];
    // mark unread as read
    $stmt = $pdo->prepare("UPDATE notifications SET read_at = NOW() WHERE user_id = ? AND read_at IS NULL");
    $stmt->execute([$user_id]);

    $stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC");
    $stmt->execute([$user_id]);
    $notes = $stmt->fetchAll();
    ?>
    <div class="container">
        <h2>Notifications</h2>
        <table class="table">
            <thead>
                <tr><th>Type</th><th>Title</th><th>Message</th><th>When</th></tr>
            </thead>
            <tbody>
                <?php foreach($notes as $n): ?>
                <tr>
                    <td><?php echo htmlspecialchars($n['type'] ?? ''); ?></td>
                    <td><?php echo htmlspecialchars($n['title'] ?? ''); ?></td>
                    <td><?php echo htmlspecialchars($n['message'] ?? ''); ?></td>
                    <td><?php echo $n['created_at']; ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
}

// Include main content based on action
function includeMainContent($action, $pdo) {
    switch($action) {
        case 'dashboard':
            includeDashboard($pdo);
            break;
        case 'assets':
            includeAssets($pdo);
            break;
        case 'licenses':
            includeLicenses($pdo);
            break;
        case 'accessories':
            includeAccessoriesPage($pdo);
            break;
        case 'consumables':
            includeConsumables($pdo);
            break;
        case 'people':
            includePeople($pdo);
            break;
        case 'reports':
            includeReports($pdo);
            break;
        case 'settings':
            includeSettings($pdo);
            break;
        case 'notifications':
            includeNotifications($pdo);
            break;
        default:
            includeDashboard($pdo);
    }
}

// Dashboard
function includeDashboard($pdo) {
    // Get statistics
    $total_assets = $pdo->query("SELECT COUNT(*) FROM assets")->fetchColumn();
    $available_assets = $pdo->query("SELECT COUNT(*) FROM assets WHERE status = 'available'")->fetchColumn();
    $assigned_assets = $pdo->query("SELECT COUNT(*) FROM assets WHERE status = 'assigned'")->fetchColumn();
    $maintenance_assets = $pdo->query("SELECT COUNT(*) FROM assets WHERE status = 'maintenance'")->fetchColumn();
    
    $total_users = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $total_licenses = $pdo->query("SELECT COUNT(*) FROM licenses")->fetchColumn();
    $total_accessories = $pdo->query("SELECT SUM(quantity) FROM accessories")->fetchColumn() ?: 0;
    
    // Get recent activity
    $recent_activity = $pdo->query("SELECT ah.*, a.name as asset_name, a.asset_tag, u.username 
                                   FROM asset_history ah 
                                   LEFT JOIN assets a ON ah.asset_id = a.id 
                                   LEFT JOIN users u ON ah.user_id = u.id 
                                   ORDER BY ah.created_at DESC LIMIT 10")->fetchAll();
    
    // Get expiring licenses
    $expiring_licenses = $pdo->query("SELECT * FROM licenses 
                                     WHERE expiration_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
                                     ORDER BY expiration_date")->fetchAll();
    
    // Get low stock accessories
    $low_stock = $pdo->query("SELECT * FROM accessories WHERE quantity <= min_quantity AND min_quantity > 0")->fetchAll();
    ?>
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Dashboard</h2>
        <div class="d-flex">
            <input type="text" class="search-box me-2" placeholder="Quick search..." id="quickSearch" onkeyup="quickSearch(this.value)">
            <button class="btn btn-primary" onclick="refreshDashboard()">
                <i class="fas fa-sync-alt"></i> Refresh
            </button>
        </div>
    </div>
    
    <!-- Statistics Cards -->
    <div class="row">
        <div class="col-md-3">
            <div class="card stat-card">
                <div class="card-body">
                    <h5 class="card-title">Total Assets</h5>
                    <h2><?php echo number_format($total_assets); ?></h2>
                    <i class="fas fa-laptop stat-icon"></i>
                    <p class="mb-0">
                        <span class="text-success"><?php echo $available_assets; ?> available</span> |
                        <span class="text-warning"><?php echo $assigned_assets; ?> assigned</span>
                    </p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card stat-card" style="background: linear-gradient(45deg, #E74C3C, #C0392B);">
                <div class="card-body">
                    <h5 class="card-title">Licenses</h5>
                    <h2><?php echo number_format($total_licenses); ?></h2>
                    <i class="fas fa-key stat-icon"></i>
                    <p class="mb-0"><?php echo count($expiring_licenses); ?> expiring soon</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card stat-card" style="background: linear-gradient(45deg, #3498DB, #2980B9);">
                <div class="card-body">
                    <h5 class="card-title">Users</h5>
                    <h2><?php echo number_format($total_users); ?></h2>
                    <i class="fas fa-users stat-icon"></i>
                    <p class="mb-0">Active employees</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card stat-card" style="background: linear-gradient(45deg, #F39C12, #E67E22);">
                <div class="card-body">
                    <h5 class="card-title">Accessories</h5>
                    <h2><?php echo number_format($total_accessories); ?></h2>
                    <i class="fas fa-mouse stat-icon"></i>
                    <p class="mb-0"><?php echo count($low_stock); ?> low stock items</p>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Quick Search Results -->
    <div class="card mt-3" id="quickSearchResults" style="display: none;">
        <div class="card-header">
            <h5>Search Results</h5>
        </div>
        <div class="card-body">
            <div id="searchResults"></div>
        </div>
    </div>
    
    <!-- Charts Row -->
    <div class="row mt-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Asset Status Distribution</h5>
                </div>
                <div class="card-body">
                    <canvas id="assetChart" style="height: 300px;"></canvas>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Recent Activity</h5>
                </div>
                <div class="card-body">
                    <div class="list-group">
                        <?php foreach($recent_activity as $activity): ?>
                        <div class="list-group-item">
                            <div class="d-flex w-100 justify-content-between">
                                <h6 class="mb-1"><?php echo ucfirst($activity['action']); ?></h6>
                                <small><?php echo date('Y-m-d H:i', strtotime($activity['created_at'])); ?></small>
                            </div>
                            <p class="mb-1">
                                <strong>Asset:</strong> <?php echo htmlspecialchars($activity['asset_name'] ?: 'Unknown'); ?> 
                                (<?php echo htmlspecialchars($activity['asset_tag'] ?? ''); ?>)
                            </p>
                            <small>By: <?php echo htmlspecialchars($activity['username'] ?: 'System'); ?></small>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Expiring Licenses -->
    <?php if(count($expiring_licenses) > 0): ?>
    <div class="row mt-4">
        <div class="col-12">
            <div class="card border-warning">
                <div class="card-header bg-warning text-white">
                    <h5 class="mb-0"><i class="fas fa-exclamation-triangle"></i> Expiring Licenses (Next 30 Days)</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>License</th>
                                    <th>Product Key</th>
                                    <th>Seats</th>
                                    <th>Expiration Date</th>
                                    <th>Days Left</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($expiring_licenses as $license): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($license['name'] ?? ''); ?></td>
                                    <td><?php echo htmlspecialchars($license['product_key'] ?? ''); ?></td>
                                    <td><?php echo $license['seats']; ?></td>
                                    <td><?php echo $license['expiration_date']; ?></td>
                                    <td>
                                        <?php 
                                        $days = ceil((strtotime($license['expiration_date']) - time()) / (60 * 60 * 24));
                                        $badge_class = $days <= 7 ? 'danger' : ($days <= 14 ? 'warning' : 'info');
                                        ?>
                                        <span class="badge bg-<?php echo $badge_class; ?>"><?php echo $days; ?> days</span>
                                    </td>
                                    <td>
                                        <?php if($days <= 7): ?>
                                        <span class="badge bg-danger">Critical</span>
                                        <?php elseif($days <= 14): ?>
                                        <span class="badge bg-warning">Warning</span>
                                        <?php else: ?>
                                        <span class="badge bg-info">Notice</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- Low Stock Alerts -->
    <?php if(count($low_stock) > 0): ?>
    <div class="row mt-4">
        <div class="col-12">
            <div class="card border-danger">
                <div class="card-header bg-danger text-white">
                    <h5 class="mb-0"><i class="fas fa-exclamation-circle"></i> Low Stock Alerts</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Accessory</th>
                                    <th>Current Quantity</th>
                                    <th>Minimum Quantity</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($low_stock as $item): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($item['name'] ?? ''); ?></td>
                                    <td class="text-danger fw-bold"><?php echo $item['quantity']; ?></td>
                                    <td><?php echo $item['min_quantity']; ?></td>
                                    <td><span class="badge bg-danger">Low Stock</span></td>
                                    <td>
                                        <button class="btn btn-sm btn-primary" onclick="reorderItem(<?php echo $item['id']; ?>)">
                                            Reorder
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    
    <script>
        // Initialize chart
        const ctx = document.getElementById('assetChart').getContext('2d');
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Available', 'Assigned', 'Maintenance', 'Retired'],
                datasets: [{
                    data: [<?php echo $available_assets; ?>, <?php echo $assigned_assets; ?>, <?php echo $maintenance_assets; ?>, 0],
                    backgroundColor: ['#28a745', '#007bff', '#dc3545', '#6c757d']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
        
        function quickSearch(term) {
            if(term.length < 2) {
                document.getElementById('quickSearchResults').style.display = 'none';
                return;
            }
            
            fetch('?ajax=search_assets&term=' + encodeURIComponent(term))
                .then(response => response.json())
                .then(data => {
                    if(data.success && data.data.length > 0) {
                        let html = '<table class="table"><thead><tr><th>Asset Tag</th><th>Name</th><th>Status</th><th>Action</th></tr></thead><tbody>';
                        data.data.forEach(asset => {
                            html += `<tr>
                                <td>${asset.asset_tag}</td>
                                <td>${asset.name}</td>
                                <td><span class="badge badge-${asset.status}">${asset.status}</span></td>
                            </tr>`;
                        });
                        html += '</tbody></table>';
                        document.getElementById('searchResults').innerHTML = html;
                        document.getElementById('quickSearchResults').style.display = 'block';
                    } else {
                        document.getElementById('searchResults').innerHTML = '<p class="text-muted">No results found</p>';
                        document.getElementById('quickSearchResults').style.display = 'block';
                    }
                });
        }
        
        function refreshDashboard() {
            location.reload();
        }
        
        function viewAsset(id) {
            // Load asset details into modal via AJAX and show with loading UX
            const modalEl = document.getElementById('viewAssetModal');
            modalEl.dataset.assetId = id;  // Store asset ID for refresh
            setModalLoading(modalEl, true);
            document.getElementById('viewAssetContent').innerHTML = '<div class="text-center py-4">Loading <span class="spinner-border spinner-border-sm modal-spinner" role="status" aria-hidden="true"></span></div>';
            const m = new bootstrap.Modal(modalEl);
            m.show();

            fetch('?ajax=asset_detail_html&asset_id=' + id)
                .then(response => response.json())
                .then(data => {
                    if(data.success && data.html) {
                        document.getElementById('viewAssetContent').innerHTML = data.html;
                        setModalLoading(modalEl, false);
                        // Initialize QR code for injected content
                        initializeQRCodeInModal();
                        // Reattach form submit handlers for injected forms
                        attachFormSubmitHandlers();
                        focusFirstInput(modalEl);
                    } else {
                        document.getElementById('viewAssetContent').innerHTML = '<div class="alert alert-danger">Failed to load asset details</div>';
                        setModalLoading(modalEl, false);
                    }
                })
                .catch(err => {
                    console.error('Error loading asset details:', err);
                    document.getElementById('viewAssetContent').innerHTML = '<div class="alert alert-danger">Failed to load asset details</div>';
                    setModalLoading(modalEl, false);
                });
        }
        
        function closeAssetDetailModal() {
            const modalEl = document.getElementById('viewAssetModal');
            const m = bootstrap.Modal.getInstance(modalEl);
            if(m) m.hide();
        }
        
        function initializeQRCodeInModal() {
            const contentContainer = document.getElementById('viewAssetContent');
            const qrcodeDiv = contentContainer.querySelector('#qrcode');
            if(qrcodeDiv) {
                const assetTag = contentContainer.querySelector('[data-asset-tag]')?.getAttribute('data-asset-tag');
                if(assetTag) {
                    // Clear any existing QR code first
                    qrcodeDiv.innerHTML = '';
                    generateQRCode('qrcode', assetTag.trim());
                }
            }
        }
        
        function attachFormSubmitHandlers() {
            const contentContainer = document.getElementById('viewAssetContent');
            const modalForms = contentContainer.querySelectorAll('form');
            modalForms.forEach(form => {
                form.addEventListener('submit', function(event) {
                    const modalEl = document.getElementById('viewAssetModal');
                    setModalLoading(modalEl, true);
                    const submit = form.querySelector('button[type=submit]');
                    if(submit) {
                        submit.disabled = true;
                    }
                }, { once: true });
            });
        }
        
        function reorderItem(id) {
            alert('Reorder functionality would be implemented here');
        }
    </script>
    <?php
}

// Assets Management
function includeAssets($pdo) {
    // Handle view single asset
    if(isset($_GET['view'])) {
        includeAssetDetail($pdo, intval($_GET['view']), false);
        return;
    }
    
    $assets = $pdo->query("SELECT a.*, c.name as category_name, m.name as manufacturer_name, l.name as location_name, 
                          CONCAT(u.first_name, ' ', u.last_name) as assigned_user 
                          FROM assets a 
                          LEFT JOIN categories c ON a.category_id = c.id 
                          LEFT JOIN manufacturers m ON a.manufacturer_id = m.id 
                          LEFT JOIN locations l ON a.location_id = l.id 
                          LEFT JOIN users u ON a.assigned_to = u.id 
                          ORDER BY a.created_at DESC")->fetchAll();
    
    // include position/department since checkout dropdown shows them
    $users = $pdo->query("SELECT id, first_name, last_name, username, email, position, department FROM users WHERE status = 'active' ORDER BY first_name, last_name")->fetchAll();
    $categories = $pdo->query("SELECT * FROM categories WHERE type = 'asset' OR type = 'all' ORDER BY name")->fetchAll();
    $manufacturers = $pdo->query("SELECT * FROM manufacturers ORDER BY name")->fetchAll();
    $locations = $pdo->query("SELECT * FROM locations ORDER BY name")->fetchAll();
    ?>
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Assets Management</h2>
        <div>
            <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addAssetModal">
                <i class="fas fa-plus"></i> Add Asset
            </button>
            <button class="btn btn-secondary ms-2" data-bs-toggle="modal" data-bs-target="#importAssetsModal">
                <i class="fas fa-file-import"></i> Import CSV
            </button>
            <div class="btn-group ms-2">
                <button class="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                    <i class="fas fa-download"></i> Export
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="#" onclick="exportToCSV('assets-table', 'assets_export')">CSV</a></li>
                    <li><a class="dropdown-item" href="#" onclick="exportToPDF()">PDF</a></li>
                    <li><a class="dropdown-item" href="#" onclick="printContent('assets-table')">Print</a></li>
                </ul>
            </div>
        </div>
    </div>
    
    <!-- Filters -->
    <div class="card mb-3">
        <div class="card-body">
            <div class="row">
                <div class="col-md-3">
                    <input type="text" class="search-box" placeholder="Search assets..." id="assetSearch" 
                           onkeyup="liveSearch(this, '#assets-table')">
                </div>
                <div class="col-md-2">
                    <select class="form-select" id="statusFilter" onchange="filterAssets()">
                        <option value="">All Status</option>
                        <option value="available">Available</option>
                        <option value="assigned">Assigned</option>
                        <option value="maintenance">Maintenance</option>
                        <option value="retired">Retired</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <select class="form-select" id="categoryFilter" onchange="filterAssets()">
                        <option value="">All Categories</option>
                        <?php foreach($categories as $category): ?>
                        <option value="<?php echo $category['id']; ?>" style="color: <?php echo $category['color'] ?? '#000'; ?>;">● <?php echo htmlspecialchars($category['name'] ?? '') . ' (' . ucfirst($category['type'] ?? 'asset') . ')'; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <select class="form-select" id="locationFilter" onchange="filterAssets()">
                        <option value="">All Locations</option>
                        <?php foreach($locations as $location): ?>
                        <option value="<?php echo $location['id']; ?>"><?php echo htmlspecialchars($location['name'] ?? '') . ($location['address'] ? ' - ' . htmlspecialchars($location['address']) : '') . ($location['city'] ? ', ' . htmlspecialchars($location['city']) : '') . ($location['state'] ? ', ' . htmlspecialchars($location['state']) : ''); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <button class="btn btn-secondary" onclick="resetFilters()">Reset Filters</button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Assets Table -->
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover datatable" id="assets-table">
                    <thead>
                        <tr>
                            <th>Asset Tag</th>
                            <th>Name</th>
                            <th>Model</th>
                            <th>Serial</th>
                            <th>Category</th>
                            <th>Manufacturer</th>
                            <th>Location</th>
                            <th>Assigned To</th>
                            <th>Status</th>
                            <th>Purchase Date</th>
                            <th>QR Code</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($assets as $asset): ?>
                        <tr data-status="<?php echo $asset['status']; ?>" 
                            data-category="<?php echo $asset['category_id']; ?>"
                            data-location="<?php echo $asset['location_id']; ?>">
                            <td><strong><?php echo htmlspecialchars($asset['asset_tag'] ?? ''); ?></strong></td>
                            <td><?php echo htmlspecialchars($asset['name'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($asset['model'] ?? '-'); ?></td>
                            <td><?php echo htmlspecialchars($asset['serial'] ?? '-'); ?></td>
                            <td><?php echo htmlspecialchars($asset['category_name'] ?? '-'); ?></td>
                            <td><?php echo htmlspecialchars($asset['manufacturer_name'] ?? '-'); ?></td>
                            <td><?php echo htmlspecialchars($asset['location_name'] ?? '-'); ?></td>
                            <td>
                                <?php if($asset['assigned_to']): ?>
                                    <span class="badge bg-info"><?php echo htmlspecialchars($asset['assigned_user'] ?? 'Unknown User'); ?></span>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge-status badge-<?php echo $asset['status']; ?>">
                                    <?php echo ucfirst($asset['status']); ?>
                                </span>
                            </td>
                            <td><?php echo $asset['purchase_date'] ? date('Y-m-d', strtotime($asset['purchase_date'])) : '-'; ?></td>
                            <td>
                                <button class="btn btn-sm btn-outline-secondary" onclick="showQR('<?php echo $asset['qr_code']; ?>')">
                                    <i class="fas fa-qrcode"></i>
                                </button>
                            </td>
                            <td>
                                <div class="btn-group">
                                    <?php if($asset['status'] == 'available'): ?>
                                    <button class="btn btn-sm btn-success" onclick="checkoutAsset(<?php echo $asset['id']; ?>)">
                                        <i class="fas fa-sign-out-alt"></i>
                                    </button>
                                    <?php elseif($asset['status'] == 'assigned'): ?>
                                    <button class="btn btn-sm btn-warning" onclick="checkinAsset(<?php echo $asset['id']; ?>)">
                                        <i class="fas fa-sign-in-alt"></i>
                                    </button>
                                    <?php endif; ?>
                                    <button class="btn btn-sm btn-primary" onclick="editAsset(<?php echo $asset['id']; ?>)">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <?php if($_SESSION['user_role'] == 'admin'): ?>
                                    <button class="btn btn-sm btn-danger" onclick="deleteAsset(<?php echo $asset['id']; ?>)">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Add Asset Modal -->
    <div class="modal fade" id="addAssetModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Asset <span class="spinner-border spinner-border-sm modal-spinner" role="status" aria-hidden="true"></span></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST">
                    <input type="hidden" name="action" value="add_asset">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Asset Tag *</label>
                                <input type="text" name="asset_tag" class="form-control" required 
                                       value="ASSET-<?php echo date('Ymd') . '-' . rand(100, 999); ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Name *</label>
                                <input type="text" name="name" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Serial Number</label>
                                <input type="text" name="serial" class="form-control">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Model</label>
                                <input type="text" name="model" class="form-control">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Category</label>
                                <select name="category_id" class="form-select">
                                    <option value="">Select Category</option>
                                    <?php foreach($categories as $category): ?>
                                    <option value="<?php echo $category['id']; ?>" style="color: <?php echo $category['color'] ?? '#000'; ?>;">● <?php echo htmlspecialchars($category['name'] ?? '') . ' (' . ucfirst($category['type'] ?? 'asset') . ')'; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Manufacturer</label>
                                <select name="manufacturer_id" class="form-select">
                                    <option value="">Select Manufacturer</option>
                                    <?php foreach($manufacturers as $manufacturer): ?>
                                    <option value="<?php echo $manufacturer['id']; ?>"><?php echo htmlspecialchars($manufacturer['name'] ?? ''); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Location</label>
                                <select name="location_id" class="form-select">
                                    <option value="">Select Location</option>
                                    <?php foreach($locations as $location): ?>
                                    <option value="<?php echo $location['id']; ?>"><?php echo htmlspecialchars($location['name'] ?? '') . ($location['address'] ? ' - ' . htmlspecialchars($location['address']) : '') . ($location['city'] ? ', ' . htmlspecialchars($location['city']) : '') . ($location['state'] ? ', ' . htmlspecialchars($location['state']) : ''); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Purchase Date</label>
                                <input type="date" name="purchase_date" class="form-control" value="<?php echo date('Y-m-d'); ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Purchase Cost</label>
                                <div class="input-group">
                                    <span class="input-group-text">$</span>

                                    <input type="number" step="0.01" name="purchase_cost" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Status</label>
                                <select name="status" class="form-select">
                                    <option value="available">Available</option>
                                    <option value="maintenance">Maintenance</option>
                                    <option value="retired">Retired</option>
                                </select>
                            </div>
                            <div class="col-md-12 mb-3">
                                <label class="form-label">Notes</label>
                                <textarea name="notes" class="form-control" rows="3"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <div class="modal-actions">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">Add Asset</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Import Assets Modal -->
    <div class="modal fade" id="importAssetsModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Import Assets from CSV <span class="spinner-border spinner-border-sm modal-spinner" role="status" aria-hidden="true"></span></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="post" enctype="multipart/form-data">
                    <input type="hidden" name="action" value="import_assets">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="csvFile" class="form-label">CSV File</label>
                            <input type="file" class="form-control" id="csvFile" name="csv_file" accept=".csv" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <div class="modal-actions">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Upload</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    
    <!-- Edit Asset Modal -->
    <div class="modal fade" id="editAssetModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Asset <span class="spinner-border spinner-border-sm modal-spinner" role="status" aria-hidden="true"></span></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST">
                    <input type="hidden" name="action" value="update_asset">
                    <input type="hidden" name="asset_id" id="edit_asset_id">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Asset Tag *</label>
                                <input type="text" name="asset_tag" id="edit_asset_tag" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Name *</label>
                                <input type="text" name="name" id="edit_name" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Serial Number</label>
                                <input type="text" name="serial" id="edit_serial" class="form-control">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Model</label>
                                <input type="text" name="model" id="edit_model" class="form-control">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Category</label>
                                <select name="category_id" id="edit_category_id" class="form-select">
                                    <option value="">Select Category</option>
                                    <?php foreach($categories as $category): ?>
                                    <option value="<?php echo $category['id']; ?>" style="color: <?php echo $category['color'] ?? '#000'; ?>;">● <?php echo htmlspecialchars($category['name'] ?? '') . ' (' . ucfirst($category['type'] ?? 'asset') . ')'; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Manufacturer</label>
                                <select name="manufacturer_id" id="edit_manufacturer_id" class="form-select">
                                    <option value="">Select Manufacturer</option>
                                    <?php foreach($manufacturers as $manufacturer): ?>
                                    <option value="<?php echo $manufacturer['id']; ?>"><?php echo htmlspecialchars($manufacturer['name'] ?? ''); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Location</label>
                                <select name="location_id" id="edit_location_id" class="form-select">
                                    <option value="">Select Location</option>
                                    <?php foreach($locations as $location): ?>
                                    <option value="<?php echo $location['id']; ?>"><?php echo htmlspecialchars($location['name'] ?? '') . ($location['address'] ? ' - ' . htmlspecialchars($location['address']) : '') . ($location['city'] ? ', ' . htmlspecialchars($location['city']) : '') . ($location['state'] ? ', ' . htmlspecialchars($location['state']) : ''); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Purchase Date</label>
                                <input type="date" name="purchase_date" id="edit_purchase_date" class="form-control">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Purchase Cost</label>
                                <div class="input-group">
                                    <span class="input-group-text">$</span>
                                    <input type="number" step="0.01" name="purchase_cost" id="edit_purchase_cost" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Status</label>
                                <select name="status" id="edit_status" class="form-select">
                                    <option value="available">Available</option>
                                    <option value="assigned">Assigned</option>
                                    <option value="maintenance">Maintenance</option>
                                    <option value="retired">Retired</option>
                                </select>
                            </div>
                            <div class="col-md-12 mb-3">
                                <label class="form-label">Notes</label>
                                <textarea name="notes" id="edit_notes" class="form-control" rows="3"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <div class="modal-actions">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">Update Asset</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script>
        function editAsset(assetId) {
            // Fetch asset data
            fetch('?ajax=get_asset&asset_id=' + assetId)
                .then(response => response.json())
                .then(data => {
                    if(data.success && data.data) {
                        const asset = data.data;
                        // Populate form fields
                        document.getElementById('edit_asset_id').value = asset.id;
                        document.getElementById('edit_asset_tag').value = asset.asset_tag;
                        document.getElementById('edit_name').value = asset.name;
                        document.getElementById('edit_serial').value = asset.serial;
                        document.getElementById('edit_model').value = asset.model;
                        document.getElementById('edit_category_id').value = asset.category_id || '';
                        document.getElementById('edit_manufacturer_id').value = asset.manufacturer_id || '';
                        document.getElementById('edit_location_id').value = asset.location_id || '';
                        document.getElementById('edit_purchase_date').value = asset.purchase_date || '';
                        document.getElementById('edit_purchase_cost').value = asset.purchase_cost || '';
                        document.getElementById('edit_status').value = asset.status;
                        document.getElementById('edit_notes').value = asset.notes || '';
                        
                        // Show modal
                        new bootstrap.Modal(document.getElementById('editAssetModal')).show();
                    } else {
                        showToast('error', 'Failed to load asset details');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showToast('error', 'Error loading asset');
                });
        }
        
        function deleteAsset(assetId) {
            if(confirm('Are you sure you want to delete this asset? This action cannot be undone.')) {
                fetch('?ajax=delete_asset', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'asset_id=' + assetId
                })
                .then(response => response.json())
                .then(data => {
                    if(data.success) {
                        showToast('success', 'Asset deleted successfully');
                        location.reload();
                    } else {
                        showToast('error', data.message || 'Failed to delete asset');
                    }
                });
            }
        }
        
        function filterAssets() {
            const status = document.getElementById('statusFilter').value;
            const category = document.getElementById('categoryFilter').value;
            const location = document.getElementById('locationFilter').value;
            const rows = document.querySelectorAll('#assets-table tbody tr');
            
            rows.forEach(row => {
                let show = true;
                if(status && row.dataset.status !== status) show = false;
                if(category && row.dataset.category !== category) show = false;
                if(location && row.dataset.location !== location) show = false;
                row.style.display = show ? '' : 'none';
            });
        }
        
        function resetFilters() {
            document.getElementById('statusFilter').value = '';
            document.getElementById('categoryFilter').value = '';
            document.getElementById('locationFilter').value = '';
            document.getElementById('assetSearch').value = '';
            const rows = document.querySelectorAll('#assets-table tbody tr');
            rows.forEach(row => row.style.display = '');
        }
        
        function exportToPDF() {
            const element = document.getElementById('assets-table');
            const opt = {
                margin: 10,
                filename: 'assets_export_' + new Date().toISOString().split('T')[0] + '.pdf',
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { scale: 2 },
                jsPDF: { orientation: 'landscape', unit: 'mm', format: 'a4' }
            };
            
            // Check if html2pdf is loaded
            if (typeof html2pdf !== 'undefined') {
                html2pdf().set(opt).from(element).save();
            } else {
                // Fallback if library not loaded
                showToast('warning', 'PDF library loading, trying export...');
                // Load library dynamically
                const script = document.createElement('script');
                script.src = 'https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js';
                script.onload = function() {
                    html2pdf().set(opt).from(element).save();
                };
                document.head.appendChild(script);
            }
        }
        
        // Auto-refresh after checkout/checkin - modal-aware refresh
        function setupCheckoutCheckinRefresh() {
            const checkoutForm = document.querySelector('#checkoutModal form');
            if(checkoutForm) {
                // Remove old listeners if any
                const newCheckoutForm = checkoutForm.cloneNode(true);
                checkoutForm.parentNode.replaceChild(newCheckoutForm, checkoutForm);
                
                newCheckoutForm.addEventListener('submit', function() {
                    setTimeout(function() {
                        // If asset detail modal is open, reload it; otherwise reload page
                        const assetModal = document.getElementById('viewAssetModal');
                        if(assetModal && bootstrap.Modal.getInstance(assetModal)) {
                            const assetId = assetModal.dataset.assetId;
                            if(assetId) {
                                viewAsset(assetId);
                            } else {
                                location.reload();
                            }
                        } else {
                            location.reload();
                        }
                    }, 500);
                });
            }
            
            const checkinForm = document.querySelector('#checkinModal form');
            if(checkinForm) {
                // Remove old listeners if any
                const newCheckinForm = checkinForm.cloneNode(true);
                checkinForm.parentNode.replaceChild(newCheckinForm, checkinForm);
                
                newCheckinForm.addEventListener('submit', function() {
                    setTimeout(function() {
                        // If asset detail modal is open, reload it; otherwise reload page
                        const assetModal = document.getElementById('viewAssetModal');
                        if(assetModal && bootstrap.Modal.getInstance(assetModal)) {
                            const assetId = assetModal.dataset.assetId;
                            if(assetId) {
                                viewAsset(assetId);
                            } else {
                                location.reload();
                            }
                        } else {
                            location.reload();
                        }
                    }, 500);
                });
            }
        }
        
        document.addEventListener('DOMContentLoaded', function() {
            setupCheckoutCheckinRefresh();
        });
        
        // Also set up refresh when modals are shown
        document.addEventListener('shown.bs.modal', function(e) {
            if(e.target.id === 'checkoutModal' || e.target.id === 'checkinModal') {
                setupCheckoutCheckinRefresh();
            }
        });
    </script>
    <?php
}

// Asset Detail View
function includeAssetDetail($pdo, $asset_id, $isModal = false) {
    $stmt = $pdo->prepare("SELECT a.*, c.name as category_name, m.name as manufacturer_name, 
                          l.name as location_name, 
                          CONCAT_WS(' ', u.first_name, u.last_name) as assigned_user,
                          u.email as assigned_email, u.employee_id as assigned_employee_id,
                          u.phone as assigned_phone, u.position as assigned_position, 
                          u.department as assigned_department, u.location as assigned_location,
                          u.username as assigned_username
                          FROM assets a 
                          LEFT JOIN categories c ON a.category_id = c.id 
                          LEFT JOIN manufacturers m ON a.manufacturer_id = m.id 
                          LEFT JOIN locations l ON a.location_id = l.id 
                          LEFT JOIN users u ON a.assigned_to = u.id 
                          WHERE a.id = ?");
    $stmt->execute([$asset_id]);
    $asset = $stmt->fetch();
    
    if(!$asset) {
        echo '<div class="alert alert-danger">Asset not found</div>';
        return;
    }
    
    // Get history
    $stmt = $pdo->prepare("SELECT ah.*, u.username, u.first_name, u.last_name 
                          FROM asset_history ah 
                          LEFT JOIN users u ON ah.user_id = u.id 
                          WHERE ah.asset_id = ? 
                          ORDER BY ah.created_at DESC");
    $stmt->execute([$asset_id]);
    $history = $stmt->fetchAll();
    
    // Get users for checkout dropdown
    $users = $pdo->query("SELECT id, first_name, last_name, username, email, position, department FROM users WHERE status = 'active' ORDER BY first_name, last_name")->fetchAll();
    ?>
    
    <?php if(!$isModal): ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 data-asset-tag="<?php echo htmlspecialchars($asset['asset_tag'] ?? ''); ?>">Asset Details: <?php echo htmlspecialchars($asset['name'] ?? ''); ?></h2>
        <div>
            <a href="?action=assets" class="btn btn-primary">
                <i class="fas fa-arrow-left"></i> Back to Assets
            </a>
            <button class="btn btn-info" onclick="printContent('asset-detail')">
                <i class="fas fa-print"></i> Print
            </button>
        </div>
    </div>
    <?php endif; ?>
    
    <div class="row" id="asset-detail">
        <div class="col-md-8">
            <div class="card mb-3">
                <div class="card-header">
                    <h5>Asset Information</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <tr>
                                    <th>Asset Tag:</th>
                                    <td><?php echo htmlspecialchars($asset['asset_tag'] ?? ''); ?></td>
                                </tr>
                                <tr>
                                    <th>Name:</th>
                                    <td><?php echo htmlspecialchars($asset['name'] ?? ''); ?></td>
                                </tr>
                                <tr>
                                    <th>Model:</th>
                                    <td><?php echo htmlspecialchars($asset['model'] ?? '-'); ?></td>
                                </tr>
                                <tr>
                                    <th>Serial Number:</th>
                                    <td><?php echo htmlspecialchars($asset['serial'] ?? '-'); ?></td>
                                </tr>
                                <tr>
                                    <th>Category:</th>
                                    <td><?php echo htmlspecialchars($asset['category_name'] ?? '-'); ?></td>
                                </tr>
                                <tr>
                                    <th>Manufacturer:</th>
                                    <td><?php echo htmlspecialchars($asset['manufacturer_name'] ?? '-'); ?></td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <tr>
                                    <th>Location:</th>
                                    <td><?php echo htmlspecialchars($asset['location_name'] ?? '-'); ?></td>
                                </tr>
                                <tr>
                                    <th>Status:</th>
                                    <td>
                                        <span class="badge-status badge-<?php echo $asset['status']; ?>">
                                            <?php echo ucfirst($asset['status']); ?>
                                        </span>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Purchase Date:</th>
                                    <td><?php echo $asset['purchase_date'] ? date('Y-m-d', strtotime($asset['purchase_date'])) : '-'; ?></td>
                                </tr>
                                <tr>
                                    <th>Purchase Cost:</th>
                                    <td>$<?php echo number_format($asset['purchase_cost'], 2); ?></td>
                                </tr>
                                <tr>
                                    <th>Warranty:</th>
                                    <td>
                                        <?php if($asset['warranty_expires']): ?>
                                            <?php echo date('Y-m-d', strtotime($asset['warranty_expires'])); ?>
                                            (<?php 
                                                $days = ceil((strtotime($asset['warranty_expires']) - time()) / (60 * 60 * 24));
                                                echo $days > 0 ? "$days days left" : "Expired";
                                            ?>)
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    
                    <?php if($asset['notes']): ?>
                    <div class="mt-3">
                        <h6>Notes:</h6>
                        <p class="text-muted"><?php echo nl2br(htmlspecialchars($asset['notes'] ?? '')); ?></p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h5>Assignment History</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Action</th>
                                    <th>User</th>
                                    <th>Notes</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($history as $record): ?>
                                <tr>
                                    <td><?php echo date('Y-m-d H:i', strtotime($record['created_at'])); ?></td>
                                    <td>
                                        <span class="badge bg-<?php 
                                            echo $record['action'] == 'checked_out' ? 'success' : 
                                                ($record['action'] == 'checked_in' ? 'warning' : 'info'); 
                                        ?>">
                                            <?php echo ucfirst($record['action']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo htmlspecialchars(trim(($record['first_name'] ?? '') . ' ' . ($record['last_name'] ?? '')) ?: 'Unknown User'); ?></td>
                                    <td><?php echo htmlspecialchars($record['notes'] ?? '-'); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card mb-3">
                <div class="card-header">
                    <h5>Current Assignment</h5>
                </div>
                <div class="card-body">
                    <?php if($asset['assigned_to']): ?>
                        <div class="mb-3">
                            <h6 class="text-primary"><?php echo htmlspecialchars($asset['assigned_user'] ?? 'Unknown User'); ?></h6>
                            <?php if($asset['assigned_position']): ?>
                            <p class="mb-1"><small class="text-muted"><strong>Position:</strong> <?php echo htmlspecialchars($asset['assigned_position'] ?? ''); ?></small></p>
                            <?php endif; ?>
                            <?php if($asset['assigned_department']): ?>
                            <p class="mb-1"><small class="text-muted"><strong>Department:</strong> <?php echo htmlspecialchars($asset['assigned_department'] ?? ''); ?></small></p>
                            <?php endif; ?>
                            <?php if($asset['assigned_email']): ?>
                            <p class="mb-1"><small class="text-muted"><strong>Email:</strong> <a href="mailto:<?php echo htmlspecialchars($asset['assigned_email'] ?? ''); ?>"><?php echo htmlspecialchars($asset['assigned_email'] ?? ''); ?></a></small></p>
                            <?php endif; ?>
                            <?php if($asset['assigned_phone']): ?>
                            <p class="mb-1"><small class="text-muted"><strong>Phone:</strong> <?php echo htmlspecialchars($asset['assigned_phone'] ?? ''); ?></small></p>
                            <?php endif; ?>
                            <?php if($asset['assigned_employee_id']): ?>
                            <p class="mb-1"><small class="text-muted"><strong>Employee ID:</strong> <?php echo htmlspecialchars($asset['assigned_employee_id'] ?? ''); ?></small></p>
                            <?php endif; ?>
                            <?php if($asset['assigned_location']): ?>
                            <p class="mb-1"><small class="text-muted"><strong>Location:</strong> <?php echo htmlspecialchars($asset['assigned_location'] ?? ''); ?></small></p>
                            <?php endif; ?>
                        </div>
                        <form method="POST">
                            <input type="hidden" name="action" value="checkin_asset">
                            <input type="hidden" name="asset_id" value="<?php echo $asset['id']; ?>">
                            <?php if(isset($_GET['view'])): ?>
                            <input type="hidden" name="return_to_view" value="1">
                            <?php endif; ?>
                            <div class="mb-3">
                                <label class="form-label">Return Notes</label>
                                <textarea name="notes" class="form-control" rows="2" placeholder="Condition on return..."></textarea>
                            </div>
                            <button type="submit" class="btn btn-warning w-100">
                                <i class="fas fa-sign-in-alt"></i> Return Asset
                            </button>
                        </form>
                    <?php else: ?>
                        <div class="alert alert-info mb-3">
                            <i class="fas fa-info-circle"></i> This asset is currently available
                        </div>
                        <form method="POST">
                            <input type="hidden" name="action" value="checkout_asset">
                            <input type="hidden" name="asset_id" value="<?php echo $asset['id']; ?>">
                            <?php if(isset($_GET['view'])): ?>
                            <input type="hidden" name="return_to_view" value="1">
                            <?php endif; ?>
                            <div class="mb-3">
                                <label class="form-label">Assign to User *</label>
                                <select name="user_id" class="form-select" required>
                                    <option value="">-- Select User --</option>
                                    <?php foreach($users as $user): ?>
                                    <option value="<?php echo $user['id']; ?>">
                                        <?php echo htmlspecialchars(strval($user['first_name'] . ' ' . $user['last_name'] . ' (' . $user['username'] . ')')); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Assignment Notes</label>
                                <textarea name="notes" class="form-control" rows="2" placeholder="Reason for assignment..."></textarea>
                            </div>
                            <button type="submit" class="btn btn-success w-100">
                                <i class="fas fa-sign-out-alt"></i> Assign Asset
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h5>QR Code</h5>
                </div>
                <div class="card-body text-center">
                    <div id="qrcode"></div>
                    <button class="btn btn-sm btn-primary mt-3" onclick="downloadQR()">
                        <i class="fas fa-download"></i> Download QR
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Generate QR code for the asset
        const assetTag = '<?php echo $asset['asset_tag']; ?>';
        const qrcodeDiv = document.getElementById('qrcode');
        if(qrcodeDiv) {
            qrcodeDiv.innerHTML = '';
            new QRCode(qrcodeDiv, {
                text: assetTag,
                width: 200,
                height: 200
            });
        }
    });
    </script>
    <?php
}

// Licenses Management
function includeLicenses($pdo) {
    $licenses = $pdo->query("SELECT l.*, m.name as manufacturer_name, 
                            (SELECT COUNT(*) FROM license_assignments WHERE license_id = l.id) as used_seats
                            FROM licenses l 
                            LEFT JOIN manufacturers m ON l.manufacturer_id = m.id 
                            ORDER BY l.created_at DESC")->fetchAll();
    
    $manufacturers = $pdo->query("SELECT * FROM manufacturers ORDER BY name")->fetchAll();
    // assets list for assignment dropdown
    $assets = $pdo->query("SELECT id, asset_tag, name FROM assets ORDER BY asset_tag")->fetchAll();
    // user list for assignment dropdown
    $users = $pdo->query("SELECT id, first_name, last_name FROM users WHERE status = 'active' ORDER BY first_name")->fetchAll();
    ?>
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>License Management</h2>
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addLicenseModal">
            <i class="fas fa-plus"></i> Add License
        </button>
    </div>
    
    <div class="row">
        <?php foreach($licenses as $license): ?>
        <div class="col-md-4 mb-3">
            <div class="card h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start">
                        <h5 class="card-title"><?php echo htmlspecialchars($license['name'] ?? ''); ?></h5>
                        <span class="badge bg-<?php 
                            echo ($license['used_seats'] / $license['seats']) >= 0.9 ? 'danger' : 
                                (($license['used_seats'] / $license['seats']) >= 0.7 ? 'warning' : 'success'); 
                        ?>">
                            <?php echo $license['used_seats']; ?>/<?php echo $license['seats']; ?> seats
                        </span>
                    </div>
                    <p class="card-text">
                        <small class="text-muted">Product Key:</small> 
                        <code><?php echo htmlspecialchars($license['product_key'] ?? ''); ?></code><br>
                        
                        <?php if($license['expiration_date']): ?>
                        <small class="text-muted">Expires:</small> 
                        <?php 
                            $days = ceil((strtotime($license['expiration_date']) - time()) / (60 * 60 * 24));
                            $badge_class = $days <= 30 ? 'warning' : 'info';
                        ?>
                        <span class="badge bg-<?php echo $badge_class; ?>">
                            <?php echo date('Y-m-d', strtotime($license['expiration_date'])); ?>
                            (<?php echo $days; ?> days)
                        </span><br>
                        <?php endif; ?>
                        
                        <small class="text-muted">Manufacturer:</small> 
                        <?php echo htmlspecialchars($license['manufacturer_name'] ?: 'N/A'); ?>
                    </p>
                    
                    <div class="progress mb-2" style="height: 20px;">
                        <div class="progress-bar <?php 
                            echo ($license['used_seats'] / $license['seats']) >= 0.9 ? 'bg-danger' : 
                                (($license['used_seats'] / $license['seats']) >= 0.7 ? 'bg-warning' : 'bg-success'); 
                        ?>" 
                             style="width: <?php echo ($license['used_seats'] / $license['seats']) * 100; ?>%">
                            <?php echo round(($license['used_seats'] / $license['seats']) * 100); ?>%
                        </div>
                    </div>
                    
                    <div class="btn-group w-100">
                        <button class="btn btn-sm btn-primary" onclick="assignLicense(<?php echo $license['id']; ?>)">
                            <i class="fas fa-user-plus"></i> Assign
                        </button>
                        <button class="btn btn-sm btn-info" onclick="viewLicenseDetails(<?php echo $license['id']; ?>)">
                            <i class="fas fa-info-circle"></i> Details
                        </button>
                        <button class="btn btn-sm btn-warning" onclick="editLicense(<?php echo $license['id']; ?>)">
                            <i class="fas fa-edit"></i> Edit
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    
    <!-- Add License Modal -->
    <div class="modal fade" id="addLicenseModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New License</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <input type="hidden" name="action" value="add_license">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">License Name *</label>
                            <input type="text" name="name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Product Key</label>
                            <input type="text" name="product_key" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Number of Seats</label>
                            <input type="number" name="seats" class="form-control" value="1" min="1">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Manufacturer</label>
                            <select name="manufacturer_id" class="form-select">
                                <option value="">Select Manufacturer</option>
                                <?php foreach($manufacturers as $manufacturer): ?>
                                <option value="<?php echo $manufacturer['id']; ?>"><?php echo htmlspecialchars($manufacturer['name'] ?? ''); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Purchase Date</label>
                            <input type="date" name="purchase_date" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Expiration Date</label>
                            <input type="date" name="expiration_date" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Notes</label>
                            <textarea name="notes" class="form-control" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Add License</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- View/Edit/Assign Modals -->
    <div class="modal fade" id="viewLicenseModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">License Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="viewLicenseContent">
                    <div class="text-center py-4">
                        Loading <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="editLicenseModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit License</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" id="editLicenseForm">
                    <input type="hidden" name="action" value="update_license">
                    <input type="hidden" name="license_id" id="edit_license_id">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">License Name *</label>
                                <input type="text" name="name" id="edit_name" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Product Key</label>
                                <input type="text" name="product_key" id="edit_product_key" class="form-control">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Number of Seats</label>
                                <input type="number" name="seats" id="edit_seats" class="form-control" min="1">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Manufacturer</label>
                                <select name="manufacturer_id" id="edit_manufacturer_id" class="form-select">
                                    <option value="">Select Manufacturer</option>
                                    <?php foreach($manufacturers as $manufacturer): ?>
                                    <option value="<?php echo $manufacturer['id']; ?>"><?php echo htmlspecialchars($manufacturer['name'] ?? ''); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Purchase Date</label>
                                <input type="date" name="purchase_date" id="edit_purchase_date" class="form-control">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Expiration Date</label>
                                <input type="date" name="expiration_date" id="edit_expiration_date" class="form-control">
                            </div>
                            <div class="col-md-12 mb-3">
                                <label class="form-label">Notes</label>
                                <textarea name="notes" id="edit_notes" class="form-control" rows="3"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="assignLicenseModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Assign License</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" id="assignLicenseForm">
                    <input type="hidden" name="action" value="assign_license">
                    <input type="hidden" name="license_id" id="assign_license_id">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Assign To User</label>
                            <select name="user_id" class="form-select">
                                <option value="">-- select user --</option>
                                <?php foreach($users as $user): ?>
                                <option value="<?php echo $user['id']; ?>"><?php echo htmlspecialchars(strval($user['first_name'] . ' ' . $user['last_name'])); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Assign To Asset</label>
                            <select name="asset_id" class="form-select">
                                <option value="">-- select asset --</option>
                                <?php foreach($assets as $a): ?>
                                <option value="<?php echo $a['id']; ?>"><?php echo htmlspecialchars(strval($a['asset_tag'] . ' (' . $a['name'] . ')')); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Assign</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        function assignLicense(id) {
            document.getElementById('assign_license_id').value = id;
            new bootstrap.Modal(document.getElementById('assignLicenseModal')).show();
        }
        
        function viewLicenseDetails(id) {
            const modalEl = document.getElementById('viewLicenseModal');
            const content = document.getElementById('viewLicenseContent');
            content.innerHTML = '<div class="text-center py-4">Loading <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span></div>';
            new bootstrap.Modal(modalEl).show();
            fetch('?ajax=get_license&license_id=' + id)
                .then(r=>r.json())
                .then(data=>{
                    if(data.success && data.data) {
                        const lic = data.data;
                        let html = '<table class="table table-borderless">';
                        html += `<tr><th>Name:</th><td>${lic.name}</td></tr>`;
                        html += `<tr><th>Product Key:</th><td>${lic.product_key}</td></tr>`;
                        html += `<tr><th>Seats:</th><td>${lic.seats}</td></tr>`;
                        html += `<tr><th>Purchase Date:</th><td>${lic.purchase_date || '-'}</td></tr>`;
                        html += `<tr><th>Expiration:</th><td>${lic.expiration_date || '-'}</td></tr>`;
                        html += `<tr><th>Notes:</th><td>${lic.notes || '-'}</td></tr>`;
                        html += '</table>';
                            content.innerHTML = html;
                    } else {
                        content.innerHTML = '<div class="alert alert-danger">Unable to load license</div>';
                    }
                });
        }
        
        function editLicense(id) {
            fetch('?ajax=get_license&license_id=' + id)
                .then(r=>r.json())
                .then(data=>{
                    if(data.success && data.data) {
                        const lic = data.data;
                        document.getElementById('edit_license_id').value = lic.id;
                        document.getElementById('edit_name').value = lic.name;
                        document.getElementById('edit_product_key').value = lic.product_key;
                        document.getElementById('edit_seats').value = lic.seats;
                        document.getElementById('edit_manufacturer_id').value = lic.manufacturer_id || '';
                        document.getElementById('edit_purchase_date').value = lic.purchase_date || '';
                        document.getElementById('edit_expiration_date').value = lic.expiration_date || '';
                        document.getElementById('edit_notes').value = lic.notes || '';
                        new bootstrap.Modal(document.getElementById('editLicenseModal')).show();
                    } else {
                        showToast('error','License not found');
                    }
                });
        }
    </script>
    <?php
}




// Enhanced Accessories Management Page (new implementation)
function includeAccessoriesPage($pdo) {
    // show single accessory view if requested
    if(isset($_GET['view'])) {
        includeAccessoryDetail($pdo, intval($_GET['view']), false);
        return;
    }

    // load lookup data
    $accessories = $pdo->query("SELECT a.*, c.name as category_name, m.name as manufacturer_name, l.name as location_name,
                          (SELECT COUNT(*) FROM accessory_assignments WHERE accessory_id = a.id AND returned_at IS NULL) as assigned_count
                          FROM accessories a
                          LEFT JOIN categories c ON a.category_id = c.id
                          LEFT JOIN manufacturers m ON a.manufacturer_id = m.id
                          LEFT JOIN locations l ON a.location_id = l.id
                          ORDER BY a.created_at DESC")->fetchAll();

    $categories = $pdo->query("SELECT * FROM categories WHERE type = 'accessory' OR type = 'all' ORDER BY name")->fetchAll();
    $manufacturers = $pdo->query("SELECT * FROM manufacturers ORDER BY name")->fetchAll();
    $locations = $pdo->query("SELECT * FROM locations ORDER BY name")->fetchAll();
    $users = $pdo->query("SELECT id, first_name, last_name FROM users WHERE status = 'active' ORDER BY first_name")->fetchAll();
    ?>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Accessories Management</h2>
        <div>
            <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addAccessoryModal">
                <i class="fas fa-plus"></i> Add Accessory
            </button>
        </div>
    </div>

    <div class="card mb-3">
        <div class="card-body">
            <input type="text" class="search-box" placeholder="Search accessories..." id="accessorySearch" onkeyup="liveSearch(this,'#accessories-table')">
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover datatable" id="accessories-table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Manufacturer</th>
                            <th>Model</th>
                            <th>Serial</th>
                            <th>Location</th>
                            <th>Qty<th>
                            <th>Available</th>
                            <th>Min Qty</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($accessories as $accessory):
                            $available = $accessory['quantity'] - $accessory['assigned_count'];
                            $status_class = $available <= 0 ? 'danger' : ($available <= $accessory['min_quantity'] ? 'warning' : 'success');
                        ?>
                        <tr>
                            <td><?php echo htmlspecialchars($accessory['name'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($accessory['category_name'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($accessory['manufacturer_name'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($accessory['model_number'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($accessory['serial_number'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($accessory['location_name'] ?? ''); ?></td>
                            <td><?php echo $accessory['quantity']; ?></td>
                            <td><span class="badge bg-<?php echo $status_class; ?>"><?php echo $available; ?></span></td>
                            <td><?php echo $accessory['min_quantity']; ?></td>
                            <td>
                                <div class="btn-group">
                                    <?php if($available > 0): ?>
                                    <button class="btn btn-sm btn-success" onclick="assignAccessory(<?php echo $accessory['id']; ?>)">
                                        <i class="fas fa-hand-pointer"></i>
                                    </button>
                                    <?php endif; ?>
                                    <button class="btn btn-sm btn-info" onclick="viewAccessoryDetails(<?php echo $accessory['id']; ?>)">
                                        <i class="fas fa-info-circle"></i>
                                    </button>
                                    <button class="btn btn-sm btn-primary" onclick="editAccessory(<?php echo $accessory['id']; ?>)">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <?php if($_SESSION['user_role']=='admin'): ?>
                                    <button class="btn btn-sm btn-danger" onclick="deleteAccessory(<?php echo $accessory['id']; ?>)">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Add Accessory Modal -->
    <div class="modal fade" id="addAccessoryModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Accessory</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="?action=accessories">
                    <input type="hidden" name="action" value="add_accessory">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Name *</label>
                            <input type="text" name="name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Category</label>
                            <select name="category_id" class="form-select">
                                <option value="">Select Category</option>
                                <?php foreach($categories as $category): ?>
                                <option value="<?php echo $category['id']; ?>" style="color: <?php echo $category['color'] ?? '#000'; ?>;">● <?php echo htmlspecialchars($category['name'] ?? '') . ' (' . ucfirst($category['type'] ?? 'asset') . ')'; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Manufacturer</label>
                            <select name="manufacturer_id" class="form-select">
                                <option value="">Select Manufacturer</option>
                                <?php foreach($manufacturers as $manufacturer): ?>
                                <option value="<?php echo $manufacturer['id']; ?>"><?php echo htmlspecialchars($manufacturer['name'] ?? ''); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Location</label>
                            <select name="location_id" class="form-select">
                                <option value="">Select Location</option>
                                <?php foreach($locations as $location): ?>
                                <option value="<?php echo $location['id']; ?>"><?php echo htmlspecialchars($location['name'] ?? '') . ($location['address'] ? ' - ' . htmlspecialchars($location['address']) : '') . ($location['city'] ? ', ' . htmlspecialchars($location['city']) : '') . ($location['state'] ? ', ' . htmlspecialchars($location['state']) : ''); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Model Number</label>
                            <input type="text" name="model_number" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Serial Number</label>
                            <input type="text" name="serial_number" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Quantity</label>
                            <input type="number" name="quantity" class="form-control" value="1" min="1">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Minimum Quantity</label>
                            <input type="number" name="min_quantity" class="form-control" value="0" min="0">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Purchase Date</label>
                            <input type="date" name="purchase_date" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Purchase Cost</label>
                            <div class="input-group">
                                <span class="input-group-text">$</span>
                                <input type="number" step="0.01" name="purchase_cost" class="form-control">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Notes</label>
                            <textarea name="notes" class="form-control" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Add Accessory</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Assign Accessory Modal -->
    <div class="modal fade" id="assignAccessoryModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Assign Accessory</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <input type="hidden" name="action" value="assign_accessory">
                    <input type="hidden" name="accessory_id" id="assign_accessory_id">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Select User</label>
                            <select name="user_id" class="form-select" required>
                                <option value="">Choose...</option>
                                <?php foreach($users as $user): ?>
                                <option value="<?php echo $user['id']; ?>">
                                    <?php echo htmlspecialchars(strval($user['first_name'] . ' ' . $user['last_name'])); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Notes</label>
                            <textarea name="notes" class="form-control" rows="2"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Assign</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        function assignAccessory(id) {
            document.getElementById('assign_accessory_id').value = id;
            new bootstrap.Modal(document.getElementById('assignAccessoryModal')).show();
        }

        function editAccessory(id) {
            fetch('?ajax=get_accessory&accessory_id=' + id)
                .then(r=>r.json())
                .then(data=>{
                    if(data.success && data.data) {
                        const a = data.data;
                        document.getElementById('edit_accessory_id').value = a.id;
                        document.getElementById('edit_name').value = a.name;
                        document.getElementById('edit_category_id').value = a.category_id || '';
                        document.getElementById('edit_manufacturer_id').value = a.manufacturer_id || '';
                        document.getElementById('edit_location_id').value = a.location_id || '';
                        document.getElementById('edit_model_number').value = a.model_number || '';
                        document.getElementById('edit_serial_number').value = a.serial_number || '';
                        document.getElementById('edit_quantity').value = a.quantity;
                        document.getElementById('edit_min_quantity').value = a.min_quantity;
                        document.getElementById('edit_purchase_date').value = a.purchase_date || '';
                        document.getElementById('edit_purchase_cost').value = a.purchase_cost || '';
                        document.getElementById('edit_notes').value = a.notes || '';
                        new bootstrap.Modal(document.getElementById('editAccessoryModal')).show();
                    } else {
                        showToast('error','Accessory not found');
                    }
                });
        }

        function deleteAccessory(id) {
            if(confirm('Are you sure you want to delete this accessory? This cannot be undone.')) {
                fetch('?ajax=delete_accessory', {
                    method:'POST',
                    headers:{'Content-Type':'application/x-www-form-urlencoded'},
                    body:'accessory_id='+id
                }).then(r=>r.json())
                  .then(data=>{
                      if(data.success) {
                          showToast('success','Accessory deleted');
                          location.reload();
                      } else showToast('error',data.message||'Failed to delete accessory');
                  });
            }
        }

        function viewAccessoryDetails(id) {
            fetch('?ajax=accessory_detail_html&accessory_id='+id)
                .then(r=>r.json())
                .then(data=>{
                    if(data.success) {
                        document.getElementById('viewAccessoryModalBody').innerHTML=data.html;
                        new bootstrap.Modal(document.getElementById('viewAccessoryModal')).show();
                    } else {
                        showToast('error', data.message || 'Unable to load details');
                    }
                });
        }
    </script>

    <!-- Edit Accessory Modal (if not already present) -->
    <div class="modal fade" id="editAccessoryModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Accessory</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <input type="hidden" name="action" value="update_accessory">
                    <input type="hidden" name="accessory_id" id="edit_accessory_id">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Name *</label>
                            <input type="text" name="name" id="edit_name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Category</label>
                            <select name="category_id" id="edit_category_id" class="form-select">
                                <option value="">Select Category</option>
                                <?php foreach($categories as $category): ?>
                                <option value="<?php echo $category['id']; ?>" style="color: <?php echo $category['color'] ?? '#000'; ?>;">● <?php echo htmlspecialchars($category['name'] ?? '') . ' (' . ucfirst($category['type'] ?? 'asset') . ')'; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Manufacturer</label>
                            <select name="manufacturer_id" id="edit_manufacturer_id" class="form-select">
                                <option value="">Select Manufacturer</option>
                                <?php foreach($manufacturers as $manufacturer): ?>
                                <option value="<?php echo $manufacturer['id']; ?>"><?php echo htmlspecialchars($manufacturer['name'] ?? ''); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Location</label>
                            <select name="location_id" id="edit_location_id" class="form-select">
                                <option value="">Select Location</option>
                                <?php foreach($locations as $location): ?>
                                <option value="<?php echo $location['id']; ?>"><?php echo htmlspecialchars($location['name'] ?? '') . ($location['address'] ? ' - ' . htmlspecialchars($location['address']) : '') . ($location['city'] ? ', ' . htmlspecialchars($location['city']) : '') . ($location['state'] ? ', ' . htmlspecialchars($location['state']) : ''); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Model Number</label>
                            <input type="text" name="model_number" id="edit_model_number" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Serial Number</label>
                            <input type="text" name="serial_number" id="edit_serial_number" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Quantity</label>
                            <input type="number" name="quantity" id="edit_quantity" class="form-control" min="1">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Minimum Quantity</label>
                            <input type="number" name="min_quantity" id="edit_min_quantity" class="form-control" min="0">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Purchase Date</label>
                            <input type="date" name="purchase_date" id="edit_purchase_date" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Purchase Cost</label>
                            <div class="input-group">
                                <span class="input-group-text">$</span>
                                <input type="number" step="0.01" name="purchase_cost" id="edit_purchase_cost" class="form-control">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Notes</label>
                            <textarea name="notes" id="edit_notes" class="form-control" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Update Accessory</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- View Accessory Modal -->
    <div class="modal fade" id="viewAccessoryModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Accessory Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="viewAccessoryModalBody"></div>
            </div>
        </div>
    </div>
    <?php
}

function includeAccessoryDetail($pdo, $accessory_id, $isModal = false) {
    $stmt = $pdo->prepare("SELECT a.*, c.name as category_name, m.name as manufacturer_name, l.name as location_name
                          FROM accessories a
                          LEFT JOIN categories c ON a.category_id = c.id
                          LEFT JOIN manufacturers m ON a.manufacturer_id = m.id
                          LEFT JOIN locations l ON a.location_id = l.id
                          WHERE a.id = ?");
    $stmt->execute([$accessory_id]);
    $accessory = $stmt->fetch();
    if(!$accessory) {
        echo '<div class="alert alert-danger">Accessory not found</div>';
        return;
    }

    $stmt = $pdo->prepare("SELECT aa.*, u.first_name, u.last_name, u.username
                          FROM accessory_assignments aa
                          LEFT JOIN users u ON aa.user_id = u.id
                          WHERE aa.accessory_id = ?
                          ORDER BY aa.assigned_at DESC");
    $stmt->execute([$accessory_id]);
    $assignments = $stmt->fetchAll();

    $available = $accessory['quantity'];
    foreach($assignments as $a) {
        if(is_null($a['returned_at'])) $available--;
    }

    // header + actions (back link only on full page)
    echo '<div class="d-flex justify-content-between align-items-center mb-4">';
    echo '<h2>Accessory Details: ' . htmlspecialchars($accessory['name'] ?? '') . '</h2>';
    echo '<div>'; 
    if(!$isModal) {
        echo '<button class="btn btn-sm btn-success me-2" onclick="assignAccessory(' . $accessory_id . ')"><i class="fas fa-hand-pointer"></i> Assign</button>';
        echo '<button class="btn btn-sm btn-info me-2" onclick="editAccessory(' . $accessory_id . ')"><i class="fas fa-edit"></i> Edit</button>';
        if($_SESSION['user_role'] == 'admin') {
            echo '<button class="btn btn-sm btn-danger me-2" onclick="deleteAccessory(' . $accessory_id . ')"><i class="fas fa-trash"></i> Delete</button>';
        }
    }
    if(!$isModal) {
        echo '<a href="?action=accessories" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Accessories</a>';
    }
    echo '</div>';
    echo '</div>';
    ?>
    <div class="row" id="accessory-detail">
        <div class="col-md-8">
            <div class="card mb-3"><div class="card-header"><h5>Information</h5></div><div class="card-body">
            <table class="table table-borderless">
                <tr><th>Name:</th><td><?php echo htmlspecialchars($accessory['name'] ?? ''); ?></td></tr>
                <tr><th>Category:</th><td><?php echo htmlspecialchars($accessory['category_name'] ?? '-'); ?></td></tr>
                <tr><th>Manufacturer:</th><td><?php echo htmlspecialchars($accessory['manufacturer_name'] ?? '-'); ?></td></tr>
                <tr><th>Model:</th><td><?php echo htmlspecialchars($accessory['model_number'] ?? '-'); ?></td></tr>
                <tr><th>Serial:</th><td><?php echo htmlspecialchars($accessory['serial_number'] ?? '-'); ?></td></tr>
                <tr><th>Location:</th><td><?php echo htmlspecialchars($accessory['location_name'] ?? '-'); ?></td></tr>
                <tr><th>Quantity:</th><td><?php echo $accessory['quantity']; ?></td></tr>
                <tr><th>Available:</th><td><?php echo $available; ?></td></tr>
                <tr><th>Minimum Qty:</th><td><?php echo $accessory['min_quantity']; ?></td></tr>
                <tr><th>Purchase Date:</th><td><?php echo $accessory['purchase_date'] ?: '-'; ?></td></tr>
                <tr><th>Purchase Cost:</th><td>$<?php echo number_format($accessory['purchase_cost'],2); ?></td></tr>
                <tr><th>Notes:</th><td><?php echo nl2br(htmlspecialchars($accessory['notes'] ?? '')); ?></td></tr>
            </table>
            </div></div>
        </div>
        <div class="col-md-4">
            <div class="card mb-3"><div class="card-header"><h5>Assignments</h5></div><div class="card-body">
                <?php if(count($assignments)==0): ?>
                    <p class="text-muted">No assignments.</p>
                <?php else: ?>
                    <ul class="list-group">
                    <?php foreach($assignments as $a): ?>
                        <li class="list-group-item">
                            <?php echo htmlspecialchars($a['first_name'].' '.$a['last_name']); ?>
                            <?php if($a['returned_at']): ?>
                                <span class="badge bg-success ms-2">Returned</span>
                            <?php else: ?>
                                <span class="badge bg-warning ms-2">Assigned</span>
                            <?php endif; ?><br>
                            <small>At: <?php echo $a['assigned_at']; ?></small>
                            <?php if($a['returned_at']): ?>
                                <br><small>Returned: <?php echo $a['returned_at']; ?></small>
                            <?php endif; ?>
                            <?php if(is_null($a['returned_at'])): ?>
                                <form method="POST" class="mt-1">
                                    <input type="hidden" name="action" value="return_accessory">
                                    <input type="hidden" name="assignment_id" value="<?php echo $a['id']; ?>">
                                    <button type="submit" class="btn btn-sm btn-secondary">Return</button>
                                </form>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div></div>
        </div>
    </div>
    <?php
    if(!$isModal) {
        // modals and supporting javascript for standalone detail page
        ?>
        <!-- Edit Accessory Modal -->
        <div class="modal fade" id="editAccessoryModal" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Edit Accessory</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <form method="POST">
                        <input type="hidden" name="action" value="update_accessory">
                        <input type="hidden" name="accessory_id" id="edit_accessory_id">
                        <div class="modal-body">
                            <!-- same fields as other edit forms -->
                            <div class="mb-3">
                                <label class="form-label">Name *</label>
                                <input type="text" name="name" id="edit_name" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Category</label>
                                <select name="category_id" id="edit_category_id" class="form-select">
                                    <option value="">Select Category</option>
                                    <?php foreach($categories as $category): ?>
                                    <option value="<?php echo $category['id']; ?>" style="color: <?php echo $category['color'] ?? '#000'; ?>;">● <?php echo htmlspecialchars($category['name'] ?? '') . ' (' . ucfirst($category['type'] ?? 'asset') . ')'; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Manufacturer</label>
                                <select name="manufacturer_id" id="edit_manufacturer_id" class="form-select">
                                    <option value="">Select Manufacturer</option>
                                    <?php foreach($manufacturers as $manufacturer): ?>
                                    <option value="<?php echo $manufacturer['id']; ?>"><?php echo htmlspecialchars($manufacturer['name'] ?? ''); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Location</label>
                                <select name="location_id" id="edit_location_id" class="form-select">
                                    <option value="">Select Location</option>
                                    <?php foreach($locations as $location): ?>
                                    <option value="<?php echo $location['id']; ?>"><?php echo htmlspecialchars($location['name'] ?? '') . ($location['address'] ? ' - ' . htmlspecialchars($location['address']) : '') . ($location['city'] ? ', ' . htmlspecialchars($location['city']) : '') . ($location['state'] ? ', ' . htmlspecialchars($location['state']) : ''); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Model Number</label>
                                <input type="text" name="model_number" id="edit_model_number" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Serial Number</label>
                                <input type="text" name="serial_number" id="edit_serial_number" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Quantity</label>
                                <input type="number" name="quantity" id="edit_quantity" class="form-control" min="1">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Minimum Quantity</label>
                                <input type="number" name="min_quantity" id="edit_min_quantity" class="form-control" min="0">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Purchase Date</label>
                                <input type="date" name="purchase_date" id="edit_purchase_date" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Purchase Cost</label>
                                <div class="input-group">
                                    <span class="input-group-text">$</span>
                                    <input type="number" step="0.01" name="purchase_cost" id="edit_purchase_cost" class="form-control">
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Notes</label>
                                <textarea name="notes" id="edit_notes" class="form-control" rows="3"></textarea>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">Update Accessory</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Assign Accessory Modal -->
        <div class="modal fade" id="assignAccessoryModal" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Assign Accessory</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <form method="POST">
                        <input type="hidden" name="action" value="assign_accessory">
                        <input type="hidden" name="accessory_id" id="assign_accessory_id">
                        <input type="hidden" name="return_to_view" id="assign_return_to_view" value="0">
                        <div class="modal-body">
                            <div class="mb-3">
                                <label class="form-label">Select User</label>
                                <select name="user_id" class="form-select" required>
                                    <option value="">Choose...</option>
                                    <?php foreach($users as $user): ?>
                                    <option value="<?php echo $user['id']; ?>"><?php echo htmlspecialchars(strval($user['first_name'] . ' ' . $user['last_name'])); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Notes</label>
                                <textarea name="notes" class="form-control" rows="2"></textarea>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">Assign</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <script>
            function editAccessory(id) {
                fetch('?ajax=get_accessory&accessory_id=' + id)
                    .then(r=>r.json())
                    .then(data=>{
                        if(data.success && data.data) {
                            const a = data.data;
                            document.getElementById('edit_accessory_id').value = a.id;
                            document.getElementById('edit_name').value = a.name;
                            document.getElementById('edit_category_id').value = a.category_id || '';
                            document.getElementById('edit_manufacturer_id').value = a.manufacturer_id || '';
                            document.getElementById('edit_location_id').value = a.location_id || '';
                            // populate other fields as needed
                            new bootstrap.Modal(document.getElementById('editAccessoryModal')).show();
                        } else {
                            showToast('error','Accessory not found');
                        }
                    });
            }
            function deleteAccessory(id) {
                if(confirm('Are you sure you want to delete this accessory? This cannot be undone.')) {
                    fetch('?ajax=delete_accessory', {
                        method:'POST',
                        headers:{'Content-Type':'application/x-www-form-urlencoded'},
                        body:'accessory_id='+id
                    }).then(r=>r.json()).then(data=>{
                        if(data.success) {
                            showToast('success','Accessory deleted');
                            window.location.href='?action=accessories';
                        }
                    });
                }
            }
            function assignAccessory(id) {
                document.getElementById('assign_accessory_id').value = id;
                var returnFlag = window.location.search.indexOf('view=') !== -1 ? 1 : 0;
                var returnEl = document.getElementById('assign_return_to_view');
                if(returnEl) returnEl.value = returnFlag;
                new bootstrap.Modal(document.getElementById('assignAccessoryModal')).show();
            }
        </script>
        <?php
    }
}

// Consumables Management
function includeConsumables($pdo) {
    $consumables = $pdo->query("SELECT c.*, cat.name as category_name, m.name as manufacturer_name, l.name as location_name,
                              (SELECT SUM(quantity) FROM consumable_assignments WHERE consumable_id = c.id) as used_quantity
                              FROM consumables c 
                              LEFT JOIN categories cat ON c.category_id = cat.id 
                              LEFT JOIN manufacturers m ON c.manufacturer_id = m.id 
                              LEFT JOIN locations l ON c.location_id = l.id 
                              ORDER BY c.created_at DESC")->fetchAll();
    
    $categories = $pdo->query("SELECT * FROM categories WHERE type = 'consumable' OR type = 'all' ORDER BY name")->fetchAll();
    $manufacturers = $pdo->query("SELECT * FROM manufacturers ORDER BY name")->fetchAll();
    $locations = $pdo->query("SELECT * FROM locations ORDER BY name")->fetchAll();
    $users = $pdo->query("SELECT id, first_name, last_name FROM users WHERE status = 'active' ORDER BY first_name")->fetchAll();
    ?>
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Inventory Management</h2>
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addConsumableModal">
            <i class="fas fa-plus"></i> Add Item
        </button>
    </div>
    
    <div class="row">
        <?php foreach($consumables as $consumable): 
            $available = $consumable['quantity'] - ($consumable['used_quantity'] ?: 0);
            $status_class = $available <= 0 ? 'danger' : ($available <= $consumable['min_quantity'] ? 'warning' : 'success');
        ?>
        <div class="col-md-4 mb-3">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title"><?php echo htmlspecialchars($consumable['name'] ?? ''); ?></h5>
                    <p class="card-text">
                        <small class="text-muted">Category:</small> <?php echo htmlspecialchars($consumable['category_name'] ?? ''); ?><br>
                        <small class="text-muted">Manufacturer:</small> <?php echo htmlspecialchars($consumable['manufacturer_name'] ?? ''); ?><br>
                        <small class="text-muted">Model:</small> <?php echo htmlspecialchars($consumable['model_number'] ?? ''); ?><br>
                        <small class="text-muted">Item #:</small> <?php echo htmlspecialchars($consumable['item_no'] ?? ''); ?>
                    </p>
                    
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span>Available:</span>
                        <span class="badge bg-<?php echo $status_class; ?> fs-6">
                            <?php echo $available; ?> / <?php echo $consumable['quantity']; ?>
                        </span>
                    </div>
                    
                    <?php if($available > 0): ?>
                    <button class="btn btn-sm btn-success w-100 mb-2" onclick="checkoutConsumable(<?php echo $consumable['id']; ?>)">
                        <i class="fas fa-hand-pointer"></i> Checkout
                    </button>
                    <?php endif; ?>
                    
                    <button class="btn btn-sm btn-info w-100" onclick="viewConsumableDetails(<?php echo $consumable['id']; ?>)">
                        <i class="fas fa-info-circle"></i> Details
                    </button>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    
    <!-- Add Consumable Modal -->
    <div class="modal fade" id="addConsumableModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Item</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <input type="hidden" name="action" value="add_consumable">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Name *</label>
                            <input type="text" name="name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Category</label>
                            <select name="category_id" class="form-select">
                                <option value="">Select Category</option>
                                <?php foreach($categories as $category): ?>
                                <option value="<?php echo $category['id']; ?>" style="color: <?php echo $category['color'] ?? '#000'; ?>;">● <?php echo htmlspecialchars($category['name'] ?? '') . ' (' . ucfirst($category['type'] ?? 'asset') . ')'; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Manufacturer</label>
                            <select name="manufacturer_id" class="form-select">
                                <option value="">Select Manufacturer</option>
                                <?php foreach($manufacturers as $manufacturer): ?>
                                <option value="<?php echo $manufacturer['id']; ?>"><?php echo htmlspecialchars($manufacturer['name'] ?? ''); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Location</label>
                            <select name="location_id" class="form-select">
                                <option value="">Select Location</option>
                                <?php foreach($locations as $location): ?>
                                <option value="<?php echo $location['id']; ?>"><?php echo htmlspecialchars($location['name'] ?? '') . ($location['address'] ? ' - ' . htmlspecialchars($location['address']) : '') . ($location['city'] ? ', ' . htmlspecialchars($location['city']) : '') . ($location['state'] ? ', ' . htmlspecialchars($location['state']) : ''); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Model Number</label>
                            <input type="text" name="model_number" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Item Number</label>
                            <input type="text" name="item_no" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Quantity</label>
                            <input type="number" name="quantity" class="form-control" value="1" min="1">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Minimum Quantity</label>
                            <input type="number" name="min_quantity" class="form-control" value="0" min="0">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Purchase Date</label>
                            <input type="date" name="purchase_date" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Purchase Cost</label>
                            <div class="input-group">
                                <span class="input-group-text">$</span>
                                <input type="number" step="0.01" name="purchase_cost" class="form-control">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Notes</label>
                            <textarea name="notes" class="form-control" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Add Item</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Checkout Consumable Modal -->
    <div class="modal fade" id="checkoutConsumableModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Issue Item</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <input type="hidden" name="action" value="checkout_consumable">
                    <input type="hidden" name="consumable_id" id="checkout_consumable_id">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Select User</label>
                            <select name="user_id" class="form-select" required>
                                <option value="">Choose...</option>
                                <?php foreach($users as $user): ?>
                                <option value="<?php echo $user['id']; ?>">
                                    <?php echo htmlspecialchars(strval($user['first_name'] . ' ' . $user['last_name'])); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Quantity</label>
                            <input type="number" name="quantity" class="form-control" value="1" min="1" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Notes</label>
                            <textarea name="notes" class="form-control" rows="2"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Checkout</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- View Consumable Modal -->
    <div class="modal fade" id="viewConsumableModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Item Details <span class="spinner-border spinner-border-sm modal-spinner" role="status" aria-hidden="true"></span></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="viewConsumableContent">
                    <!-- injected -->
                </div>
            </div>
        </div>
    </div>
    
    <script>
        function checkoutConsumable(id) {
            document.getElementById('checkout_consumable_id').value = id;
            new bootstrap.Modal(document.getElementById('checkoutConsumableModal')).show();
        }
        
        function viewConsumableDetails(id) {
            const modalEl = document.getElementById('viewConsumableModal');
            const content = document.getElementById('viewConsumableContent');
            content.innerHTML = '<div class="text-center py-4">Loading <span class="spinner-border spinner-border-sm" role="status"></span></div>';
            const m = new bootstrap.Modal(modalEl);
            m.show();

            fetch('?ajax=get_consumable&consumable_id=' + id)
                .then(r => r.json())
                .then(data => {
                    if(data.success && data.data) {
                        const c = data.data;
                        let html = '<dl class="row">';
                        html += '<dt class="col-sm-3">Name</dt><dd class="col-sm-9">' + (c.name ?? '') + '</dd>';
                        html += '<dt class="col-sm-3">Category</dt><dd class="col-sm-9">' + (c.category_id ?? '-') + '</dd>';
                        html += '<dt class="col-sm-3">Manufacturer</dt><dd class="col-sm-9">' + (c.manufacturer_id ?? '-') + '</dd>';
                        html += '<dt class="col-sm-3">Model</dt><dd class="col-sm-9">' + (c.model_number ?? '-') + '</dd>';
                        html += '<dt class="col-sm-3">Item #</dt><dd class="col-sm-9">' + (c.item_no ?? '-') + '</dd>';
                        html += '<dt class="col-sm-3">Quantity</dt><dd class="col-sm-9">' + (c.quantity ?? 0) + '</dd>';
                        html += '<dt class="col-sm-3">Used</dt><dd class="col-sm-9">' + (c.used_quantity ?? 0) + '</dd>';
                        html += '<dt class="col-sm-3">Available</dt><dd class="col-sm-9">' + (c.available ?? 0) + '</dd>';
                        html += '<dt class="col-sm-3">Min Quantity</dt><dd class="col-sm-9">' + (c.min_quantity ?? 0) + '</dd>';
                        html += '<dt class="col-sm-3">Notes</dt><dd class="col-sm-9">' + (c.notes ? c.notes.replace(/\n/g, '<br>') : '') + '</dd>';
                        html += '</dl>';
                        content.innerHTML = html;
                    } else {
                        content.innerHTML = '<div class="alert alert-danger">Failed to load consumable details</div>';
                    }
                })
                .catch(err => {
                    console.error('Error fetching consumable:', err);
                    content.innerHTML = '<div class="alert alert-danger">Failed to load consumable details</div>';
                });
        }
    </script>
    <?php
}

// People Management
function includePeople($pdo) {
    $users = $pdo->query("SELECT * FROM users ORDER BY created_at DESC")->fetchAll();
    ?>
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>People Management</h2>
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addUserModal">
            <i class="fas fa-plus"></i> Add User
        </button>
    </div>
    
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover datatable">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Employee ID</th>
                            <th>Department</th>
                            <th>Position</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Last Login</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($users as $user): 
                            // Get assigned assets count
                            $stmt = $pdo->prepare("SELECT COUNT(*) FROM assets WHERE assigned_to = ?");
                            $stmt->execute([$user['id']]);
                            $asset_count = $stmt->fetchColumn();
                        ?>
                        <tr>
                            <td><?php echo htmlspecialchars(strval($user['first_name'] . ' ' . $user['last_name'])); ?></td>
                            <td><?php echo htmlspecialchars($user['username']); ?></td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td><?php echo htmlspecialchars($user['employee_id'] ?: '-'); ?></td>
                            <td><?php echo htmlspecialchars($user['department'] ?: '-'); ?></td>
                            <td><?php echo htmlspecialchars($user['position'] ?: '-'); ?></td>
                            <td>
                                <span class="badge bg-<?php echo $user['role'] == 'admin' ? 'danger' : ($user['role'] == 'manager' ? 'warning' : 'primary'); ?>">
                                    <?php echo ucfirst($user['role']); ?>
                                </span>
                            </td>
                            <td>
                                <span class="badge bg-<?php echo $user['status'] == 'active' ? 'success' : 'secondary'; ?>">
                                    <?php echo ucfirst($user['status']); ?>
                                </span>
                            </td>
                            <td><?php echo $user['last_login'] ? date('Y-m-d H:i', strtotime($user['last_login'])) : 'Never'; ?></td>
                            <td>
                                <div class="btn-group">
                                    <button class="btn btn-sm btn-info" onclick="viewUser(<?php echo $user['id']; ?>)">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button class="btn btn-sm btn-primary" onclick="editUser(<?php echo $user['id']; ?>)">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <?php if($user['id'] != $_SESSION['user_id'] && $_SESSION['user_role'] == 'admin'): ?>
                                    <button class="btn btn-sm btn-<?php echo $user['status'] == 'active' ? 'warning' : 'success'; ?>" 
                                            onclick="toggleUserStatus(<?php echo $user['id']; ?>, '<?php echo $user['status']; ?>')">
                                        <i class="fas fa-<?php echo $user['status'] == 'active' ? 'ban' : 'check'; ?>"></i>
                                    </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Add User Modal -->
    <div class="modal fade" id="addUserModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <input type="hidden" name="action" value="add_user">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">First Name *</label>
                                <input type="text" name="first_name" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Last Name *</label>
                                <input type="text" name="last_name" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Username *</label>
                                <input type="text" name="username" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Email *</label>
                                <input type="email" name="email" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Password</label>
                                <input type="password" name="password" class="form-control" value="password123">
                                <small class="text-muted">Default: password123</small>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Employee ID</label>
                                <input type="text" name="employee_id" class="form-control">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Department</label>
                                <input type="text" name="department" class="form-control">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Position</label>
                                <input type="text" name="position" class="form-control">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Phone</label>
                                <input type="text" name="phone" class="form-control">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Role</label>
                                <select name="role" class="form-select">
                                    <option value="user">User</option>
                                    <option value="manager">Manager</option>
                                    <option value="admin">Admin</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Add User</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script>
        function viewUser(id) {
            alert('User details would be shown here for ID: ' + id);
        }
        
        function editUser(id) {
            alert('User edit would be implemented here for ID: ' + id);
        }
        
        function toggleUserStatus(id, currentStatus) {
            const action = currentStatus == 'active' ? 'deactivate' : 'activate';
            if(confirm(`Are you sure you want to ${action} this user?`)) {
                alert('Status change would be implemented here');
            }
        }
    </script>
    <?php
}

// Reports
function includeReports($pdo) {
    ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Reports</h2>
        <div class="btn-group">
            <button class="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                <i class="fas fa-download"></i> Generate Report
            </button>
            <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#" onclick="generateReport('assets')">Asset Report</a></li>
                <li><a class="dropdown-item" href="#" onclick="generateReport('licenses')">License Report</a></li>
                <li><a class="dropdown-item" href="#" onclick="generateReport('users')">User Report</a></li>
                <li><a class="dropdown-item" href="#" onclick="generateReport('maintenance')">Maintenance Report</a></li>
                <li><a class="dropdown-item" href="#" onclick="generateReport('depreciation')">Depreciation Report</a></li>
                <li><a class="dropdown-item" href="#" onclick="generateReport('audit')">Audit Report</a></li>
            </ul>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h5>Asset Summary by Location</h5>
                </div>
                <div class="card-body">
                    <canvas id="locationChart" style="height: 300px;"></canvas>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h5>Assets by Category</h5>
                </div>
                <div class="card-body">
                    <canvas id="categoryChart" style="height: 300px;"></canvas>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row mt-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h5>Asset Status Overview</h5>
                </div>
                <div class="card-body">
                    <canvas id="statusChart" style="height: 300px;"></canvas>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h5>Monthly Acquisitions</h5>
                </div>
                <div class="card-body">
                    <canvas id="acquisitionChart" style="height: 300px;"></canvas>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row mt-4">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5>Depreciation Report</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Asset</th>
                                    <th>Purchase Date</th>
                                    <th>Purchase Cost</th>
                                    <th>Current Value</th>
                                    <th>Depreciation %</th>
                                    <th>Remaining Value</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $assets = $pdo->query("SELECT name, purchase_date, purchase_cost FROM assets WHERE purchase_date IS NOT NULL AND purchase_cost > 0 LIMIT 10")->fetchAll();
                                foreach($assets as $asset):
                                    $years = $asset['purchase_date'] ? (time() - strtotime($asset['purchase_date'])) / (365 * 24 * 60 * 60) : 0;
                                    $depreciation = min(100, $years * 20); // 20% per year straight line
                                    $current_value = $asset['purchase_cost'] * (1 - $depreciation/100);
                                ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($asset['name']); ?></td>
                                    <td><?php echo $asset['purchase_date']; ?></td>
                                    <td>$<?php echo number_format($asset['purchase_cost'], 2); ?></td>
                                    <td>$<?php echo number_format($current_value, 2); ?></td>
                                    <td>
                                        <div class="progress" style="height: 20px;">
                                            <div class="progress-bar bg-<?php echo $depreciation >= 80 ? 'danger' : ($depreciation >= 50 ? 'warning' : 'success'); ?>" 
                                                 style="width: <?php echo $depreciation; ?>%">
                                                <?php echo round($depreciation); ?>%
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <?php
                                        $percent_remaining = 100 - $depreciation;
                                        $badge_class = $percent_remaining >= 50 ? 'success' : ($percent_remaining >= 25 ? 'warning' : 'danger');
                                        ?>
                                        <span class="badge bg-<?php echo $badge_class; ?>">
                                            <?php echo round($percent_remaining); ?>% remaining
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Location chart data
        <?php
        $location_data = $pdo->query("SELECT l.name, COUNT(a.id) as count 
                                      FROM locations l 
                                      LEFT JOIN assets a ON l.id = a.location_id 
                                      GROUP BY l.id")->fetchAll();
        $location_labels = [];
        $location_counts = [];
        foreach($location_data as $loc) {
            $location_labels[] = $loc['name'];
            $location_counts[] = $loc['count'];
        }
        ?>
        
        // Category chart data
        <?php
        $category_data = $pdo->query("SELECT c.name, COUNT(a.id) as count 
                                      FROM categories c 
                                      LEFT JOIN assets a ON c.id = a.category_id 
                                      WHERE c.type = 'asset' 
                                      GROUP BY c.id")->fetchAll();
        $category_labels = [];
        $category_counts = [];
        foreach($category_data as $cat) {
            $category_labels[] = $cat['name'];
            $category_counts[] = $cat['count'];
        }
        ?>
        
        // Status chart data
        <?php
        $status_data = $pdo->query("SELECT status, COUNT(*) as count FROM assets GROUP BY status")->fetchAll();
        $status_labels = [];
        $status_counts = [];
        $status_colors = [
            'available' => '#28a745',
            'assigned' => '#007bff',
            'maintenance' => '#dc3545',
            'retired' => '#6c757d'
        ];
        foreach($status_data as $status) {
            $status_labels[] = ucfirst($status['status']);
            $status_counts[] = $status['count'];
        }
        ?>
        
        // Acquisition chart data
        <?php
        $acquisition_data = $pdo->query("SELECT DATE_FORMAT(purchase_date, '%Y-%m') as month, COUNT(*) as count 
                                        FROM assets WHERE purchase_date IS NOT NULL 
                                        GROUP BY DATE_FORMAT(purchase_date, '%Y-%m') 
                                        ORDER BY month DESC LIMIT 6")->fetchAll();
        $acquisition_labels = [];
        $acquisition_counts = [];
        foreach(array_reverse($acquisition_data) as $acq) {
            $acquisition_labels[] = $acq['month'];
            $acquisition_counts[] = $acq['count'];
        }
        ?>
        
        // Initialize charts
        new Chart(document.getElementById('locationChart'), {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($location_labels); ?>,
                datasets: [{
                    label: 'Assets by Location',
                    data: <?php echo json_encode($location_counts); ?>,
                    backgroundColor: '#3498DB'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
        
        new Chart(document.getElementById('categoryChart'), {
            type: 'pie',
            data: {
                labels: <?php echo json_encode($category_labels); ?>,
                datasets: [{
                    data: <?php echo json_encode($category_counts); ?>,
                    backgroundColor: ['#3498DB', '#2ECC71', '#F39C12', '#E74C3C', '#9B59B6', '#1ABC9C']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
        
        new Chart(document.getElementById('statusChart'), {
            type: 'doughnut',
            data: {
                labels: <?php echo json_encode($status_labels); ?>,
                datasets: [{
                    data: <?php echo json_encode($status_counts); ?>,
                    backgroundColor: <?php echo json_encode(array_values($status_colors)); ?>
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
        
        new Chart(document.getElementById('acquisitionChart'), {
            type: 'line',
            data: {
                labels: <?php echo json_encode($acquisition_labels); ?>,
                datasets: [{
                    label: 'Assets Acquired',
                    data: <?php echo json_encode($acquisition_counts); ?>,
                    borderColor: '#2ECC71',
                    backgroundColor: 'rgba(46, 204, 113, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
        
        function generateReport(type) {
            alert('Report generation for ' + type + ' would be implemented here');
        }
    </script>
    <?php
}

// Settings
function includeSettings($pdo) {
    $settings = $pdo->query("SELECT setting_key, setting_value FROM settings")->fetchAll(PDO::FETCH_KEY_PAIR);
    $categories = $pdo->query("SELECT * FROM categories ORDER BY type, name")->fetchAll();
    $manufacturers = $pdo->query("SELECT * FROM manufacturers ORDER BY name")->fetchAll();
    $locations = $pdo->query("SELECT * FROM locations ORDER BY name")->fetchAll();
    $custom_fields = $pdo->query("SELECT * FROM custom_fields ORDER BY name")->fetchAll();
    ?>
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>System Settings</h2>
    </div>
    
    <ul class="nav nav-tabs mb-3" id="settingsTabs" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#general">General</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" data-bs-toggle="tab" data-bs-target="#categories">Categories</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" data-bs-toggle="tab" data-bs-target="#manufacturers">Manufacturers</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" data-bs-toggle="tab" data-bs-target="#locations">Locations</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" data-bs-toggle="tab" data-bs-target="#customfields">Custom Fields</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" data-bs-toggle="tab" data-bs-target="#system">System</button>
        </li>
    </ul>
    
    <div class="tab-content">
        <!-- General Settings -->
        <div class="tab-pane fade show active" id="general">
            <div class="card">
                <div class="card-body">
                    <form method="POST">
                        <input type="hidden" name="action" value="update_settings">
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Site Name</label>
                                <input type="text" name="site_name" class="form-control" value="<?php echo htmlspecialchars($settings['site_name'] ?? ''); ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Site URL</label>
                                <input type="text" name="site_url" class="form-control" value="<?php echo htmlspecialchars($settings['site_url'] ?? ''); ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Company Name</label>
                                <input type="text" name="company_name" class="form-control" value="<?php echo htmlspecialchars($settings['company_name'] ?? ''); ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Default Currency</label>
                                <select name="default_currency" class="form-select">
                                    <option value="USD" <?php echo ($settings['default_currency'] ?? '') == 'USD' ? 'selected' : ''; ?>>USD ($)</option>
                                    <option value="EUR" <?php echo ($settings['default_currency'] ?? '') == 'EUR' ? 'selected' : ''; ?>>EUR (€)</option>
                                    <option value="GBP" <?php echo ($settings['default_currency'] ?? '') == 'GBP' ? 'selected' : ''; ?>>GBP (£)</option>
                                    <option value="JPY" <?php echo ($settings['default_currency'] ?? '') == 'JPY' ? 'selected' : ''; ?>>JPY (¥)</option>
                                    <option value="CAD" <?php echo ($settings['default_currency'] ?? '') == 'CAD' ? 'selected' : ''; ?>>CAD ($)</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Alert Threshold (days)</label>
                                <input type="number" name="alert_threshold" class="form-control" value="<?php echo $settings['alert_threshold'] ?? 30; ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Date Format</label>
                                <input type="text" name="date_format" class="form-control" value="<?php echo htmlspecialchars($settings['date_format'] ?? 'Y-m-d'); ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <div class="form-check">
                                    <input type="checkbox" name="enable_qr" class="form-check-input" value="true" 
                                           <?php echo ($settings['enable_qr'] ?? '') == 'true' ? 'checked' : ''; ?>>
                                    <label class="form-check-label">Enable QR Codes</label>
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <div class="form-check">
                                    <input type="checkbox" name="auto_increment_asset_tag" class="form-check-input" value="true"
                                           <?php echo ($settings['auto_increment_asset_tag'] ?? '') == 'true' ? 'checked' : ''; ?>>
                                    <label class="form-check-label">Auto-increment Asset Tags</label>
                                </div>
                            </div>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Save Settings</button>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- Categories -->
        <div class="tab-pane fade" id="categories">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Categories</h5>
                    <button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#addCategoryModal">
                        <i class="fas fa-plus"></i> Add Category
                    </button>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Type</th>
                                    <th>Color</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($categories as $category): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($category['name'] ?? ''); ?></td>
                                    <td><span class="badge bg-secondary"><?php echo ucfirst($category['type']); ?></span></td>
                                    <td>
                                        <span style="display: inline-block; width: 30px; height: 30px; background: <?php echo $category['color']; ?>; border-radius: 5px;"></span>
                                        <?php echo $category['color']; ?>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-warning" onclick="editCategory(<?php echo $category['id']; ?>)">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-danger" onclick="deleteCategory(<?php echo $category['id']; ?>)">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Manufacturers -->
        <div class="tab-pane fade" id="manufacturers">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Manufacturers</h5>
                    <button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#addManufacturerModal">
                        <i class="fas fa-plus"></i> Add Manufacturer
                    </button>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Support URL</th>
                                    <th>Support Phone</th>
                                    <th>Support Email</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($manufacturers as $manufacturer): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($manufacturer['name'] ?? ''); ?></td>
                                    <td><a href="<?php echo htmlspecialchars($manufacturer['support_url'] ?? ''); ?>" target="_blank"><?php echo htmlspecialchars($manufacturer['support_url'] ?? ''); ?></a></td>
                                    <td><?php echo htmlspecialchars($manufacturer['support_phone'] ?? ''); ?></td>
                                    <td><?php echo htmlspecialchars($manufacturer['support_email'] ?? ''); ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-warning" onclick="editManufacturer(<?php echo $manufacturer['id']; ?>)">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-danger" onclick="deleteManufacturer(<?php echo $manufacturer['id']; ?>)">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Locations -->
        <div class="tab-pane fade" id="locations">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Locations</h5>
                    <button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#addLocationModal">
                        <i class="fas fa-plus"></i> Add Location
                    </button>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Address</th>
                                    <th>City</th>
                                    <th>State</th>
                                    <th>Country</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($locations as $location): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($location['name']); ?></td>
                                    <td><?php echo htmlspecialchars($location['address']); ?></td>
                                    <td><?php echo htmlspecialchars($location['city']); ?></td>
                                    <td><?php echo htmlspecialchars($location['state']); ?></td>
                                    <td><?php echo htmlspecialchars($location['country']); ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-warning" onclick="editLocation(<?php echo $location['id']; ?>)">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-danger" onclick="deleteLocation(<?php echo $location['id']; ?>)">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Custom Fields -->
        <div class="tab-pane fade" id="customfields">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Custom Fields</h5>
                    <button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#addCustomFieldModal">
                        <i class="fas fa-plus"></i> Add Custom Field
                    </button>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Type</th>
                                    <th>Options</th>
                                    <th>Required</th>
                                    <th>Show in List</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($custom_fields as $field): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($field['name']); ?></td>
                                    <td><span class="badge bg-info"><?php echo ucfirst($field['type']); ?></span></td>
                                    <td><small><?php echo htmlspecialchars(substr($field['field_options'], 0, 30)) . '...'; ?></small></td>
                                    <td><?php echo $field['required'] ? 'Yes' : 'No'; ?></td>
                                    <td><?php echo $field['show_in_list'] ? 'Yes' : 'No'; ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-warning" onclick="editCustomField(<?php echo $field['id']; ?>)">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-danger" onclick="deleteCustomField(<?php echo $field['id']; ?>)">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- System -->
        <div class="tab-pane fade" id="system">
            <div class="card">
                <div class="card-header">
                    <h5>System Information</h5>
                </div>
                <div class="card-body">
                    <table class="table">
                        <tr>
                            <th>Version:</th>
                            <td><?php echo $settings['version'] ?? '24.04 LTS'; ?></td>
                        </tr>
                        <tr>
                            <th>PHP Version:</th>
                            <td><?php echo phpversion(); ?></td>
                        </tr>
                        <tr>
                            <th>MySQL Version:</th>
                            <td>
                                <?php
                                $stmt = $pdo->query("SELECT VERSION() as version");
                                $version = $stmt->fetch();
                                echo $version['version'];
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <th>Server Software:</th>
                            <td><?php echo $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown'; ?></td>
                        </tr>
                        <tr>
                            <th>Max Upload Size:</th>
                            <td><?php echo ini_get('upload_max_filesize'); ?></td>
                        </tr>
                        <tr>
                            <th>Max Execution Time:</th>
                            <td><?php echo ini_get('max_execution_time'); ?> seconds</td>
                        </tr>
                        <tr>
                            <th>Memory Limit:</th>
                            <td><?php echo ini_get('memory_limit'); ?></td>
                        </tr>
                    </table>
                    
                    <div class="mt-3">
                        <button class="btn btn-warning" onclick="clearCache()">
                            <i class="fas fa-trash"></i> Clear Cache
                        </button>
                        <button class="btn btn-danger" onclick="optimizeDatabase()">
                            <i class="fas fa-database"></i> Optimize Database
                        </button>
                        <button class="btn btn-info" onclick="backupDatabase()">
                            <i class="fas fa-download"></i> Backup Database
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Add Category Modal -->
    <div class="modal fade" id="addCategoryModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add Category</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <input type="hidden" name="action" value="add_category">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Name *</label>
                            <input type="text" name="name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Type</label>
                            <select name="type" class="form-select">
                                <option value="asset">Asset</option>
                                <option value="accessory">Accessory</option>
                                <option value="consumable">Consumable</option>
                                <option value="license">License</option>
                                <option value="all">All Types</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Color</label>
                            <input type="color" name="color" class="form-control" value="#3498DB">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Add Category</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Add Manufacturer Modal -->
    <div class="modal fade" id="addManufacturerModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add Manufacturer</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <input type="hidden" name="action" value="add_manufacturer">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Name *</label>
                            <input type="text" name="name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Support URL</label>
                            <input type="url" name="support_url" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Support Phone</label>
                            <input type="text" name="support_phone" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Support Email</label>
                            <input type="email" name="support_email" class="form-control">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Add Manufacturer</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Add Location Modal -->
    <div class="modal fade" id="addLocationModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add Location</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <input type="hidden" name="action" value="add_location">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Name *</label>
                            <input type="text" name="name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Address</label>
                            <input type="text" name="address" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Address Line 2</label>
                            <input type="text" name="address2" class="form-control">
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">City</label>
                                <input type="text" name="city" class="form-control">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">State</label>
                                <input type="text" name="state" class="form-control">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">ZIP/Postal Code</label>
                                <input type="text" name="zip" class="form-control">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Country</label>
                                <input type="text" name="country" class="form-control">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Add Location</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Add Custom Field Modal -->
    <div class="modal fade" id="addCustomFieldModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add Custom Field</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <input type="hidden" name="action" value="add_custom_field">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Field Name *</label>
                            <input type="text" name="name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Field Type</label>
                            <select name="type" class="form-select" id="fieldType" onchange="toggleFieldOptions()">
                                <option value="text">Text</option>
                                <option value="number">Number</option>
                                <option value="date">Date</option>
                                <option value="boolean">Yes/No</option>
                                <option value="select">Dropdown</option>
                            </select>
                        </div>
                        <div class="mb-3" id="optionsField" style="display: none;">
                            <label class="form-label">Options (one per line)</label>
                            <textarea name="options" class="form-control" rows="4" placeholder="Option 1&#10;Option 2&#10;Option 3"></textarea>
                        </div>
                        <div class="mb-3">
                            <div class="form-check">
                                <input type="checkbox" name="required" class="form-check-input">
                                <label class="form-check-label">Required field</label>
                            </div>
                        </div>
                        <div class="mb-3">
                            <div class="form-check">
                                <input type="checkbox" name="show_in_list" class="form-check-input" checked>
                                <label class="form-check-label">Show in list view</label>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Add Field</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script>
        function toggleFieldOptions() {
            const type = document.getElementById('fieldType').value;
            document.getElementById('optionsField').style.display = type === 'select' ? 'block' : 'none';
        }
        
        function editCategory(id) {
            alert('Edit category ' + id);
        }
        
        function deleteCategory(id) {
            if(confirm('Are you sure you want to delete this category?')) {
                alert('Delete category ' + id);
            }
        }
        
        function editManufacturer(id) {
            alert('Edit manufacturer ' + id);
        }
        
        function deleteManufacturer(id) {
            if(confirm('Are you sure you want to delete this manufacturer?')) {
                alert('Delete manufacturer ' + id);
            }
        }
        
        function editLocation(id) {
            alert('Edit location ' + id);
        }
        
        function deleteLocation(id) {
            if(confirm('Are you sure you want to delete this location?')) {
                alert('Delete location ' + id);
            }
        }
        
        function editCustomField(id) {
            alert('Edit custom field ' + id);
        }
        
        function deleteCustomField(id) {
            if(confirm('Are you sure you want to delete this custom field?')) {
                alert('Delete custom field ' + id);
            }
        }
        
        function clearCache() {
            if(confirm('Clear system cache?')) {
                alert('Cache cleared');
            }
        }
        
        function optimizeDatabase() {
            if(confirm('Optimize database tables? This may take a few moments.')) {
                alert('Database optimized');
            }
        }
        
        function backupDatabase() {
            alert('Database backup would be downloaded here');
        }
    </script>
    <?php
}
?>