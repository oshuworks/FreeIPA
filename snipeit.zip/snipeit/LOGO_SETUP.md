# Snipe-IT Logo Setup Guide

## Color Palette Implementation ✅

The following color palette has been successfully implemented in the Snipe-IT application:

### Primary Palette
- **Charcoal Gray** - #2C3E50 (headers, primary text, sidebar background)
- **Warm Orange** - #F39C12 (accents, active buttons, highlights, active sidebar links)
- **Light Gray** - #ECF0F1 (card backgrounds, form backgrounds)

### Secondary Palette
- **Medium Gray** - #7F8C8D (secondary text, retired status)
- **Off-white** - #F8F9FA (page background)
- **Dark Slate** - #1A252F (for future footer/dark mode implementation)

### Accent Colors
- **Success Green** - #27AE60 (available status, check-in buttons)
- **Info Blue** - #3498DB (links, info messages)
- **Warning Yellow** - #F1C40F (warnings, maintenance status)
- **Danger Red** - #E74C3C (errors, check-out status, dangerous actions)

## Logo Setup Instructions

### Adding the Logo

1. **Prepare Your Logo File**
   - Format the logo as PNG with transparency: `snipeit.png`
   - Recommended dimensions: 200x200px or larger (will be scaled to 70px height)
   - Suggested colors: Use Charcoal Gray (#2C3E50) and Warm Orange (#F39C12) for brand consistency

2. **Place the Logo File**
   - Copy/upload `snipeit.png` to the root directory of the application:
     ```
     c:\xampp\htdocs\snipeit\snipeit.png
     ```
   - The logo will automatically display in the sidebar header

3. **Logo Display Information**
   - Location: Top of the left sidebar, above the "Snipe-IT" text
   - Size: Automatically scaled to 70px height
   - Features: 
     - Logo has a drop shadow effect for depth
     - Scales up slightly on hover (1.05x)
     - Separated from menu items by a subtle divider line

### Logo Styling Applied

The logo area includes:
- Centered display with padding
- Top and bottom border separator (subtle white divider)
- Drop shadow effect
- Hover animation (slight scale up)
- Responsive sizing

### Example Logo Recommendations

For best results, create a logo that:
- Uses the Charcoal Gray (#2C3E50) as the primary color
- Incorporates the Warm Orange (#F39C12) as accent
- Includes simple, clean design
- Works well at both small (70px) and large (200px) sizes
- Has a transparent background for seamless integration

### If Logo File Not Found

If `snipeit.png` is not found:
- The sidebar will display without the logo image
- The application will continue to function normally
- A placeholder area will be visible above the "Snipe-IT" text
- Simply add the logo file to enable the visual

## CSS Color Variables Used

All colors are defined as CSS variables for easy future updates:

```css
--primary-color: #2C3E50
--secondary-color: #F39C12
--success-color: #27AE60
--danger-color: #E74C3C
--warning-color: #F1C40F
--info-color: #3498DB
--light-gray: #ECF0F1
--medium-gray: #7F8C8D
--off-white: #F8F9FA
--dark-slate: #1A252F
```

To change colors globally, simply update these CSS variable definitions in the `<style>` section.

## Color Usage Throughout the Application

- **Sidebar**: Charcoal Gray background with Warm Orange active links
- **Buttons**: Primary (Charcoal), Success (Green), Danger (Red), Warning (Yellow), Info (Blue)
- **Status Badges**: 
  - Available: Success Green
  - Assigned: Danger Red
  - Maintenance: Warning Yellow
  - Retired: Medium Gray
- **Form Elements**: Warm Orange border on focus
- **Toasts/Notifications**: Color-coded borders matching their type
- **Cards**: Light Gray headers with smooth shadows
- **Links**: Info Blue with Warm Orange hover effect

## Testing the Theme

1. Navigate to the application dashboard
2. Look for the warm orange accent on the active sidebar link
3. Hover over buttons to see the color transitions
4. View asset status badges to see color-coded information
5. Check form inputs when focused (orange border)
6. View toast notifications (color-coded by type)

---

**Installation Date**: February 27, 2026  
**Color Palette Version**: 1.0  
**Logo Support**: PNG format with transparency
